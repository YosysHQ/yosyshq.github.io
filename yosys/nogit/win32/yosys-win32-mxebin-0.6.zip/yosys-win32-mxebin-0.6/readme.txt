This is Yosys 0.6 for Win32.
Documentation at http://www.clifford.at/yosys/.
