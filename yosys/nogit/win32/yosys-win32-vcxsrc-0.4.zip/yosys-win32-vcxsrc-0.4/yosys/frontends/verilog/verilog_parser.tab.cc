/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1


/* Substitute the variable and function names.  */
#define yyparse         frontend_verilog_yyparse
#define yylex           frontend_verilog_yylex
#define yyerror         frontend_verilog_yyerror
#define yydebug         frontend_verilog_yydebug
#define yynerrs         frontend_verilog_yynerrs

#define yylval          frontend_verilog_yylval
#define yychar          frontend_verilog_yychar

/* Copy the first part of user declarations.  */
#line 36 "frontends/verilog/verilog_parser.y" /* yacc.c:339  */

#include <list>
#include <string.h>
#include "verilog_frontend.h"
#include "kernel/log.h"

USING_YOSYS_NAMESPACE
using namespace AST;
using namespace VERILOG_FRONTEND;

YOSYS_NAMESPACE_BEGIN
namespace VERILOG_FRONTEND {
	int port_counter;
	std::map<std::string, int> port_stubs;
	std::map<std::string, AstNode*> attr_list, default_attr_list;
	std::map<std::string, AstNode*> *albuf;
	std::vector<AstNode*> ast_stack;
	struct AstNode *astbuf1, *astbuf2, *astbuf3;
	struct AstNode *current_function_or_task;
	struct AstNode *current_ast, *current_ast_mod;
	int current_function_or_task_port_id;
	std::vector<char> case_type_stack;
	bool do_not_require_port_stubs;
	bool default_nettype_wire;
	bool sv_mode;
	std::istream *lexin;
}
YOSYS_NAMESPACE_END

static void append_attr(AstNode *ast, std::map<std::string, AstNode*> *al)
{
	for (auto &it : *al) {
		if (ast->attributes.count(it.first) > 0)
			delete ast->attributes[it.first];
		ast->attributes[it.first] = it.second;
	}
	delete al;
}

static void append_attr_clone(AstNode *ast, std::map<std::string, AstNode*> *al)
{
	for (auto &it : *al) {
		if (ast->attributes.count(it.first) > 0)
			delete ast->attributes[it.first];
		ast->attributes[it.first] = it.second->clone();
	}
}

static void free_attr(std::map<std::string, AstNode*> *al)
{
	for (auto &it : *al)
		delete it.second;
	delete al;
}


#line 131 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "verilog_parser.tab.h".  */
#ifndef YY_FRONTEND_VERILOG_YY_FRONTENDS_VERILOG_VERILOG_PARSER_TAB_H_INCLUDED
# define YY_FRONTEND_VERILOG_YY_FRONTENDS_VERILOG_VERILOG_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int frontend_verilog_yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    TOK_STRING = 258,
    TOK_ID = 259,
    TOK_CONST = 260,
    TOK_REALVAL = 261,
    TOK_PRIMITIVE = 262,
    ATTR_BEGIN = 263,
    ATTR_END = 264,
    DEFATTR_BEGIN = 265,
    DEFATTR_END = 266,
    TOK_MODULE = 267,
    TOK_ENDMODULE = 268,
    TOK_PARAMETER = 269,
    TOK_LOCALPARAM = 270,
    TOK_DEFPARAM = 271,
    TOK_INPUT = 272,
    TOK_OUTPUT = 273,
    TOK_INOUT = 274,
    TOK_WIRE = 275,
    TOK_REG = 276,
    TOK_INTEGER = 277,
    TOK_SIGNED = 278,
    TOK_ASSIGN = 279,
    TOK_ALWAYS = 280,
    TOK_INITIAL = 281,
    TOK_BEGIN = 282,
    TOK_END = 283,
    TOK_IF = 284,
    TOK_ELSE = 285,
    TOK_FOR = 286,
    TOK_WHILE = 287,
    TOK_REPEAT = 288,
    TOK_DPI_FUNCTION = 289,
    TOK_POSEDGE = 290,
    TOK_NEGEDGE = 291,
    TOK_OR = 292,
    TOK_CASE = 293,
    TOK_CASEX = 294,
    TOK_CASEZ = 295,
    TOK_ENDCASE = 296,
    TOK_DEFAULT = 297,
    TOK_FUNCTION = 298,
    TOK_ENDFUNCTION = 299,
    TOK_TASK = 300,
    TOK_ENDTASK = 301,
    TOK_GENERATE = 302,
    TOK_ENDGENERATE = 303,
    TOK_GENVAR = 304,
    TOK_REAL = 305,
    TOK_SYNOPSYS_FULL_CASE = 306,
    TOK_SYNOPSYS_PARALLEL_CASE = 307,
    TOK_SUPPLY0 = 308,
    TOK_SUPPLY1 = 309,
    TOK_TO_SIGNED = 310,
    TOK_TO_UNSIGNED = 311,
    TOK_POS_INDEXED = 312,
    TOK_NEG_INDEXED = 313,
    TOK_ASSERT = 314,
    TOK_PROPERTY = 315,
    OP_LOR = 316,
    OP_LAND = 317,
    OP_NOR = 318,
    OP_XNOR = 319,
    OP_NAND = 320,
    OP_EQ = 321,
    OP_NE = 322,
    OP_EQX = 323,
    OP_NEX = 324,
    OP_LE = 325,
    OP_GE = 326,
    OP_SHL = 327,
    OP_SHR = 328,
    OP_SSHL = 329,
    OP_SSHR = 330,
    OP_POW = 331,
    UNARY_OPS = 332
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 95 "frontends/verilog/verilog_parser.y" /* yacc.c:355  */

	std::string *string;
	struct YOSYS_NAMESPACE_PREFIX AST::AstNode *ast;
	std::map<std::string, YOSYS_NAMESPACE_PREFIX AST::AstNode*> *al;
	bool boolean;

#line 256 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:355  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE frontend_verilog_yylval;

int frontend_verilog_yyparse (void);

#endif /* !YY_FRONTEND_VERILOG_YY_FRONTENDS_VERILOG_VERILOG_PARSER_TAB_H_INCLUDED  */

/* Copy the second part of user declarations.  */

#line 271 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1179

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  104
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  156
/* YYNRULES -- Number of rules.  */
#define YYNRULES  338
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  650

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   332

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   103,     2,    92,     2,    85,    67,     2,
      93,    94,    83,    81,    88,    82,    90,    84,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    96,    91,
      73,    89,    76,   101,    98,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    95,     2,    97,    65,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    99,    63,   100,   102,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    64,    66,
      68,    69,    70,    71,    72,    74,    75,    77,    78,    79,
      80,    86,    87
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   141,   141,   141,   152,   153,   154,   154,   158,   158,
     171,   171,   175,   182,   175,   188,   188,   191,   192,   195,
     201,   209,   212,   222,   222,   243,   243,   243,   243,   246,
     247,   247,   251,   251,   255,   258,   258,   258,   261,   261,
     264,   264,   267,   277,   281,   281,   294,   294,   308,   313,
     313,   320,   320,   323,   326,   329,   333,   335,   338,   344,
     350,   355,   360,   365,   370,   376,   379,   385,   388,   393,
     394,   397,   400,   408,   410,   410,   414,   414,   414,   414,
     414,   414,   414,   415,   415,   415,   415,   418,   418,   428,
     428,   439,   439,   451,   451,   463,   463,   486,   491,   497,
     497,   501,   502,   503,   503,   507,   510,   515,   515,   515,
     519,   515,   527,   527,   530,   530,   551,   554,   554,   558,
     560,   563,   570,   573,   577,   580,   589,   589,   597,   597,
     605,   605,   608,   620,   623,   623,   626,   637,   652,   637,
     658,   666,   676,   676,   679,   680,   690,   732,   735,   735,
     738,   743,   743,   752,   752,   762,   765,   770,   771,   774,
     774,   781,   781,   790,   791,   794,   795,   795,   801,   801,
     803,   804,   805,   808,   813,   821,   822,   823,   824,   824,
     830,   835,   842,   850,   855,   850,   863,   863,   877,   878,
     879,   880,   881,   881,   885,   886,   887,   890,   895,   900,
     907,   910,   915,   920,   925,   929,   936,   936,   936,   937,
     938,   938,   948,   948,   964,   969,   971,   964,   979,   979,
     992,   992,  1005,  1005,  1019,  1019,  1030,  1033,  1036,  1041,
    1045,  1048,  1052,  1053,  1056,  1056,  1060,  1060,  1066,  1070,
    1070,  1074,  1078,  1074,  1090,  1090,  1094,  1098,  1094,  1106,
    1107,  1110,  1113,  1116,  1121,  1126,  1131,  1138,  1141,  1146,
    1150,  1156,  1156,  1160,  1160,  1164,  1165,  1168,  1173,  1173,
    1177,  1177,  1181,  1185,  1181,  1190,  1190,  1198,  1198,  1206,
    1206,  1220,  1220,  1229,  1229,  1232,  1232,  1235,  1238,  1247,
    1250,  1260,  1272,  1279,  1285,  1296,  1300,  1300,  1310,  1314,
    1318,  1321,  1324,  1327,  1331,  1335,  1339,  1343,  1347,  1351,
    1356,  1360,  1365,  1369,  1373,  1377,  1381,  1385,  1389,  1393,
    1397,  1401,  1405,  1409,  1413,  1417,  1421,  1425,  1429,  1433,
    1437,  1441,  1445,  1449,  1453,  1457,  1461,  1467,  1470
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TOK_STRING", "TOK_ID", "TOK_CONST",
  "TOK_REALVAL", "TOK_PRIMITIVE", "ATTR_BEGIN", "ATTR_END",
  "DEFATTR_BEGIN", "DEFATTR_END", "TOK_MODULE", "TOK_ENDMODULE",
  "TOK_PARAMETER", "TOK_LOCALPARAM", "TOK_DEFPARAM", "TOK_INPUT",
  "TOK_OUTPUT", "TOK_INOUT", "TOK_WIRE", "TOK_REG", "TOK_INTEGER",
  "TOK_SIGNED", "TOK_ASSIGN", "TOK_ALWAYS", "TOK_INITIAL", "TOK_BEGIN",
  "TOK_END", "TOK_IF", "TOK_ELSE", "TOK_FOR", "TOK_WHILE", "TOK_REPEAT",
  "TOK_DPI_FUNCTION", "TOK_POSEDGE", "TOK_NEGEDGE", "TOK_OR", "TOK_CASE",
  "TOK_CASEX", "TOK_CASEZ", "TOK_ENDCASE", "TOK_DEFAULT", "TOK_FUNCTION",
  "TOK_ENDFUNCTION", "TOK_TASK", "TOK_ENDTASK", "TOK_GENERATE",
  "TOK_ENDGENERATE", "TOK_GENVAR", "TOK_REAL", "TOK_SYNOPSYS_FULL_CASE",
  "TOK_SYNOPSYS_PARALLEL_CASE", "TOK_SUPPLY0", "TOK_SUPPLY1",
  "TOK_TO_SIGNED", "TOK_TO_UNSIGNED", "TOK_POS_INDEXED", "TOK_NEG_INDEXED",
  "TOK_ASSERT", "TOK_PROPERTY", "OP_LOR", "OP_LAND", "'|'", "OP_NOR",
  "'^'", "OP_XNOR", "'&'", "OP_NAND", "OP_EQ", "OP_NE", "OP_EQX", "OP_NEX",
  "'<'", "OP_LE", "OP_GE", "'>'", "OP_SHL", "OP_SHR", "OP_SSHL", "OP_SSHR",
  "'+'", "'-'", "'*'", "'/'", "'%'", "OP_POW", "UNARY_OPS", "','", "'='",
  "'.'", "';'", "'#'", "'('", "')'", "'['", "':'", "']'", "'@'", "'{'",
  "'}'", "'?'", "'~'", "'!'", "$accept", "input", "$@1", "design", "attr",
  "$@2", "attr_opt", "defattr", "$@3", "$@4", "opt_attr_list", "attr_list",
  "attr_assign", "hierarchical_id", "module", "$@5", "module_para_opt",
  "$@6", "$@7", "module_para_list", "single_module_para", "$@8",
  "module_args_opt", "module_args", "optional_comma",
  "module_arg_opt_assignment", "module_arg", "$@9", "$@10", "wire_type",
  "$@11", "wire_type_token_list", "wire_type_token", "non_opt_range",
  "non_opt_multirange", "range", "range_or_multirange",
  "range_or_signed_int", "module_body", "module_body_stmt",
  "task_func_decl", "$@12", "$@13", "$@14", "$@15", "$@16",
  "dpi_function_arg", "opt_dpi_function_args", "dpi_function_args",
  "opt_signed", "task_func_args_opt", "$@17", "$@18", "task_func_args",
  "task_func_port", "$@19", "task_func_body", "param_signed",
  "param_integer", "param_real", "param_range", "param_decl", "$@20",
  "localparam_decl", "$@21", "param_decl_list", "single_param_decl",
  "defparam_decl", "defparam_decl_list", "single_defparam_decl",
  "wire_decl", "$@22", "$@23", "wire_name_list",
  "wire_name_and_opt_assign", "wire_name", "assign_stmt",
  "assign_expr_list", "assign_expr", "cell_stmt", "$@24", "$@25",
  "tok_prim_wrapper", "cell_list", "single_cell", "$@26", "$@27",
  "prim_list", "single_prim", "$@28", "cell_parameter_list_opt",
  "cell_parameter_list", "cell_parameter", "cell_port_list", "$@29",
  "cell_port", "always_stmt", "$@30", "$@31", "$@32", "always_cond",
  "always_events", "always_event", "opt_label", "assert",
  "assert_property", "simple_behavioral_stmt", "behavioral_stmt", "$@33",
  "$@34", "$@35", "$@36", "$@37", "$@38", "$@39", "$@40", "$@41",
  "case_type", "opt_synopsys_attr", "behavioral_stmt_opt",
  "behavioral_stmt_list", "optional_else", "$@42", "case_body",
  "case_item", "$@43", "$@44", "gen_case_body", "gen_case_item", "$@45",
  "$@46", "case_select", "case_expr_list", "rvalue", "lvalue",
  "lvalue_concat_list", "opt_arg_list", "arg_list", "arg_list2",
  "single_arg", "module_gen_body", "gen_stmt_or_module_body_stmt",
  "gen_stmt", "$@47", "$@48", "$@49", "$@50", "$@51", "gen_stmt_block",
  "$@52", "gen_stmt_or_null", "opt_gen_else", "expr", "basic_expr", "$@53",
  "concat_list", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   124,   318,    94,   319,    38,   320,   321,
     322,   323,   324,    60,   325,   326,    62,   327,   328,   329,
     330,    43,    45,    42,    47,    37,   331,   332,    44,    61,
      46,    59,    35,    40,    41,    91,    58,    93,    64,   123,
     125,    63,   126,    33
};
# endif

#define YYPACT_NINF -521

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-521)))

#define YYTABLE_NINF -252

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    -521,    44,    28,  -521,  -521,  -521,    19,  -521,    28,    28,
      28,    42,    62,    71,    54,    98,   161,  -521,  -521,  -521,
    -521,  -521,    40,  -521,   117,  -521,    14,  -521,    18,  -521,
      42,   173,    42,   864,   182,   103,  -521,   193,   197,  -521,
     864,  -521,  -521,   204,   119,   207,  -521,  -521,  -521,   213,
    -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,
    -521,   864,   864,  -521,  -521,   167,  -521,  -521,   962,  -521,
     129,   139,   144,   224,   145,     3,  -521,   159,   174,  -521,
    -521,   165,   168,   864,   864,   864,   864,   864,   864,   864,
     864,   180,   -47,   176,   864,   864,  -521,   864,  -521,   183,
     183,  -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,
    -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,
    -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,    11,   186,
     275,   192,  -521,   280,   864,   864,   864,  -521,   119,  -521,
     281,  -521,   864,   864,  -521,  -521,  -521,  -521,  -521,  -521,
    -521,  -521,   284,   864,   864,  -521,  -521,  -521,   124,   194,
    -521,  -521,   864,   864,   864,   864,   864,   864,   864,   864,
     864,   864,   864,   864,   864,   864,   864,   864,   864,   864,
     864,   864,   864,   864,   864,   864,   864,    41,  -521,   196,
    -521,  -521,   203,  -521,  -521,   297,  -521,   -31,  -521,   144,
     300,   208,   209,   210,   217,   183,  -521,   222,  -521,  -521,
      12,   223,   225,  -521,   228,  -521,   226,   233,   864,   995,
    1019,  1041,  1061,  1061,  1079,  1093,  1093,  1093,  1093,   460,
     460,   460,   460,   371,   371,   371,   371,   163,   163,   242,
     242,   242,  -521,   234,   240,  -521,  -521,   246,  -521,   250,
     251,   183,   221,    22,   248,   489,  -521,   275,  -521,   249,
    -521,  -521,  -521,  -521,  -521,   183,  -521,  -521,   183,     0,
    -521,  -521,   253,   864,   282,  -521,   120,  -521,  -521,   252,
    -521,  -521,   -42,  -521,  -521,   247,    42,   260,  -521,  -521,
    -521,   864,   864,   326,   257,    41,   864,  -521,  -521,   356,
    -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,   221,  -521,
    -521,  -521,  -521,  -521,  -521,   183,   864,   267,   271,   272,
    -521,  -521,  -521,  -521,   306,   406,  -521,  -521,  -521,  -521,
    -521,  -521,  -521,  -521,  -521,  -521,  -521,   276,  -521,  -521,
    -521,   144,   160,  -521,  -521,   278,   864,   273,   286,   267,
     283,   285,   288,   292,   382,   385,   183,   301,  -521,  -521,
     864,   864,  -521,    81,  -521,   864,   296,  -521,  -521,  -521,
     373,  -521,  -521,  -521,  -521,  -521,   326,   326,    42,   -32,
    -521,   -15,  -521,   304,   392,  -521,   864,  -521,   574,   309,
    -521,  -521,  -521,  -521,  -521,  -521,   864,   308,  -521,   281,
    -521,   303,  -521,   864,  -521,   864,  -521,   864,   864,   312,
     313,  -521,   864,   314,  -521,  -521,  -521,  -521,  -521,   183,
     250,   373,   373,   141,   183,  -521,   864,  -521,   864,  -521,
    -521,   311,    -2,  -521,  -521,  -521,  -521,   864,   316,   318,
      64,   407,   320,  -521,  -521,   321,  -521,  -521,   323,    -2,
     324,   325,  -521,  -521,   281,   328,   864,   329,  -521,   419,
    -521,   374,   374,   864,  -521,  -521,  -521,   944,  -521,   335,
     333,   337,   407,    96,  -521,  -521,   183,  -521,    97,  -521,
     340,  -521,  -521,   170,  -521,   343,  -521,  -521,   348,  -521,
     350,  -521,   260,  -521,  -521,  -521,   183,   183,  -521,   267,
    -521,   864,   346,   782,   105,  -521,   347,  -521,   634,    64,
    -521,   349,   407,  -521,   675,  -521,   267,  -521,    64,   864,
      64,    64,   281,   353,   864,  -521,   351,   419,   419,  -521,
     416,   971,  -521,  -521,   444,   364,   362,  -521,   407,  -521,
    -521,  -521,   864,   864,   369,   123,  -521,  -521,  -521,   372,
     675,  -521,  -521,   463,   370,   380,  -521,   428,  -521,   440,
    -521,  -521,  -521,  -521,  -521,  -521,    37,  -521,   135,  -521,
     136,   383,  -521,  -521,   386,   378,  -521,   782,  -521,  -521,
    -521,  -521,   716,   716,  -521,   675,   387,   675,   389,  -521,
     675,  -521,  -521,   823,  -521,  -521,   394,  -521,  -521,   435,
     419,  -521,  -521,  -521,  -521,  -521,    -2,   864,  -521,  -521,
    -521,   393,  -521,  -521,   289,  -521,   -46,  -521,    21,  -521,
      64,    -2,  -521,  -521,   823,  -521,   395,   396,  -521,  -521,
     398,   383,   864,  -521,  -521,   399,  -521,  -521,  -521,  -521,
    -521,  -521,  -521,   114,  -521,    64,  -521,  -521,  -521,  -521
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       2,     0,     8,     1,    12,     3,     0,    11,     8,     8,
       8,    16,     0,     0,   106,     0,     9,     5,     4,     6,
      21,    13,    15,    17,    19,    23,     0,   105,    68,    93,
      16,     0,     0,     0,     0,    28,    87,     0,     0,    72,
       0,    67,    71,     0,   108,     0,    14,    18,   295,   293,
     294,     8,     8,     8,     8,     8,     8,     8,     8,     8,
       8,     0,     0,     8,     8,    68,   289,    20,   287,    22,
       0,    36,   100,     0,     0,     0,    95,   109,     0,    10,
     292,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   337,     0,     0,     0,   291,     0,   296,    67,
     256,   255,     8,     8,     8,     8,     8,     8,     8,     8,
       8,     8,     8,     8,     8,     8,     8,     8,     8,     8,
       8,     8,     8,     8,     8,     8,     8,    25,     8,     0,
     104,     0,    89,     0,     0,     0,     0,    64,   108,   107,
       8,   118,     0,     0,   310,   311,   312,   313,   308,   309,
     332,   333,   300,     0,     0,   301,   303,   336,     0,     0,
      65,    66,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    31,    44,     0,
      35,    49,    41,    38,    75,    98,   103,     0,    88,   100,
       0,     0,     0,     0,     0,    68,    49,    41,   112,   116,
       8,     0,     0,   290,   337,   338,     0,    64,   264,   335,
     334,   305,   306,   307,   304,   320,   321,   322,   323,   318,
     319,   324,   325,   314,   315,   316,   317,   326,   327,   328,
     329,   330,   331,     0,     0,    32,    26,    29,    34,    43,
       0,    68,     0,     8,     0,     8,    97,   102,    99,     0,
      91,    62,    63,    61,   118,    70,    69,   146,    68,     8,
     110,    94,     0,     0,    49,   206,     8,   208,   207,     0,
     117,   257,     0,   298,   299,     0,     0,    41,   263,   265,
     267,     0,     0,   120,     0,    31,     0,    45,    48,     0,
      53,    54,    55,    56,    57,    58,    60,    59,    50,    51,
      39,    37,    24,   126,   128,    68,     0,   201,     0,     0,
     226,   227,   228,   269,     0,    49,    85,    73,    76,    77,
      78,    79,    80,    81,    82,    83,    86,     0,    74,   101,
      90,   100,     8,   114,   113,     0,     0,     0,   259,   201,
       0,     0,     0,     0,     0,     0,    68,     0,   210,   209,
       0,     0,   302,    68,   254,    40,     0,   288,   132,   119,
     122,    27,    30,    42,    46,    52,   120,   120,     0,     0,
     134,     0,   148,     0,     0,   279,     0,   272,     8,     0,
     151,   155,   183,   186,   156,   153,     0,     0,    96,     0,
     111,     0,   258,     0,   212,     0,   214,     0,     0,     0,
       0,   137,     0,   262,   205,   204,   266,   297,   121,    68,
      43,   122,   122,     0,    68,   133,     0,   147,     0,   200,
     269,     0,     0,    84,   271,   268,   270,     0,   169,   193,
       8,   166,     0,    92,   115,     0,   260,   235,     0,     0,
       0,     0,   140,   141,     0,     0,   264,     0,   125,     0,
      47,   124,   124,     0,   135,   149,   150,     8,   275,     0,
       0,     0,     0,     0,   184,   187,   159,   165,     0,   163,
       0,   277,   202,     8,   222,     0,   218,   220,   138,   142,
     144,   224,    41,   211,    33,   123,    68,    68,   136,   201,
     281,     0,     0,   170,     0,   157,     0,   192,     0,     8,
     161,     0,   166,   154,   175,   245,   201,   234,     8,     0,
       8,     8,     0,     0,     0,   231,     0,     0,     0,   280,
     286,     8,   273,   203,     0,     0,   171,   173,     0,   152,
     190,   191,     0,     0,     0,     0,   194,   199,   185,     0,
     175,   164,   178,     0,     0,   176,   180,   246,   213,   238,
     215,   219,   221,   143,   139,   145,   240,   261,     0,   130,
       0,   281,   276,   282,     0,     0,   168,   170,   158,   197,
     198,   189,     0,     0,   188,   175,     0,   175,     0,   167,
     175,   278,   244,     0,   236,   223,     0,   229,   230,   241,
       0,   127,   129,   284,   283,   285,     0,     0,   172,   195,
     196,     0,   160,   179,     0,   177,   250,   247,     0,   252,
       8,     0,   225,   239,     0,   131,     0,     0,   162,   182,
       0,   281,     0,   249,   237,     0,   242,   281,   174,   181,
     248,   253,   216,     8,   274,     8,   233,   232,   243,   217
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -521,  -521,  -521,   111,    27,  -521,  -521,    -1,  -521,  -521,
     453,  -521,   456,   -11,  -521,  -521,  -521,  -521,  -521,   200,
    -521,  -521,  -521,  -521,  -194,    77,   255,  -521,  -521,  -152,
    -521,  -521,   198,   -51,   295,   -18,  -521,  -521,  -521,   256,
    -232,  -521,  -521,  -521,  -521,  -521,   244,  -182,  -521,  -521,
     379,  -521,  -521,  -521,   243,  -521,   258,  -125,  -166,    57,
    -230,  -521,  -521,  -521,  -521,    -7,  -432,  -521,  -521,    99,
    -231,  -521,  -521,  -521,     2,  -356,  -521,  -521,   100,  -521,
    -521,  -521,  -521,  -521,  -466,  -521,  -521,  -521,    13,  -521,
    -521,   -45,  -521,  -520,  -521,  -521,  -521,  -521,  -521,  -521,
    -521,  -521,  -311,  -338,  -521,  -521,  -429,  -318,  -521,  -521,
    -521,  -521,  -521,  -521,  -521,  -521,  -521,   259,  -521,  -521,
    -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,  -521,
    -521,   -93,  -521,  -159,  -521,   131,  -521,    79,  -521,   185,
     121,    16,   298,  -521,  -521,  -521,  -521,  -521,  -475,  -521,
     -79,  -521,   -28,   483,  -521,   403
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,     2,     5,   274,     7,    16,   275,    11,    31,
      21,    22,    23,    65,     9,    35,    71,   187,   294,   246,
     247,   293,   129,   192,   254,   297,   193,   249,   420,   356,
     252,   308,   309,    41,   100,   101,   267,    43,   255,   434,
      10,    72,   199,   341,    44,   138,   196,   131,   197,    28,
      78,   140,   345,   207,   208,   399,   210,   370,   419,   496,
     459,   329,   376,   330,   377,   568,   248,   331,   379,   380,
     277,   454,   523,   488,   489,   209,   333,   381,   382,   334,
     438,   441,   395,   504,   477,   511,   549,   478,   479,   480,
     472,   535,   536,   554,   587,   555,   335,   439,   509,   440,
     474,   545,   546,   385,   278,   336,   279,   280,   413,   447,
     449,   596,   645,   520,   521,   518,   525,   337,   566,   648,
     483,   595,   620,   599,   623,   624,   643,   557,   592,   593,
     631,   617,   618,    66,   282,   347,   457,   287,   288,   289,
     388,   435,   436,   432,   574,   500,   515,   430,   604,   531,
     605,   572,   556,    68,   159,    93
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      24,     8,    20,   469,   205,    67,   505,     8,     8,     8,
      42,   404,    75,   270,    99,   188,    20,   259,    36,    24,
     485,    24,     4,   328,   332,   530,   188,   494,    -7,     6,
     586,    12,   360,    91,    92,     6,     6,     6,     4,   251,
      39,   153,  -251,   444,     3,   244,    20,   361,   160,   161,
    -251,   281,   154,    13,   268,   245,   424,   257,   271,   425,
     134,   135,    14,   258,    15,   611,    25,   613,    20,   158,
     615,   272,   578,   426,     4,    26,   427,    27,    81,    82,
      83,    84,    85,    86,    87,    88,    89,    90,   597,   598,
      94,    95,    98,   366,   -40,   569,   569,   273,   490,   136,
     137,   189,    29,    37,   506,   190,   201,   202,   203,   632,
      38,   273,   189,    40,   211,   212,   -40,   633,    20,    17,
      18,    19,   475,   272,     4,   214,   216,   364,    32,   162,
     163,   164,   165,   166,   167,   168,   169,   170,   171,   172,
     173,   174,   175,   176,   177,   178,   179,   180,   181,   182,
     183,   184,   185,   186,    99,   191,   328,   332,   243,   397,
     582,   529,   644,   273,    20,   517,   490,   206,   625,    30,
       4,    34,    96,   272,    20,    -8,    97,   626,   558,   507,
       4,   134,   135,   281,    46,   512,    69,   266,   513,   508,
     290,   548,   635,   538,   -68,    70,   539,    73,   516,   276,
     559,    74,   561,   562,   398,   646,    33,    34,    76,   -68,
      34,   583,    77,   273,   161,    97,    79,   584,    80,   272,
     136,   217,   127,   600,   600,    99,   601,   602,   132,   272,
     463,    34,   128,   299,   133,   328,   332,   130,   300,   301,
     302,   303,   304,   305,   306,   348,   122,   123,   124,   125,
     343,   421,   422,   139,   326,   461,   462,    34,   142,   273,
      -8,   143,    97,   367,   368,   141,   527,   528,   373,   273,
     307,   609,   610,   281,   152,   363,   155,   194,    40,   195,
     191,   281,   325,   198,   200,   205,   250,   218,   383,   213,
     281,   253,    48,    20,    49,    50,   206,   378,   526,   328,
     332,   256,   634,   358,   260,   261,   262,   263,   264,   349,
     269,   350,    99,   351,   352,   353,   153,   283,   401,   284,
     320,   321,   322,   286,   281,   647,   285,   649,   125,   292,
     291,   276,   414,   415,   295,   354,   355,   290,   411,   296,
     340,   298,   311,   359,    51,    52,   346,   362,   365,   369,
     281,   371,    53,    54,    55,    56,    57,    58,   431,   281,
     374,   281,   281,   384,   386,   387,   389,   423,   442,   396,
      59,    60,   400,   402,   403,   348,   405,   448,   406,   450,
     451,   407,    61,   629,   455,   408,   409,   326,    62,   410,
     417,    63,    64,   428,   412,   418,   429,   445,   383,   443,
     466,   458,   437,   452,   453,   468,   378,   456,   471,   470,
     390,   476,   482,   391,   481,   325,   473,   484,   486,   487,
     493,   363,   491,   244,   495,   510,   501,   502,   290,   276,
     503,   392,   393,   514,   519,   498,   522,   533,   363,   524,
      13,   540,   550,   394,   564,   567,   571,   281,   575,    14,
     577,    15,   120,   121,   122,   123,   124,   125,   576,   354,
     355,   281,   281,   581,   589,   585,   326,   588,   590,   591,
     594,   607,   276,   532,   603,   537,   622,   606,   458,   458,
     547,   612,   614,    45,   281,   621,   281,   628,    47,   637,
     638,   560,   639,   642,   325,   372,   565,   460,   276,     4,
     265,   339,   312,   313,   314,   315,   375,   276,   310,   276,
     276,   327,   344,   316,   579,   580,   317,   204,   318,   497,
     319,   570,   342,   464,   563,   551,   465,   320,   321,   322,
     326,   636,   608,   357,   446,   492,   323,   116,   117,   118,
     119,   120,   121,   122,   123,   124,   125,   573,   324,   537,
     416,   467,   640,   338,   547,   547,   215,     0,   325,     0,
       0,     0,     0,     0,     0,   619,   144,   145,   146,   147,
     148,   149,   150,   151,     0,     0,     0,   156,   157,   627,
       0,     0,     0,     0,     4,     0,   630,     0,   313,   314,
     315,     0,     0,     0,     0,   363,   619,     0,   316,     0,
       0,   317,     0,   318,   641,   319,     0,     0,     0,   276,
     363,     0,   320,   321,   322,     0,     0,     0,     0,     0,
       0,   323,   433,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   276,   324,   276,     0,     0,    48,    20,    49,
      50,     0,     0,   541,     0,   219,   220,   221,   222,   223,
     224,   225,   226,   227,   228,   229,   230,   231,   232,   233,
     234,   235,   236,   237,   238,   239,   240,   241,   242,   542,
     543,     0,     0,     0,     0,     0,     0,     0,    48,    20,
      49,    50,     0,     0,     0,     0,     0,     0,     0,    51,
      52,     0,     0,     0,     0,     0,     0,    53,    54,    55,
      56,    57,    58,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    59,    60,   544,     0,    48,
      20,    49,    50,     0,     0,     0,     0,    61,     0,     0,
      51,    52,     0,    62,     0,     0,    63,    64,    53,    54,
      55,    56,    57,    58,     0,     0,     0,     0,     0,     0,
       0,   542,   543,     0,     0,     0,    59,    60,     0,     0,
       0,     0,     0,   552,     0,   553,     0,     0,    61,     0,
       0,    51,    52,     0,    62,     0,     0,    63,    64,    53,
      54,    55,    56,    57,    58,    48,    20,    49,    50,     0,
       0,     0,     0,     0,     0,     0,     0,    59,    60,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    61,
       0,     0,     0,     0,     0,    62,     0,     0,    63,    64,
       0,     0,     0,     0,     0,     0,    48,    20,    49,    50,
       0,     0,     0,     0,     0,     0,     0,    51,    52,     0,
       0,     0,     0,     0,     0,    53,    54,    55,    56,    57,
      58,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    59,    60,   616,     0,    48,    20,    49,
      50,     0,   534,     0,     0,    61,     0,     0,    51,    52,
       0,    62,     0,     0,    63,    64,    53,    54,    55,    56,
      57,    58,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    59,    60,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    61,     0,     0,    51,
      52,     0,    62,     0,     0,    63,    64,    53,    54,    55,
      56,    57,    58,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    59,    60,     0,     0,     0,
       0,     0,     0,     0,     4,     0,     0,    61,   313,   314,
     315,     0,     0,    62,     0,     0,    63,    64,   316,     0,
       0,   317,   499,   318,     0,   319,     0,     0,     0,     0,
       0,     4,   320,   321,   322,   313,   314,   315,     0,     0,
       0,   323,     0,     0,     0,   316,     0,     0,   317,     0,
     318,     0,   319,   324,     0,     0,     0,     0,     0,   320,
     321,   322,     0,     0,     0,     0,     0,     0,   323,     0,
       0,     0,     0,   102,   103,   104,     0,   105,   106,   107,
     324,   108,   109,   110,   111,   112,   113,   114,   115,   116,
     117,   118,   119,   120,   121,   122,   123,   124,   125,     0,
       0,     0,     0,     0,     0,     0,     0,   103,   104,     0,
     105,   106,   107,   126,   108,   109,   110,   111,   112,   113,
     114,   115,   116,   117,   118,   119,   120,   121,   122,   123,
     124,   125,   104,     0,   105,   106,   107,     0,   108,   109,
     110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
     120,   121,   122,   123,   124,   125,   105,   106,   107,     0,
     108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
     118,   119,   120,   121,   122,   123,   124,   125,   107,     0,
     108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
     118,   119,   120,   121,   122,   123,   124,   125,   108,   109,
     110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
     120,   121,   122,   123,   124,   125,   112,   113,   114,   115,
     116,   117,   118,   119,   120,   121,   122,   123,   124,   125
};

static const yytype_int16 yycheck[] =
{
      11,     2,     4,   432,     4,    33,   472,     8,     9,    10,
      28,   349,    40,   207,    65,     4,     4,   199,     4,    30,
     449,    32,    10,   255,   255,   500,     4,   459,     0,     2,
     550,    12,    74,    61,    62,     8,     9,    10,    10,   191,
      22,    88,    88,   399,     0,     4,     4,    89,    99,   100,
      96,   210,    99,    34,   206,    14,    88,    88,    46,    91,
      57,    58,    43,    94,    45,   585,     4,   587,     4,    97,
     590,    59,   538,    88,    10,     4,    91,    23,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    51,    52,
      63,    64,    65,   287,    94,   527,   528,    99,   454,    96,
      97,    90,     4,    89,     8,    94,   134,   135,   136,    88,
      96,    99,    90,    95,   142,   143,    94,    96,     4,     8,
       9,    10,   440,    59,    10,   153,   154,   286,    88,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
     113,   114,   115,   116,   117,   118,   119,   120,   121,   122,
     123,   124,   125,   126,   205,   128,   388,   388,   186,   341,
      37,   499,   637,    99,     4,   483,   522,   140,   600,     8,
      10,    90,     5,    59,     4,     8,    95,   606,   516,    83,
      10,    57,    58,   342,    11,    88,     4,   205,    91,    93,
     218,   509,   621,    88,    74,    92,    91,     4,    28,   210,
     518,     4,   520,   521,    44,    91,    89,    90,     4,    89,
      90,    88,    93,    99,   265,    95,     9,    94,     5,    59,
      96,    97,    93,    88,    88,   276,    91,    91,     4,    59,
      89,    90,    93,   251,    89,   467,   467,    93,    17,    18,
      19,    20,    21,    22,    23,   273,    83,    84,    85,    86,
     268,   376,   377,    94,   255,   421,   422,    90,    93,    99,
      93,    93,    95,   291,   292,    91,   496,   497,   296,    99,
      49,   582,   583,   432,    94,   286,   100,    91,    95,     4,
     253,   440,   255,    91,     4,     4,    90,    93,   316,     5,
     449,    88,     3,     4,     5,     6,   269,   315,   492,   531,
     531,     4,   620,   276,     4,    97,    97,    97,    91,    27,
      88,    29,   363,    31,    32,    33,    88,    94,   346,    94,
      38,    39,    40,    90,   483,   643,   100,   645,    86,    89,
      96,   342,   360,   361,    88,    53,    54,   365,   356,    89,
      91,    90,    94,    91,    55,    56,    93,   100,    88,    23,
     509,    94,    63,    64,    65,    66,    67,    68,   386,   518,
       4,   520,   521,    96,    93,    93,    60,   378,   396,    93,
      81,    82,    94,   100,    88,   403,    93,   405,    93,   407,
     408,    93,    93,    94,   412,    93,     4,   388,    99,     4,
      94,   102,   103,    89,    93,    22,     4,    94,   426,    91,
     428,   419,    93,    91,    91,    94,   424,    93,    92,   437,
       4,     4,    91,     7,    94,   388,    98,    94,    94,    94,
      91,   432,    94,     4,    50,   476,    91,    94,   456,   440,
      93,    25,    26,    93,    91,   463,    88,    91,   449,    89,
      34,    94,    93,    37,    91,    94,    30,   606,     4,    43,
      88,    45,    81,    82,    83,    84,    85,    86,    94,    53,
      54,   620,   621,    94,    94,    93,   467,     4,    88,    41,
      30,    93,   483,   501,    91,   503,    41,    91,   496,   497,
     508,    94,    93,    30,   643,    91,   645,    94,    32,    94,
      94,   519,    94,    94,   467,   295,   524,   420,   509,    10,
     205,   257,    13,    14,    15,    16,   308,   518,   253,   520,
     521,   255,   269,    24,   542,   543,    27,   138,    29,   462,
      31,   528,   264,   424,   522,   512,   426,    38,    39,    40,
     531,   624,   577,   274,   403,   456,    47,    77,    78,    79,
      80,    81,    82,    83,    84,    85,    86,   531,    59,   577,
     365,   430,   631,   255,   582,   583,   153,    -1,   531,    -1,
      -1,    -1,    -1,    -1,    -1,   593,    83,    84,    85,    86,
      87,    88,    89,    90,    -1,    -1,    -1,    94,    95,   607,
      -1,    -1,    -1,    -1,    10,    -1,   614,    -1,    14,    15,
      16,    -1,    -1,    -1,    -1,   606,   624,    -1,    24,    -1,
      -1,    27,    -1,    29,   632,    31,    -1,    -1,    -1,   620,
     621,    -1,    38,    39,    40,    -1,    -1,    -1,    -1,    -1,
      -1,    47,    48,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   643,    59,   645,    -1,    -1,     3,     4,     5,
       6,    -1,    -1,     9,    -1,   162,   163,   164,   165,   166,
     167,   168,   169,   170,   171,   172,   173,   174,   175,   176,
     177,   178,   179,   180,   181,   182,   183,   184,   185,    35,
      36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,     4,
       5,     6,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    55,
      56,    -1,    -1,    -1,    -1,    -1,    -1,    63,    64,    65,
      66,    67,    68,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    82,    83,    -1,     3,
       4,     5,     6,    -1,    -1,    -1,    -1,    93,    -1,    -1,
      55,    56,    -1,    99,    -1,    -1,   102,   103,    63,    64,
      65,    66,    67,    68,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    35,    36,    -1,    -1,    -1,    81,    82,    -1,    -1,
      -1,    -1,    -1,    88,    -1,    90,    -1,    -1,    93,    -1,
      -1,    55,    56,    -1,    99,    -1,    -1,   102,   103,    63,
      64,    65,    66,    67,    68,     3,     4,     5,     6,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    81,    82,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    93,
      -1,    -1,    -1,    -1,    -1,    99,    -1,    -1,   102,   103,
      -1,    -1,    -1,    -1,    -1,    -1,     3,     4,     5,     6,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    55,    56,    -1,
      -1,    -1,    -1,    -1,    -1,    63,    64,    65,    66,    67,
      68,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    81,    82,    42,    -1,     3,     4,     5,
       6,    -1,    90,    -1,    -1,    93,    -1,    -1,    55,    56,
      -1,    99,    -1,    -1,   102,   103,    63,    64,    65,    66,
      67,    68,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    81,    82,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    93,    -1,    -1,    55,
      56,    -1,    99,    -1,    -1,   102,   103,    63,    64,    65,
      66,    67,    68,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    81,    82,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    10,    -1,    -1,    93,    14,    15,
      16,    -1,    -1,    99,    -1,    -1,   102,   103,    24,    -1,
      -1,    27,    28,    29,    -1,    31,    -1,    -1,    -1,    -1,
      -1,    10,    38,    39,    40,    14,    15,    16,    -1,    -1,
      -1,    47,    -1,    -1,    -1,    24,    -1,    -1,    27,    -1,
      29,    -1,    31,    59,    -1,    -1,    -1,    -1,    -1,    38,
      39,    40,    -1,    -1,    -1,    -1,    -1,    -1,    47,    -1,
      -1,    -1,    -1,    61,    62,    63,    -1,    65,    66,    67,
      59,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    62,    63,    -1,
      65,    66,    67,   101,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    63,    -1,    65,    66,    67,    -1,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    86,    65,    66,    67,    -1,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    85,    86,    67,    -1,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    85,    86,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    86,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    83,    84,    85,    86
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,   105,   106,     0,    10,   107,   108,   109,   111,   118,
     144,   112,    12,    34,    43,    45,   110,   107,   107,   107,
       4,   114,   115,   116,   117,     4,     4,    23,   153,     4,
       8,   113,    88,    89,    90,   119,     4,    89,    96,    22,
      95,   137,   139,   141,   148,   114,    11,   116,     3,     5,
       6,    55,    56,    63,    64,    65,    66,    67,    68,    81,
      82,    93,    99,   102,   103,   117,   237,   256,   257,     4,
      92,   120,   145,     4,     4,   256,     4,    93,   154,     9,
       5,   108,   108,   108,   108,   108,   108,   108,   108,   108,
     108,   256,   256,   259,   108,   108,     5,    95,   108,   137,
     138,   139,    61,    62,    63,    65,    66,    67,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    86,   101,    93,    93,   126,
      93,   151,     4,    89,    57,    58,    96,    97,   149,    94,
     155,    91,    93,    93,   257,   257,   257,   257,   257,   257,
     257,   257,    94,    88,    99,   100,   257,   257,   256,   258,
     137,   137,   108,   108,   108,   108,   108,   108,   108,   108,
     108,   108,   108,   108,   108,   108,   108,   108,   108,   108,
     108,   108,   108,   108,   108,   108,   108,   121,     4,    90,
      94,   108,   127,   130,    91,     4,   150,   152,    91,   146,
       4,   256,   256,   256,   154,     4,   108,   157,   158,   179,
     160,   256,   256,     5,   256,   259,   256,    97,    93,   257,
     257,   257,   257,   257,   257,   257,   257,   257,   257,   257,
     257,   257,   257,   257,   257,   257,   257,   257,   257,   257,
     257,   257,   257,   256,     4,    14,   123,   124,   170,   131,
      90,   133,   134,    88,   128,   142,     4,    88,    94,   151,
       4,    97,    97,    97,    91,   138,   139,   140,   133,    88,
     128,    46,    59,    99,   108,   111,   117,   174,   208,   210,
     211,   237,   238,    94,    94,   100,    90,   241,   242,   243,
     256,    96,    89,   125,   122,    88,    89,   129,    90,   139,
      17,    18,    19,    20,    21,    22,    23,    49,   135,   136,
     130,    94,    13,    14,    15,    16,    24,    27,    29,    31,
      38,    39,    40,    47,    59,   108,   111,   143,   144,   165,
     167,   171,   174,   180,   183,   200,   209,   221,   246,   150,
      91,   147,   160,   139,   158,   156,    93,   239,   256,    27,
      29,    31,    32,    33,    53,    54,   133,   221,   108,    91,
      74,    89,   100,   117,   237,    88,   128,   256,   256,    23,
     161,    94,   123,   256,     4,   136,   166,   168,   139,   172,
     173,   181,   182,   256,    96,   207,    93,    93,   244,    60,
       4,     7,    25,    26,    37,   186,    93,   151,    44,   159,
      94,   256,   100,    88,   207,    93,    93,    93,    93,     4,
       4,   139,    93,   212,   256,   256,   243,    94,    22,   162,
     132,   161,   161,   117,    88,    91,    88,    91,    89,     4,
     251,   256,   247,    48,   143,   245,   246,    93,   184,   201,
     203,   185,   256,    91,   179,    94,   239,   213,   256,   214,
     256,   256,    91,    91,   175,   256,    93,   240,   139,   164,
     129,   162,   162,    89,   173,   182,   256,   244,    94,   210,
     256,    92,   194,    98,   204,   211,     4,   188,   191,   192,
     193,    94,    91,   224,    94,   210,    94,    94,   177,   178,
     179,    94,   241,    91,   170,    50,   163,   163,   256,    28,
     249,    91,    94,    93,   187,   188,     8,    83,    93,   202,
     137,   189,    88,    91,    93,   250,    28,   211,   219,    91,
     217,   218,    88,   176,    89,   220,   128,   164,   164,   207,
     252,   253,   256,    91,    90,   195,   196,   256,    88,    91,
      94,     9,    35,    36,    83,   205,   206,   256,   211,   190,
      93,   192,    88,    90,   197,   199,   256,   231,   207,   211,
     256,   211,   211,   178,    91,   256,   222,    94,   169,   170,
     169,    30,   255,   245,   248,     4,    94,    88,   188,   256,
     256,    94,    37,    88,    94,    93,   197,   198,     4,    94,
      88,    41,   232,   233,    30,   225,   215,    51,    52,   227,
      88,    91,    91,    91,   252,   254,    91,    93,   195,   206,
     206,   197,    94,   197,    93,   197,    42,   235,   236,   256,
     226,    91,    41,   228,   229,   170,   210,   256,    94,    94,
     256,   234,    88,    96,   211,   210,   235,    94,    94,    94,
     254,   256,    94,   230,   252,   216,    91,   211,   223,   211
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   104,   106,   105,   107,   107,   107,   107,   109,   108,
     110,   110,   112,   113,   111,   114,   114,   115,   115,   116,
     116,   117,   117,   119,   118,   121,   122,   120,   120,   123,
     123,   123,   125,   124,   124,   126,   126,   126,   127,   127,
     128,   128,   129,   129,   131,   130,   132,   130,   130,   134,
     133,   135,   135,   136,   136,   136,   136,   136,   136,   136,
     136,   137,   137,   137,   137,   138,   138,   139,   139,   140,
     140,   141,   141,   142,   142,   142,   143,   143,   143,   143,
     143,   143,   143,   143,   143,   143,   143,   145,   144,   146,
     144,   147,   144,   148,   144,   149,   144,   150,   150,   151,
     151,   152,   152,   152,   152,   153,   153,   154,   154,   155,
     156,   154,   157,   157,   159,   158,   158,   160,   160,   161,
     161,   162,   162,   163,   163,   164,   166,   165,   168,   167,
     169,   169,   170,   171,   172,   172,   173,   175,   176,   174,
     174,   174,   177,   177,   178,   178,   179,   180,   181,   181,
     182,   184,   183,   185,   183,   186,   186,   187,   187,   189,
     188,   190,   188,   191,   191,   192,   193,   192,   194,   194,
     195,   195,   195,   196,   196,   197,   197,   197,   198,   197,
     199,   199,   199,   201,   202,   200,   203,   200,   204,   204,
     204,   204,   204,   204,   205,   205,   205,   206,   206,   206,
     207,   207,   208,   209,   210,   210,   211,   211,   211,   211,
     212,   211,   213,   211,   214,   215,   216,   211,   217,   211,
     218,   211,   219,   211,   220,   211,   221,   221,   221,   222,
     222,   222,   223,   223,   224,   224,   226,   225,   225,   227,
     227,   229,   230,   228,   231,   231,   233,   234,   232,   235,
     235,   236,   236,   236,   237,   237,   237,   238,   238,   239,
     239,   240,   240,   241,   241,   242,   242,   243,   244,   244,
     245,   245,   247,   248,   246,   249,   246,   250,   246,   251,
     246,   253,   252,   254,   254,   255,   255,   256,   256,   257,
     257,   257,   257,   257,   257,   257,   258,   257,   257,   257,
     257,   257,   257,   257,   257,   257,   257,   257,   257,   257,
     257,   257,   257,   257,   257,   257,   257,   257,   257,   257,
     257,   257,   257,   257,   257,   257,   257,   257,   257,   257,
     257,   257,   257,   257,   257,   257,   257,   259,   259
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     0,     2,     2,     2,     2,     0,     0,     2,
       4,     0,     0,     0,     5,     1,     0,     1,     3,     1,
       3,     1,     3,     0,     9,     0,     0,     6,     0,     1,
       3,     0,     0,     6,     1,     2,     0,     4,     1,     3,
       1,     0,     2,     0,     0,     3,     0,     6,     3,     0,
       2,     1,     2,     1,     1,     1,     1,     1,     1,     1,
       1,     5,     5,     5,     3,     2,     2,     1,     0,     1,
       1,     1,     1,     2,     2,     0,     1,     1,     1,     1,
       1,     1,     1,     1,     3,     1,     1,     0,     7,     0,
       9,     0,    11,     0,     8,     0,    10,     2,     1,     3,
       0,     3,     2,     1,     0,     1,     0,     2,     0,     0,
       0,     6,     1,     3,     0,     5,     1,     2,     0,     1,
       0,     1,     0,     1,     0,     1,     0,     8,     0,     8,
       1,     3,     3,     3,     1,     3,     4,     0,     0,     7,
       4,     4,     1,     3,     1,     3,     2,     3,     1,     3,
       3,     0,     6,     0,     5,     1,     1,     1,     3,     0,
       5,     0,     6,     1,     3,     1,     0,     4,     4,     0,
       0,     1,     3,     1,     5,     0,     1,     3,     0,     3,
       1,     5,     4,     0,     0,     6,     0,     4,     4,     4,
       3,     3,     2,     0,     1,     3,     3,     2,     2,     1,
       2,     0,     5,     6,     3,     3,     1,     1,     1,     2,
       0,     5,     0,     7,     0,     0,     0,    13,     0,     7,
       0,     7,     0,     8,     0,     9,     1,     1,     1,     2,
       2,     0,     1,     1,     2,     0,     0,     3,     0,     2,
       0,     0,     0,     4,     2,     0,     0,     0,     4,     2,
       1,     1,     1,     3,     6,     2,     2,     1,     3,     1,
       3,     4,     0,     1,     0,     1,     3,     1,     2,     0,
       1,     1,     0,     0,    11,     0,     7,     0,     7,     0,
       6,     0,     2,     1,     1,     2,     0,     1,     6,     1,
       4,     2,     2,     1,     1,     1,     0,     7,     5,     5,
       3,     3,     6,     3,     4,     4,     4,     4,     3,     3,
       3,     3,     3,     3,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     3,     3,     4,     4,     3,     1,     3
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 141 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
	ast_stack.push_back(current_ast);
}
#line 1962 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 3:
#line 143 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
	ast_stack.pop_back();
	log_assert(GetSize(ast_stack) == 0);
	for (auto &it : default_attr_list)
		delete it.second;
	default_attr_list.clear();
}
#line 1974 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 8:
#line 158 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		for (auto &it : attr_list)
			delete it.second;
		attr_list.clear();
		for (auto &it : default_attr_list)
			attr_list[it.first] = it.second->clone();
	}
#line 1986 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 9:
#line 164 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		std::map<std::string, AstNode*> *al = new std::map<std::string, AstNode*>;
		al->swap(attr_list);
		(yyval.al) = al;
	}
#line 1996 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 12:
#line 175 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		for (auto &it : default_attr_list)
			delete it.second;
		default_attr_list.clear();
		for (auto &it : attr_list)
			delete it.second;
		attr_list.clear();
	}
#line 2009 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 13:
#line 182 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		default_attr_list = attr_list;
		attr_list.clear();
	}
#line 2018 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 19:
#line 195 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (attr_list.count(*(yyvsp[0].string)) != 0)
			delete attr_list[*(yyvsp[0].string)];
		attr_list[*(yyvsp[0].string)] = AstNode::mkconst_int(1, false);
		delete (yyvsp[0].string);
	}
#line 2029 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 20:
#line 201 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (attr_list.count(*(yyvsp[-2].string)) != 0)
			delete attr_list[*(yyvsp[-2].string)];
		attr_list[*(yyvsp[-2].string)] = (yyvsp[0].ast);
		delete (yyvsp[-2].string);
	}
#line 2040 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 21:
#line 209 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = (yyvsp[0].string);
	}
#line 2048 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 22:
#line 212 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[0].string)->substr(0, 1) == "\\")
			*(yyvsp[-2].string) += "." + (yyvsp[0].string)->substr(1);
		else
			*(yyvsp[-2].string) += "." + *(yyvsp[0].string);
		delete (yyvsp[0].string);
		(yyval.string) = (yyvsp[-2].string);
	}
#line 2061 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 23:
#line 222 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		do_not_require_port_stubs = false;
		AstNode *mod = new AstNode(AST_MODULE);
		ast_stack.back()->children.push_back(mod);
		ast_stack.push_back(mod);
		current_ast_mod = mod;
		port_stubs.clear();
		port_counter = 0;
		mod->str = *(yyvsp[0].string);
		append_attr(mod, (yyvsp[-2].al));
		delete (yyvsp[0].string);
	}
#line 2078 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 24:
#line 233 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (port_stubs.size() != 0)
			frontend_verilog_yyerror("Missing details for module port `%s'.",
					port_stubs.begin()->first.c_str());
		ast_stack.pop_back();
		log_assert(ast_stack.size() == 1);
		current_ast_mod = NULL;
	}
#line 2091 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 25:
#line 243 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { astbuf1 = nullptr; }
#line 2097 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 26:
#line 243 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { if (astbuf1) delete astbuf1; }
#line 2103 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 32:
#line 251 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (astbuf1) delete astbuf1;
		astbuf1 = new AstNode(AST_PARAMETER);
		astbuf1->children.push_back(AstNode::mkconst_int(0, true));
	}
#line 2113 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 42:
#line 267 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (ast_stack.back()->children.size() > 0 && ast_stack.back()->children.back()->type == AST_WIRE) {
			AstNode *wire = new AstNode(AST_IDENTIFIER);
			wire->str = ast_stack.back()->children.back()->str;
			if (ast_stack.back()->children.back()->is_reg)
				ast_stack.back()->children.push_back(new AstNode(AST_INITIAL, new AstNode(AST_BLOCK, new AstNode(AST_ASSIGN_LE, wire, (yyvsp[0].ast)))));
			else
				ast_stack.back()->children.push_back(new AstNode(AST_ASSIGN, wire, (yyvsp[0].ast)));
		} else
			frontend_verilog_yyerror("Syntax error.");
	}
#line 2129 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 44:
#line 281 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (ast_stack.back()->children.size() > 0 && ast_stack.back()->children.back()->type == AST_WIRE) {
			AstNode *node = ast_stack.back()->children.back()->clone();
			node->str = *(yyvsp[0].string);
			node->port_id = ++port_counter;
			ast_stack.back()->children.push_back(node);
		} else {
			if (port_stubs.count(*(yyvsp[0].string)) != 0)
				frontend_verilog_yyerror("Duplicate module port `%s'.", (yyvsp[0].string)->c_str());
			port_stubs[*(yyvsp[0].string)] = ++port_counter;
		}
		delete (yyvsp[0].string);
	}
#line 2147 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 46:
#line 294 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = (yyvsp[-2].ast);
		node->str = *(yyvsp[0].string);
		node->port_id = ++port_counter;
		if ((yyvsp[-1].ast) != NULL)
			node->children.push_back((yyvsp[-1].ast));
		if (!node->is_input && !node->is_output)
			frontend_verilog_yyerror("Module port `%s' is neither input nor output.", (yyvsp[0].string)->c_str());
		if (node->is_reg && node->is_input && !node->is_output)
			frontend_verilog_yyerror("Input port `%s' is declared as register.", (yyvsp[0].string)->c_str());
		ast_stack.back()->children.push_back(node);
		append_attr(node, (yyvsp[-3].al));
		delete (yyvsp[0].string);
	}
#line 2166 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 48:
#line 308 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		do_not_require_port_stubs = true;
	}
#line 2174 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 49:
#line 313 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3 = new AstNode(AST_WIRE);
	}
#line 2182 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 50:
#line 315 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = astbuf3;
	}
#line 2190 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 53:
#line 323 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_input = true;
	}
#line 2198 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 54:
#line 326 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_output = true;
	}
#line 2206 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 55:
#line 329 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_input = true;
		astbuf3->is_output = true;
	}
#line 2215 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 56:
#line 333 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
	}
#line 2222 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 57:
#line 335 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_reg = true;
	}
#line 2230 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 58:
#line 338 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_reg = true;
		astbuf3->range_left = 31;
		astbuf3->range_right = 0;
		astbuf3->is_signed = true;
	}
#line 2241 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 59:
#line 344 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->type = AST_GENVAR;
		astbuf3->is_reg = true;
		astbuf3->range_left = 31;
		astbuf3->range_right = 0;
	}
#line 2252 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 60:
#line 350 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_signed = true;
	}
#line 2260 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 61:
#line 355 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_RANGE);
		(yyval.ast)->children.push_back((yyvsp[-3].ast));
		(yyval.ast)->children.push_back((yyvsp[-1].ast));
	}
#line 2270 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 62:
#line 360 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_RANGE);
		(yyval.ast)->children.push_back(new AstNode(AST_SUB, new AstNode(AST_ADD, (yyvsp[-3].ast)->clone(), (yyvsp[-1].ast)), AstNode::mkconst_int(1, true)));
		(yyval.ast)->children.push_back(new AstNode(AST_ADD, (yyvsp[-3].ast), AstNode::mkconst_int(0, true)));
	}
#line 2280 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 63:
#line 365 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_RANGE);
		(yyval.ast)->children.push_back(new AstNode(AST_ADD, (yyvsp[-3].ast), AstNode::mkconst_int(0, true)));
		(yyval.ast)->children.push_back(new AstNode(AST_SUB, new AstNode(AST_ADD, (yyvsp[-3].ast)->clone(), AstNode::mkconst_int(1, true)), (yyvsp[-1].ast)));
	}
#line 2290 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 64:
#line 370 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_RANGE);
		(yyval.ast)->children.push_back((yyvsp[-1].ast));
	}
#line 2299 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 65:
#line 376 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_MULTIRANGE, (yyvsp[-1].ast), (yyvsp[0].ast));
	}
#line 2307 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 66:
#line 379 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[-1].ast);
		(yyval.ast)->children.push_back((yyvsp[0].ast));
	}
#line 2316 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 67:
#line 385 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 2324 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 68:
#line 388 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = NULL;
	}
#line 2332 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 69:
#line 393 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { (yyval.ast) = (yyvsp[0].ast); }
#line 2338 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 70:
#line 394 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { (yyval.ast) = (yyvsp[0].ast); }
#line 2344 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 71:
#line 397 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 2352 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 72:
#line 400 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_RANGE);
		(yyval.ast)->children.push_back(AstNode::mkconst_int(31, true));
		(yyval.ast)->children.push_back(AstNode::mkconst_int(0, true));
		(yyval.ast)->is_signed = true;
	}
#line 2363 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 87:
#line 418 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = new AstNode(AST_DPI_FUNCTION, AstNode::mkconst_str(*(yyvsp[-1].string)), AstNode::mkconst_str(*(yyvsp[0].string)));
		current_function_or_task->str = *(yyvsp[0].string);
		append_attr(current_function_or_task, (yyvsp[-3].al));
		ast_stack.back()->children.push_back(current_function_or_task);
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 2376 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 88:
#line 425 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = NULL;
	}
#line 2384 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 89:
#line 428 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = new AstNode(AST_DPI_FUNCTION, AstNode::mkconst_str(*(yyvsp[-1].string)), AstNode::mkconst_str(*(yyvsp[-3].string)));
		current_function_or_task->str = *(yyvsp[0].string);
		append_attr(current_function_or_task, (yyvsp[-5].al));
		ast_stack.back()->children.push_back(current_function_or_task);
		delete (yyvsp[-3].string);
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 2398 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 90:
#line 436 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = NULL;
	}
#line 2406 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 91:
#line 439 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = new AstNode(AST_DPI_FUNCTION, AstNode::mkconst_str(*(yyvsp[-1].string)), AstNode::mkconst_str(*(yyvsp[-5].string) + ":" + RTLIL::unescape_id(*(yyvsp[-3].string))));
		current_function_or_task->str = *(yyvsp[0].string);
		append_attr(current_function_or_task, (yyvsp[-7].al));
		ast_stack.back()->children.push_back(current_function_or_task);
		delete (yyvsp[-5].string);
		delete (yyvsp[-3].string);
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 2421 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 92:
#line 448 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = NULL;
	}
#line 2429 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 93:
#line 451 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = new AstNode(AST_TASK);
		current_function_or_task->str = *(yyvsp[0].string);
		append_attr(current_function_or_task, (yyvsp[-2].al));
		ast_stack.back()->children.push_back(current_function_or_task);
		ast_stack.push_back(current_function_or_task);
		current_function_or_task_port_id = 1;
		delete (yyvsp[0].string);
	}
#line 2443 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 94:
#line 459 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = NULL;
		ast_stack.pop_back();
	}
#line 2452 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 95:
#line 463 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = new AstNode(AST_FUNCTION);
		current_function_or_task->str = *(yyvsp[0].string);
		append_attr(current_function_or_task, (yyvsp[-4].al));
		ast_stack.back()->children.push_back(current_function_or_task);
		ast_stack.push_back(current_function_or_task);
		AstNode *outreg = new AstNode(AST_WIRE);
		outreg->str = *(yyvsp[0].string);
		outreg->is_signed = (yyvsp[-2].boolean);
		if ((yyvsp[-1].ast) != NULL) {
			outreg->children.push_back((yyvsp[-1].ast));
			outreg->is_signed = (yyvsp[-2].boolean) || (yyvsp[-1].ast)->is_signed;
			(yyvsp[-1].ast)->is_signed = false;
		}
		current_function_or_task->children.push_back(outreg);
		current_function_or_task_port_id = 1;
		delete (yyvsp[0].string);
	}
#line 2475 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 96:
#line 480 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = NULL;
		ast_stack.pop_back();
	}
#line 2484 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 97:
#line 486 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task->children.push_back(AstNode::mkconst_str(*(yyvsp[-1].string)));
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 2494 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 98:
#line 491 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task->children.push_back(AstNode::mkconst_str(*(yyvsp[0].string)));
		delete (yyvsp[0].string);
	}
#line 2503 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 105:
#line 507 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.boolean) = true;
	}
#line 2511 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 106:
#line 510 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.boolean) = false;
	}
#line 2519 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 109:
#line 515 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		albuf = nullptr;
		astbuf1 = nullptr;
		astbuf2 = nullptr;
	}
#line 2529 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 110:
#line 519 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
		if (astbuf2 != NULL)
			delete astbuf2;
		free_attr(albuf);
	}
#line 2540 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 114:
#line 530 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (albuf) {
			delete astbuf1;
			if (astbuf2 != NULL)
				delete astbuf2;
			free_attr(albuf);
		}
		albuf = (yyvsp[-2].al);
		astbuf1 = (yyvsp[-1].ast);
		astbuf2 = (yyvsp[0].ast);
		if (astbuf1->range_left >= 0 && astbuf1->range_right >= 0) {
			if (astbuf2) {
				frontend_verilog_yyerror("Syntax error.");
			} else {
				astbuf2 = new AstNode(AST_RANGE);
				astbuf2->children.push_back(AstNode::mkconst_int(astbuf1->range_left, true));
				astbuf2->children.push_back(AstNode::mkconst_int(astbuf1->range_right, true));
			}
		}
		if (astbuf2 && astbuf2->children.size() != 2)
			frontend_verilog_yyerror("Syntax error.");
	}
#line 2567 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 119:
#line 558 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf1->is_signed = true;
	}
#line 2575 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 121:
#line 563 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (astbuf1->children.size() != 1)
			frontend_verilog_yyerror("Syntax error.");
		astbuf1->children.push_back(new AstNode(AST_RANGE));
		astbuf1->children.back()->children.push_back(AstNode::mkconst_int(31, true));
		astbuf1->children.back()->children.push_back(AstNode::mkconst_int(0, true));
		astbuf1->is_signed = true;
	}
#line 2588 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 123:
#line 573 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (astbuf1->children.size() != 1)
			frontend_verilog_yyerror("Syntax error.");
		astbuf1->children.push_back(new AstNode(AST_REALVALUE));
	}
#line 2598 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 125:
#line 580 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[0].ast) != NULL) {
			if (astbuf1->children.size() != 1)
				frontend_verilog_yyerror("Syntax error.");
			astbuf1->children.push_back((yyvsp[0].ast));
		}
	}
#line 2610 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 126:
#line 589 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf1 = new AstNode(AST_PARAMETER);
		astbuf1->children.push_back(AstNode::mkconst_int(0, true));
	}
#line 2619 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 127:
#line 592 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
	}
#line 2627 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 128:
#line 597 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf1 = new AstNode(AST_LOCALPARAM);
		astbuf1->children.push_back(AstNode::mkconst_int(0, true));
	}
#line 2636 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 129:
#line 600 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
	}
#line 2644 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 132:
#line 608 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (astbuf1 == nullptr)
			frontend_verilog_yyerror("syntax error");
		AstNode *node = astbuf1->clone();
		node->str = *(yyvsp[-2].string);
		delete node->children[0];
		node->children[0] = (yyvsp[0].ast);
		ast_stack.back()->children.push_back(node);
		delete (yyvsp[-2].string);
	}
#line 2659 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 136:
#line 626 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_DEFPARAM);
		node->str = *(yyvsp[-2].string);
		node->children.push_back((yyvsp[0].ast));
		if ((yyvsp[-3].ast) != NULL)
			node->children.push_back((yyvsp[-3].ast));
		ast_stack.back()->children.push_back(node);
		delete (yyvsp[-2].string);
	}
#line 2673 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 137:
#line 637 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		albuf = (yyvsp[-2].al);
		astbuf1 = (yyvsp[-1].ast);
		astbuf2 = (yyvsp[0].ast);
		if (astbuf1->range_left >= 0 && astbuf1->range_right >= 0) {
			if (astbuf2) {
				frontend_verilog_yyerror("Syntax error.");
			} else {
				astbuf2 = new AstNode(AST_RANGE);
				astbuf2->children.push_back(AstNode::mkconst_int(astbuf1->range_left, true));
				astbuf2->children.push_back(AstNode::mkconst_int(astbuf1->range_right, true));
			}
		}
		if (astbuf2 && astbuf2->children.size() != 2)
			frontend_verilog_yyerror("Syntax error.");
	}
#line 2694 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 138:
#line 652 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
		if (astbuf2 != NULL)
			delete astbuf2;
		free_attr(albuf);
	}
#line 2705 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 140:
#line 658 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_WIRE));
		ast_stack.back()->children.back()->str = *(yyvsp[-1].string);
		append_attr(ast_stack.back()->children.back(), (yyvsp[-3].al));
		ast_stack.back()->children.push_back(new AstNode(AST_ASSIGN, new AstNode(AST_IDENTIFIER), AstNode::mkconst_int(0, false, 1)));
		ast_stack.back()->children.back()->children[0]->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
	}
#line 2718 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 141:
#line 666 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_WIRE));
		ast_stack.back()->children.back()->str = *(yyvsp[-1].string);
		append_attr(ast_stack.back()->children.back(), (yyvsp[-3].al));
		ast_stack.back()->children.push_back(new AstNode(AST_ASSIGN, new AstNode(AST_IDENTIFIER), AstNode::mkconst_int(1, false, 1)));
		ast_stack.back()->children.back()->children[0]->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
	}
#line 2731 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 145:
#line 680 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *wire = new AstNode(AST_IDENTIFIER);
		wire->str = ast_stack.back()->children.back()->str;
		if (astbuf1->is_reg)
			ast_stack.back()->children.push_back(new AstNode(AST_INITIAL, new AstNode(AST_BLOCK, new AstNode(AST_ASSIGN_LE, wire, (yyvsp[0].ast)))));
		else
			ast_stack.back()->children.push_back(new AstNode(AST_ASSIGN, wire, (yyvsp[0].ast)));
	}
#line 2744 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 146:
#line 690 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = astbuf1->clone();
		node->str = *(yyvsp[-1].string);
		append_attr_clone(node, albuf);
		if (astbuf2 != NULL)
			node->children.push_back(astbuf2->clone());
		if ((yyvsp[0].ast) != NULL) {
			if (node->is_input || node->is_output)
				frontend_verilog_yyerror("Syntax error.");
			if (!astbuf2) {
				AstNode *rng = new AstNode(AST_RANGE);
				rng->children.push_back(AstNode::mkconst_int(0, true));
				rng->children.push_back(AstNode::mkconst_int(0, true));
				node->children.push_back(rng);
			}
			node->type = AST_MEMORY;
			node->children.push_back((yyvsp[0].ast));
		}
		if (current_function_or_task == NULL) {
			if (do_not_require_port_stubs && (node->is_input || node->is_output) && port_stubs.count(*(yyvsp[-1].string)) == 0) {
				port_stubs[*(yyvsp[-1].string)] = ++port_counter;
			}
			if (port_stubs.count(*(yyvsp[-1].string)) != 0) {
				if (!node->is_input && !node->is_output)
					frontend_verilog_yyerror("Module port `%s' is neither input nor output.", (yyvsp[-1].string)->c_str());
				if (node->is_reg && node->is_input && !node->is_output)
					frontend_verilog_yyerror("Input port `%s' is declared as register.", (yyvsp[-1].string)->c_str());
				node->port_id = port_stubs[*(yyvsp[-1].string)];
				port_stubs.erase(*(yyvsp[-1].string));
			} else {
				if (node->is_input || node->is_output)
					frontend_verilog_yyerror("Module port `%s' is not declared in module header.", (yyvsp[-1].string)->c_str());
			}
		} else {
			if (node->is_input || node->is_output)
				node->port_id = current_function_or_task_port_id++;
		}
		ast_stack.back()->children.push_back(node);
		delete (yyvsp[-1].string);
	}
#line 2789 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 150:
#line 738 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_ASSIGN, (yyvsp[-2].ast), (yyvsp[0].ast)));
	}
#line 2797 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 151:
#line 743 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf1 = new AstNode(AST_CELL);
		append_attr(astbuf1, (yyvsp[-1].al));
		astbuf1->children.push_back(new AstNode(AST_CELLTYPE));
		astbuf1->children[0]->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
	}
#line 2809 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 152:
#line 749 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
	}
#line 2817 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 153:
#line 752 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf1 = new AstNode(AST_PRIMITIVE);
		astbuf1->str = *(yyvsp[0].string);
		append_attr(astbuf1, (yyvsp[-1].al));
		delete (yyvsp[0].string);
	}
#line 2828 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 154:
#line 757 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
	}
#line 2836 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 155:
#line 762 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = (yyvsp[0].string);
	}
#line 2844 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 156:
#line 765 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = new std::string("or");
	}
#line 2852 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 159:
#line 774 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf2 = astbuf1->clone();
		if (astbuf2->type != AST_PRIMITIVE)
			astbuf2->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
		ast_stack.back()->children.push_back(astbuf2);
	}
#line 2864 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 161:
#line 781 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf2 = astbuf1->clone();
		if (astbuf2->type != AST_PRIMITIVE)
			astbuf2->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
		ast_stack.back()->children.push_back(new AstNode(AST_CELLARRAY, (yyvsp[0].ast), astbuf2));
	}
#line 2876 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 166:
#line 795 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf2 = astbuf1->clone();
		ast_stack.back()->children.push_back(astbuf2);
	}
#line 2885 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 173:
#line 808 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_PARASET);
		astbuf1->children.push_back(node);
		node->children.push_back((yyvsp[0].ast));
	}
#line 2895 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 174:
#line 813 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_PARASET);
		node->str = *(yyvsp[-3].string);
		astbuf1->children.push_back(node);
		node->children.push_back((yyvsp[-1].ast));
		delete (yyvsp[-3].string);
	}
#line 2907 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 178:
#line 824 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ARGUMENT);
		astbuf2->children.push_back(node);
	}
#line 2916 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 180:
#line 830 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ARGUMENT);
		astbuf2->children.push_back(node);
		node->children.push_back((yyvsp[0].ast));
	}
#line 2926 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 181:
#line 835 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ARGUMENT);
		node->str = *(yyvsp[-3].string);
		astbuf2->children.push_back(node);
		node->children.push_back((yyvsp[-1].ast));
		delete (yyvsp[-3].string);
	}
#line 2938 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 182:
#line 842 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ARGUMENT);
		node->str = *(yyvsp[-2].string);
		astbuf2->children.push_back(node);
		delete (yyvsp[-2].string);
	}
#line 2949 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 183:
#line 850 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ALWAYS);
		append_attr(node, (yyvsp[-1].al));
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 2960 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 184:
#line 855 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
	}
#line 2970 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 185:
#line 859 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 2979 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 186:
#line 863 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_INITIAL);
		append_attr(node, (yyvsp[-1].al));
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
	}
#line 2993 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 187:
#line 871 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 3002 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 197:
#line 890 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_POSEDGE);
		ast_stack.back()->children.push_back(node);
		node->children.push_back((yyvsp[0].ast));
	}
#line 3012 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 198:
#line 895 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_NEGEDGE);
		ast_stack.back()->children.push_back(node);
		node->children.push_back((yyvsp[0].ast));
	}
#line 3022 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 199:
#line 900 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_EDGE);
		ast_stack.back()->children.push_back(node);
		node->children.push_back((yyvsp[0].ast));
	}
#line 3032 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 200:
#line 907 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = (yyvsp[0].string);
	}
#line 3040 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 201:
#line 910 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = NULL;
	}
#line 3048 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 202:
#line 915 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_ASSERT, (yyvsp[-2].ast)));
	}
#line 3056 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 203:
#line 920 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_ASSERT, (yyvsp[-2].ast)));
	}
#line 3064 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 204:
#line 925 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ASSIGN_EQ, (yyvsp[-2].ast), (yyvsp[0].ast));
		ast_stack.back()->children.push_back(node);
	}
#line 3073 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 205:
#line 929 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ASSIGN_LE, (yyvsp[-2].ast), (yyvsp[0].ast));
		ast_stack.back()->children.push_back(node);
	}
#line 3082 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 210:
#line 938 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_TCALL);
		node->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[0].al));
	}
#line 3095 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 211:
#line 945 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
	}
#line 3103 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 212:
#line 948 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[-2].al));
		if ((yyvsp[0].string) != NULL)
			node->str = *(yyvsp[0].string);
	}
#line 3116 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 213:
#line 955 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[-4].string) != NULL && (yyvsp[0].string) != NULL && *(yyvsp[-4].string) != *(yyvsp[0].string))
			frontend_verilog_yyerror("Syntax error.");
		if ((yyvsp[-4].string) != NULL)
			delete (yyvsp[-4].string);
		if ((yyvsp[0].string) != NULL)
			delete (yyvsp[0].string);
		ast_stack.pop_back();
	}
#line 3130 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 214:
#line 964 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_FOR);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[-2].al));
	}
#line 3141 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 215:
#line 969 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back((yyvsp[0].ast));
	}
#line 3149 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 216:
#line 971 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
	}
#line 3159 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 217:
#line 975 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 3168 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 218:
#line 979 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_WHILE);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[-4].al));
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back((yyvsp[-1].ast));
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
	}
#line 3183 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 219:
#line 988 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 3192 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 220:
#line 992 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_REPEAT);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[-4].al));
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back((yyvsp[-1].ast));
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
	}
#line 3207 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 221:
#line 1001 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 3216 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 222:
#line 1005 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_CASE);
		AstNode *block = new AstNode(AST_BLOCK);
		AstNode *cond = new AstNode(AST_COND, AstNode::mkconst_int(1, false, 1), block);
		ast_stack.back()->children.push_back(node);
		node->children.push_back(new AstNode(AST_REDUCE_BOOL, (yyvsp[-1].ast)));
		node->children.push_back(cond);
		ast_stack.push_back(node);
		ast_stack.push_back(block);
		append_attr(node, (yyvsp[-4].al));
	}
#line 3232 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 223:
#line 1015 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 3241 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 224:
#line 1019 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_CASE, (yyvsp[-1].ast));
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[-4].al));
	}
#line 3252 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 225:
#line 1024 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.pop_back();
		ast_stack.pop_back();
	}
#line 3261 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 226:
#line 1030 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { 
		case_type_stack.push_back(0);
	}
#line 3269 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 227:
#line 1033 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { 
		case_type_stack.push_back('x');
	}
#line 3277 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 228:
#line 1036 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { 
		case_type_stack.push_back('z');
	}
#line 3285 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 229:
#line 1041 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (ast_stack.back()->attributes.count("\\full_case") == 0)
			ast_stack.back()->attributes["\\full_case"] = AstNode::mkconst_int(1, false);
	}
#line 3294 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 230:
#line 1045 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (ast_stack.back()->attributes.count("\\parallel_case") == 0)
			ast_stack.back()->attributes["\\parallel_case"] = AstNode::mkconst_int(1, false);
	}
#line 3303 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 236:
#line 1060 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *block = new AstNode(AST_BLOCK);
		AstNode *cond = new AstNode(AST_COND, new AstNode(AST_DEFAULT), block);
		ast_stack.pop_back();
		ast_stack.back()->children.push_back(cond);
		ast_stack.push_back(block);
	}
#line 3315 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 241:
#line 1074 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_COND);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 3325 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 242:
#line 1078 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
		case_type_stack.push_back(0);
	}
#line 3336 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 243:
#line 1083 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.pop_back();
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 3346 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 246:
#line 1094 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_COND);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 3356 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 247:
#line 1098 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.push_back(0);
	}
#line 3364 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 248:
#line 1100 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.pop_back();
		ast_stack.pop_back();
	}
#line 3373 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 251:
#line 1110 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_DEFAULT));
	}
#line 3381 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 252:
#line 1113 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back((yyvsp[0].ast));
	}
#line 3389 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 253:
#line 1116 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back((yyvsp[0].ast));
	}
#line 3397 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 254:
#line 1121 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_PREFIX, (yyvsp[-3].ast), (yyvsp[0].ast));
		(yyval.ast)->str = *(yyvsp[-5].string);
		delete (yyvsp[-5].string);
	}
#line 3407 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 255:
#line 1126 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_IDENTIFIER, (yyvsp[0].ast));
		(yyval.ast)->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
	}
#line 3417 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 256:
#line 1131 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_IDENTIFIER, (yyvsp[0].ast));
		(yyval.ast)->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
	}
#line 3427 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 257:
#line 1138 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 3435 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 258:
#line 1141 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[-1].ast);
	}
#line 3443 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 259:
#line 1146 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_CONCAT);
		(yyval.ast)->children.push_back((yyvsp[0].ast));
	}
#line 3452 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 260:
#line 1150 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
		(yyval.ast)->children.push_back((yyvsp[-2].ast));
	}
#line 3461 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 267:
#line 1168 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back((yyvsp[0].ast));
	}
#line 3469 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 272:
#line 1181 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_GENFOR);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 3479 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 273:
#line 1185 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back((yyvsp[0].ast));
	}
#line 3487 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 274:
#line 1187 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
	}
#line 3495 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 275:
#line 1190 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_GENIF);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		ast_stack.back()->children.push_back((yyvsp[-1].ast));
	}
#line 3506 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 276:
#line 1195 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
	}
#line 3514 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 277:
#line 1198 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_GENCASE, (yyvsp[-1].ast));
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 3524 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 278:
#line 1202 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.pop_back();
		ast_stack.pop_back();
	}
#line 3533 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 279:
#line 1206 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_GENBLOCK);
		node->str = (yyvsp[0].string) ? *(yyvsp[0].string) : std::string();
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 3544 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 280:
#line 1211 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[-4].string) != NULL)
			delete (yyvsp[-4].string);
		if ((yyvsp[0].string) != NULL)
			delete (yyvsp[0].string);
		ast_stack.pop_back();
	}
#line 3556 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 281:
#line 1220 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_GENBLOCK);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 3566 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 282:
#line 1224 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
	}
#line 3574 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 287:
#line 1235 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 3582 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 288:
#line 1238 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_TERNARY);
		(yyval.ast)->children.push_back((yyvsp[-5].ast));
		(yyval.ast)->children.push_back((yyvsp[-2].ast));
		(yyval.ast)->children.push_back((yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-3].al));
	}
#line 3594 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 289:
#line 1247 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 3602 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 290:
#line 1250 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[0].string)->substr(0, 1) != "'")
			frontend_verilog_yyerror("Syntax error.");
		AstNode *bits = (yyvsp[-2].ast);
		AstNode *val = const2ast(*(yyvsp[0].string), case_type_stack.size() == 0 ? 0 : case_type_stack.back());
		if (val == NULL)
			log_error("Value conversion failed: `%s'\n", (yyvsp[0].string)->c_str());
		(yyval.ast) = new AstNode(AST_TO_BITS, bits, val);
		delete (yyvsp[0].string);
	}
#line 3617 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 291:
#line 1260 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[0].string)->substr(0, 1) != "'")
			frontend_verilog_yyerror("Syntax error.");
		AstNode *bits = new AstNode(AST_IDENTIFIER);
		bits->str = *(yyvsp[-1].string);
		AstNode *val = const2ast(*(yyvsp[0].string), case_type_stack.size() == 0 ? 0 : case_type_stack.back());
		if (val == NULL)
			log_error("Value conversion failed: `%s'\n", (yyvsp[0].string)->c_str());
		(yyval.ast) = new AstNode(AST_TO_BITS, bits, val);
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 3634 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 292:
#line 1272 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = const2ast(*(yyvsp[-1].string) + *(yyvsp[0].string), case_type_stack.size() == 0 ? 0 : case_type_stack.back());
		if ((yyval.ast) == NULL || (*(yyvsp[0].string))[0] != '\'')
			log_error("Value conversion failed: `%s%s'\n", (yyvsp[-1].string)->c_str(), (yyvsp[0].string)->c_str());
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 3646 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 293:
#line 1279 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = const2ast(*(yyvsp[0].string), case_type_stack.size() == 0 ? 0 : case_type_stack.back());
		if ((yyval.ast) == NULL)
			log_error("Value conversion failed: `%s'\n", (yyvsp[0].string)->c_str());
		delete (yyvsp[0].string);
	}
#line 3657 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 294:
#line 1285 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REALVALUE);
		char *p = strdup((yyvsp[0].string)->c_str()), *q;
		for (int i = 0, j = 0; !p[j]; j++)
			if (p[j] != '_')
				p[i++] = p[j], p[i] = 0;
		(yyval.ast)->realvalue = strtod(p, &q);
		log_assert(*q == 0);
		delete (yyvsp[0].string);
		free(p);
	}
#line 3673 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 295:
#line 1296 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = AstNode::mkconst_str(*(yyvsp[0].string));
		delete (yyvsp[0].string);
	}
#line 3682 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 296:
#line 1300 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_FCALL);
		node->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[0].al));
	}
#line 3694 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 297:
#line 1306 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = ast_stack.back();
		ast_stack.pop_back();
	}
#line 3703 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 298:
#line 1310 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_TO_SIGNED, (yyvsp[-1].ast));
		append_attr((yyval.ast), (yyvsp[-3].al));
	}
#line 3712 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 299:
#line 1314 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_TO_UNSIGNED, (yyvsp[-1].ast));
		append_attr((yyval.ast), (yyvsp[-3].al));
	}
#line 3721 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 300:
#line 1318 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[-1].ast);
	}
#line 3729 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 301:
#line 1321 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[-1].ast);
	}
#line 3737 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 302:
#line 1324 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REPLICATE, (yyvsp[-4].ast), (yyvsp[-2].ast));
	}
#line 3745 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 303:
#line 1327 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_NOT, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3754 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 304:
#line 1331 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_AND, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3763 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 305:
#line 1335 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_OR, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3772 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 306:
#line 1339 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_XOR, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3781 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 307:
#line 1343 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_XNOR, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3790 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 308:
#line 1347 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_AND, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3799 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 309:
#line 1351 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_AND, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
		(yyval.ast) = new AstNode(AST_LOGIC_NOT, (yyval.ast));
	}
#line 3809 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 310:
#line 1356 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_OR, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3818 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 311:
#line 1360 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_OR, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
		(yyval.ast) = new AstNode(AST_LOGIC_NOT, (yyval.ast));
	}
#line 3828 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 312:
#line 1365 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_XOR, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3837 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 313:
#line 1369 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_XNOR, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3846 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 314:
#line 1373 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_SHIFT_LEFT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3855 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 315:
#line 1377 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_SHIFT_RIGHT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3864 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 316:
#line 1381 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_SHIFT_SLEFT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3873 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 317:
#line 1385 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_SHIFT_SRIGHT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3882 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 318:
#line 1389 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_LT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3891 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 319:
#line 1393 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_LE, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3900 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 320:
#line 1397 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_EQ, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3909 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 321:
#line 1401 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_NE, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3918 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 322:
#line 1405 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_EQX, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3927 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 323:
#line 1409 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_NEX, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3936 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 324:
#line 1413 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_GE, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3945 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 325:
#line 1417 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_GT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3954 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 326:
#line 1421 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_ADD, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3963 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 327:
#line 1425 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_SUB, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3972 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 328:
#line 1429 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_MUL, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3981 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 329:
#line 1433 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_DIV, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3990 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 330:
#line 1437 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_MOD, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 3999 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 331:
#line 1441 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_POW, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 4008 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 332:
#line 1445 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_POS, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 4017 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 333:
#line 1449 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_NEG, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 4026 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 334:
#line 1453 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_LOGIC_AND, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 4035 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 335:
#line 1457 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_LOGIC_OR, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 4044 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 336:
#line 1461 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_LOGIC_NOT, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 4053 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 337:
#line 1467 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_CONCAT, (yyvsp[0].ast));
	}
#line 4061 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;

  case 338:
#line 1470 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
		(yyval.ast)->children.push_back((yyvsp[-2].ast));
	}
#line 4070 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
    break;


#line 4074 "frontends/verilog/verilog_parser.tab.c" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
