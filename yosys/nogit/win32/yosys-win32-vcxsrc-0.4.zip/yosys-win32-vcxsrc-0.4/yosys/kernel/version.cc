namespace Yosys { extern const char *yosys_version_str; const char *yosys_version_str="Yosys 0.4 (git sha1 d5aa0ee, Visual Studio)"; }
