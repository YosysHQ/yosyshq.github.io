Yosys is using "ABC" for gate-level optimizations and technology
mapping. Download yosys-win32-mxebin-0.5.zip and copy the
following files from it into this directory:

	pthreadVC2.dll
	yosys-abc.exe
