namespace Yosys { extern const char *yosys_version_str; const char *yosys_version_str="Yosys 0.5 (git sha1 c3c9fbf, Visual Studio)"; }
