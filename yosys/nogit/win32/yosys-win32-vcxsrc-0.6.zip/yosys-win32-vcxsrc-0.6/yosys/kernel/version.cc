namespace Yosys { extern const char *yosys_version_str; const char *yosys_version_str="Yosys 0.6 (git sha1 5869d26, Visual Studio)"; }
