namespace Yosys { extern const char *yosys_version_str; const char *yosys_version_str="Yosys 0.7 (git sha1 61f6811, Visual Studio)"; }
