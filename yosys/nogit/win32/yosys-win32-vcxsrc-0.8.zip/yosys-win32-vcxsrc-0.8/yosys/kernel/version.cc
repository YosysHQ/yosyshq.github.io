namespace Yosys { extern const char *yosys_version_str; const char *yosys_version_str="Yosys 0.8 (git sha1 5706e90, Visual Studio)"; }
