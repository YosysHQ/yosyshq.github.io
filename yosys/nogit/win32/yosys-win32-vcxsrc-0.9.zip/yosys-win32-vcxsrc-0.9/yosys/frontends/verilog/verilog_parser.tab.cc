/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.4"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Substitute the type names.  */
#define YYSTYPE         FRONTEND_VERILOG_YYSTYPE
/* Substitute the variable and function names.  */
#define yyparse         frontend_verilog_yyparse
#define yylex           frontend_verilog_yylex
#define yyerror         frontend_verilog_yyerror
#define yydebug         frontend_verilog_yydebug
#define yynerrs         frontend_verilog_yynerrs

#define yylval          frontend_verilog_yylval
#define yychar          frontend_verilog_yychar

/* Copy the first part of user declarations.  */
#line 36 "frontends/verilog/verilog_parser.y" /* yacc.c:339  */

#include <list>
#include <stack>
#include <string.h>
#include "frontends/verilog/verilog_frontend.h"
#include "kernel/log.h"

USING_YOSYS_NAMESPACE
using namespace AST;
using namespace VERILOG_FRONTEND;

YOSYS_NAMESPACE_BEGIN
namespace VERILOG_FRONTEND {
	int port_counter;
	std::map<std::string, int> port_stubs;
	std::map<std::string, AstNode*> *attr_list, default_attr_list;
	std::stack<std::map<std::string, AstNode*> *> attr_list_stack;
	std::map<std::string, AstNode*> *albuf;
	std::vector<AstNode*> ast_stack;
	struct AstNode *astbuf1, *astbuf2, *astbuf3;
	struct AstNode *current_function_or_task;
	struct AstNode *current_ast, *current_ast_mod;
	int current_function_or_task_port_id;
	std::vector<char> case_type_stack;
	bool do_not_require_port_stubs;
	bool default_nettype_wire;
	bool sv_mode, formal_mode, lib_mode, specify_mode;
	bool noassert_mode, noassume_mode, norestrict_mode;
	bool assume_asserts_mode, assert_assumes_mode;
	bool current_wire_rand, current_wire_const;
	bool current_modport_input, current_modport_output;
	std::istream *lexin;
}
YOSYS_NAMESPACE_END

static void append_attr(AstNode *ast, std::map<std::string, AstNode*> *al)
{
	for (auto &it : *al) {
		if (ast->attributes.count(it.first) > 0)
			delete ast->attributes[it.first];
		ast->attributes[it.first] = it.second;
	}
	delete al;
}

static void append_attr_clone(AstNode *ast, std::map<std::string, AstNode*> *al)
{
	for (auto &it : *al) {
		if (ast->attributes.count(it.first) > 0)
			delete ast->attributes[it.first];
		ast->attributes[it.first] = it.second->clone();
	}
}

static void free_attr(std::map<std::string, AstNode*> *al)
{
	for (auto &it : *al)
		delete it.second;
	delete al;
}

struct specify_target {
	char polarity_op;
	AstNode *dst, *dat;
};

struct specify_triple {
	AstNode *t_min, *t_avg, *t_max;
};

struct specify_rise_fall {
	specify_triple rise;
	specify_triple fall;
};


#line 152 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 1
#endif

/* In a future release of Bison, this section will be replaced
   by #include "verilog_parser.tab.hh".  */
#ifndef YY_FRONTEND_VERILOG_YY_FRONTENDS_VERILOG_VERILOG_PARSER_TAB_HH_INCLUDED
# define YY_FRONTEND_VERILOG_YY_FRONTENDS_VERILOG_VERILOG_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef FRONTEND_VERILOG_YYDEBUG
# if defined YYDEBUG
#if YYDEBUG
#   define FRONTEND_VERILOG_YYDEBUG 1
#  else
#   define FRONTEND_VERILOG_YYDEBUG 0
#  endif
# else /* ! defined YYDEBUG */
#  define FRONTEND_VERILOG_YYDEBUG 1
# endif /* ! defined YYDEBUG */
#endif  /* ! defined FRONTEND_VERILOG_YYDEBUG */
#if FRONTEND_VERILOG_YYDEBUG
extern int frontend_verilog_yydebug;
#endif
/* "%code requires" blocks.  */
#line 118 "frontends/verilog/verilog_parser.y" /* yacc.c:355  */

#include <map>
#include <string>
#include "frontends/verilog/verilog_frontend.h"

#line 196 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:355  */

/* Token type.  */
#ifndef FRONTEND_VERILOG_YYTOKENTYPE
# define FRONTEND_VERILOG_YYTOKENTYPE
  enum frontend_verilog_yytokentype
  {
    TOK_STRING = 258,
    TOK_ID = 259,
    TOK_CONSTVAL = 260,
    TOK_REALVAL = 261,
    TOK_PRIMITIVE = 262,
    TOK_SVA_LABEL = 263,
    TOK_SPECIFY_OPER = 264,
    TOK_MSG_TASKS = 265,
    TOK_ASSERT = 266,
    TOK_ASSUME = 267,
    TOK_RESTRICT = 268,
    TOK_COVER = 269,
    TOK_FINAL = 270,
    ATTR_BEGIN = 271,
    ATTR_END = 272,
    DEFATTR_BEGIN = 273,
    DEFATTR_END = 274,
    TOK_MODULE = 275,
    TOK_ENDMODULE = 276,
    TOK_PARAMETER = 277,
    TOK_LOCALPARAM = 278,
    TOK_DEFPARAM = 279,
    TOK_PACKAGE = 280,
    TOK_ENDPACKAGE = 281,
    TOK_PACKAGESEP = 282,
    TOK_INTERFACE = 283,
    TOK_ENDINTERFACE = 284,
    TOK_MODPORT = 285,
    TOK_VAR = 286,
    TOK_INPUT = 287,
    TOK_OUTPUT = 288,
    TOK_INOUT = 289,
    TOK_WIRE = 290,
    TOK_WAND = 291,
    TOK_WOR = 292,
    TOK_REG = 293,
    TOK_LOGIC = 294,
    TOK_INTEGER = 295,
    TOK_SIGNED = 296,
    TOK_ASSIGN = 297,
    TOK_ALWAYS = 298,
    TOK_INITIAL = 299,
    TOK_BEGIN = 300,
    TOK_END = 301,
    TOK_IF = 302,
    TOK_ELSE = 303,
    TOK_FOR = 304,
    TOK_WHILE = 305,
    TOK_REPEAT = 306,
    TOK_DPI_FUNCTION = 307,
    TOK_POSEDGE = 308,
    TOK_NEGEDGE = 309,
    TOK_OR = 310,
    TOK_AUTOMATIC = 311,
    TOK_CASE = 312,
    TOK_CASEX = 313,
    TOK_CASEZ = 314,
    TOK_ENDCASE = 315,
    TOK_DEFAULT = 316,
    TOK_FUNCTION = 317,
    TOK_ENDFUNCTION = 318,
    TOK_TASK = 319,
    TOK_ENDTASK = 320,
    TOK_SPECIFY = 321,
    TOK_IGNORED_SPECIFY = 322,
    TOK_ENDSPECIFY = 323,
    TOK_SPECPARAM = 324,
    TOK_SPECIFY_AND = 325,
    TOK_GENERATE = 326,
    TOK_ENDGENERATE = 327,
    TOK_GENVAR = 328,
    TOK_REAL = 329,
    TOK_SYNOPSYS_FULL_CASE = 330,
    TOK_SYNOPSYS_PARALLEL_CASE = 331,
    TOK_SUPPLY0 = 332,
    TOK_SUPPLY1 = 333,
    TOK_TO_SIGNED = 334,
    TOK_TO_UNSIGNED = 335,
    TOK_POS_INDEXED = 336,
    TOK_NEG_INDEXED = 337,
    TOK_PROPERTY = 338,
    TOK_ENUM = 339,
    TOK_TYPEDEF = 340,
    TOK_RAND = 341,
    TOK_CONST = 342,
    TOK_CHECKER = 343,
    TOK_ENDCHECKER = 344,
    TOK_EVENTUALLY = 345,
    TOK_INCREMENT = 346,
    TOK_DECREMENT = 347,
    TOK_UNIQUE = 348,
    TOK_PRIORITY = 349,
    OP_LOR = 350,
    OP_LAND = 351,
    OP_NOR = 352,
    OP_XNOR = 353,
    OP_NAND = 354,
    OP_EQ = 355,
    OP_NE = 356,
    OP_EQX = 357,
    OP_NEX = 358,
    OP_LE = 359,
    OP_GE = 360,
    OP_SHL = 361,
    OP_SHR = 362,
    OP_SSHL = 363,
    OP_SSHR = 364,
    OP_POW = 365,
    UNARY_OPS = 366,
    FAKE_THEN = 367
  };
#endif

/* Value type.  */
#if ! defined FRONTEND_VERILOG_YYSTYPE && ! defined FRONTEND_VERILOG_YYSTYPE_IS_DECLARED

union FRONTEND_VERILOG_YYSTYPE
{
#line 124 "frontends/verilog/verilog_parser.y" /* yacc.c:355  */

	std::string *string;
	struct YOSYS_NAMESPACE_PREFIX AST::AstNode *ast;
	std::map<std::string, YOSYS_NAMESPACE_PREFIX AST::AstNode*> *al;
	struct specify_target *specify_target_ptr;
	struct specify_triple *specify_triple_ptr;
	struct specify_rise_fall *specify_rise_fall_ptr;
	bool boolean;
	char ch;

#line 332 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:355  */
};

typedef union FRONTEND_VERILOG_YYSTYPE FRONTEND_VERILOG_YYSTYPE;
# define FRONTEND_VERILOG_YYSTYPE_IS_TRIVIAL 1
# define FRONTEND_VERILOG_YYSTYPE_IS_DECLARED 1
#endif


extern FRONTEND_VERILOG_YYSTYPE frontend_verilog_yylval;

int frontend_verilog_yyparse (void);

#endif /* !YY_FRONTEND_VERILOG_YY_FRONTENDS_VERILOG_VERILOG_PARSER_TAB_HH_INCLUDED  */

/* Copy the second part of user declarations.  */

#line 349 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if 1

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
# define YYCOPY_NEEDED 1
#endif


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined FRONTEND_VERILOG_YYSTYPE_IS_TRIVIAL && FRONTEND_VERILOG_YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   2240

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  139
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  228
/* YYNRULES -- Number of rules.  */
#define YYNRULES  513
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  1058

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   367

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   138,     2,   127,     2,   119,   101,     2,
     128,   129,   117,   115,   123,   116,   125,   118,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   130,   126,
     107,   124,   110,   136,   133,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   131,     2,   132,    99,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   134,    97,   135,   137,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    98,   100,   102,   103,   104,   105,   106,   108,
     109,   111,   112,   113,   114,   120,   121,   122
};

#if FRONTEND_VERILOG_YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   192,   192,   192,   204,   205,   206,   207,   208,   209,
     210,   210,   214,   214,   230,   230,   234,   241,   234,   252,
     252,   255,   256,   259,   265,   273,   276,   284,   294,   294,
     315,   315,   315,   315,   318,   318,   320,   322,   322,   328,
     328,   334,   337,   337,   337,   340,   340,   343,   343,   346,
     362,   366,   366,   379,   384,   379,   394,   394,   408,   413,
     413,   426,   426,   429,   432,   432,   452,   452,   455,   455,
     455,   455,   455,   455,   456,   459,   460,   461,   462,   463,
     466,   466,   469,   469,   478,   478,   479,   482,   485,   488,
     494,   496,   499,   502,   505,   508,   511,   517,   524,   527,
     530,   535,   540,   545,   550,   556,   559,   565,   568,   573,
     574,   577,   580,   588,   590,   590,   594,   594,   594,   594,
     594,   594,   594,   594,   594,   595,   595,   595,   595,   595,
     595,   598,   598,   609,   609,   619,   619,   630,   630,   642,
     642,   654,   654,   678,   683,   689,   689,   693,   694,   695,
     695,   699,   699,   703,   706,   711,   711,   711,   715,   711,
     723,   723,   726,   726,   747,   750,   750,   756,   759,   759,
     763,   846,   905,   908,   913,   916,   921,   924,   929,   935,
     941,   947,   955,   956,   957,   960,   968,   977,   983,   993,
     994,   997,   998,  1001,  1004,  1005,  1009,  1010,  1016,  1019,
    1019,  1022,  1025,  1025,  1028,  1034,  1035,  1039,  1040,  1041,
    1045,  1045,  1048,  1048,  1051,  1052,  1053,  1056,  1057,  1058,
    1062,  1063,  1066,  1067,  1070,  1071,  1074,  1075,  1076,  1080,
    1084,  1087,  1090,  1091,  1092,  1095,  1096,  1099,  1102,  1103,
    1111,  1114,  1117,  1122,  1124,  1127,  1134,  1137,  1141,  1144,
    1153,  1153,  1162,  1162,  1171,  1171,  1174,  1192,  1195,  1195,
    1198,  1208,  1223,  1208,  1229,  1229,  1237,  1237,  1246,  1248,
    1259,  1259,  1262,  1304,  1319,  1370,  1373,  1373,  1376,  1381,
    1381,  1390,  1390,  1400,  1403,  1408,  1409,  1412,  1412,  1419,
    1419,  1428,  1429,  1432,  1433,  1433,  1439,  1439,  1442,  1442,
    1444,  1446,  1451,  1460,  1487,  1487,  1490,  1495,  1501,  1509,
    1516,  1527,  1532,  1527,  1540,  1540,  1554,  1555,  1556,  1557,
    1558,  1558,  1562,  1563,  1564,  1567,  1572,  1577,  1584,  1587,
    1592,  1595,  1600,  1603,  1606,  1611,  1617,  1611,  1623,  1623,
    1626,  1626,  1629,  1630,  1633,  1643,  1643,  1646,  1658,  1670,
    1682,  1694,  1702,  1710,  1718,  1732,  1748,  1755,  1762,  1769,
    1776,  1783,  1794,  1807,  1811,  1815,  1819,  1826,  1826,  1826,
    1826,  1826,  1827,  1828,  1828,  1829,  1829,  1839,  1839,  1849,
    1849,  1865,  1870,  1872,  1865,  1880,  1880,  1893,  1893,  1906,
    1906,  1920,  1920,  1931,  1934,  1937,  1942,  1948,  1951,  1954,
    1959,  1963,  1966,  1970,  1970,  1974,  1974,  1981,  1984,  1984,
    1988,  1994,  1988,  2006,  2006,  2010,  2016,  2010,  2024,  2025,
    2028,  2031,  2036,  2039,  2044,  2049,  2058,  2065,  2068,  2073,
    2077,  2083,  2083,  2087,  2087,  2091,  2092,  2095,  2100,  2100,
    2104,  2104,  2108,  2112,  2108,  2117,  2117,  2125,  2125,  2133,
    2133,  2145,  2145,  2156,  2156,  2165,  2165,  2168,  2168,  2171,
    2174,  2183,  2186,  2196,  2208,  2215,  2221,  2232,  2236,  2236,
    2246,  2250,  2254,  2257,  2262,  2265,  2268,  2272,  2276,  2280,
    2284,  2288,  2292,  2296,  2300,  2305,  2309,  2314,  2318,  2322,
    2326,  2330,  2334,  2338,  2342,  2346,  2350,  2354,  2358,  2362,
    2366,  2370,  2374,  2378,  2382,  2386,  2390,  2394,  2398,  2402,
    2406,  2410,  2416,  2419
};
#endif

#if FRONTEND_VERILOG_YYDEBUG || YYERROR_VERBOSE || 1
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TOK_STRING", "TOK_ID", "TOK_CONSTVAL",
  "TOK_REALVAL", "TOK_PRIMITIVE", "TOK_SVA_LABEL", "TOK_SPECIFY_OPER",
  "TOK_MSG_TASKS", "TOK_ASSERT", "TOK_ASSUME", "TOK_RESTRICT", "TOK_COVER",
  "TOK_FINAL", "ATTR_BEGIN", "ATTR_END", "DEFATTR_BEGIN", "DEFATTR_END",
  "TOK_MODULE", "TOK_ENDMODULE", "TOK_PARAMETER", "TOK_LOCALPARAM",
  "TOK_DEFPARAM", "TOK_PACKAGE", "TOK_ENDPACKAGE", "TOK_PACKAGESEP",
  "TOK_INTERFACE", "TOK_ENDINTERFACE", "TOK_MODPORT", "TOK_VAR",
  "TOK_INPUT", "TOK_OUTPUT", "TOK_INOUT", "TOK_WIRE", "TOK_WAND",
  "TOK_WOR", "TOK_REG", "TOK_LOGIC", "TOK_INTEGER", "TOK_SIGNED",
  "TOK_ASSIGN", "TOK_ALWAYS", "TOK_INITIAL", "TOK_BEGIN", "TOK_END",
  "TOK_IF", "TOK_ELSE", "TOK_FOR", "TOK_WHILE", "TOK_REPEAT",
  "TOK_DPI_FUNCTION", "TOK_POSEDGE", "TOK_NEGEDGE", "TOK_OR",
  "TOK_AUTOMATIC", "TOK_CASE", "TOK_CASEX", "TOK_CASEZ", "TOK_ENDCASE",
  "TOK_DEFAULT", "TOK_FUNCTION", "TOK_ENDFUNCTION", "TOK_TASK",
  "TOK_ENDTASK", "TOK_SPECIFY", "TOK_IGNORED_SPECIFY", "TOK_ENDSPECIFY",
  "TOK_SPECPARAM", "TOK_SPECIFY_AND", "TOK_GENERATE", "TOK_ENDGENERATE",
  "TOK_GENVAR", "TOK_REAL", "TOK_SYNOPSYS_FULL_CASE",
  "TOK_SYNOPSYS_PARALLEL_CASE", "TOK_SUPPLY0", "TOK_SUPPLY1",
  "TOK_TO_SIGNED", "TOK_TO_UNSIGNED", "TOK_POS_INDEXED", "TOK_NEG_INDEXED",
  "TOK_PROPERTY", "TOK_ENUM", "TOK_TYPEDEF", "TOK_RAND", "TOK_CONST",
  "TOK_CHECKER", "TOK_ENDCHECKER", "TOK_EVENTUALLY", "TOK_INCREMENT",
  "TOK_DECREMENT", "TOK_UNIQUE", "TOK_PRIORITY", "OP_LOR", "OP_LAND",
  "'|'", "OP_NOR", "'^'", "OP_XNOR", "'&'", "OP_NAND", "OP_EQ", "OP_NE",
  "OP_EQX", "OP_NEX", "'<'", "OP_LE", "OP_GE", "'>'", "OP_SHL", "OP_SHR",
  "OP_SSHL", "OP_SSHR", "'+'", "'-'", "'*'", "'/'", "'%'", "OP_POW",
  "UNARY_OPS", "FAKE_THEN", "','", "'='", "'.'", "';'", "'#'", "'('",
  "')'", "':'", "'['", "']'", "'@'", "'{'", "'}'", "'?'", "'~'", "'!'",
  "$accept", "input", "$@1", "design", "attr", "$@2", "attr_opt",
  "defattr", "$@3", "$@4", "opt_attr_list", "attr_list", "attr_assign",
  "hierarchical_id", "module", "$@5", "module_para_opt", "$@6", "$@7",
  "module_para_list", "single_module_para", "$@8", "$@9",
  "module_args_opt", "module_args", "optional_comma",
  "module_arg_opt_assignment", "module_arg", "$@10", "$@11", "$@12",
  "$@13", "package", "$@14", "package_body", "package_body_stmt",
  "interface", "$@15", "interface_body", "interface_body_stmt",
  "non_opt_delay", "delay", "wire_type", "$@16", "wire_type_token_list",
  "wire_type_token_io", "wire_type_token", "non_opt_range",
  "non_opt_multirange", "range", "range_or_multirange",
  "range_or_signed_int", "module_body", "module_body_stmt", "checker_decl",
  "$@17", "task_func_decl", "$@18", "$@19", "$@20", "$@21", "$@22",
  "dpi_function_arg", "opt_dpi_function_args", "dpi_function_args",
  "opt_automatic", "opt_signed", "task_func_args_opt", "$@23", "$@24",
  "task_func_args", "task_func_port", "$@25", "task_func_body",
  "specify_block", "specify_item_list", "specify_item", "specify_opt_arg",
  "specify_if", "specify_condition", "specify_target", "specify_edge",
  "specify_rise_fall", "specify_triple", "ignored_specify_block",
  "ignored_specify_item_opt", "ignored_specify_item",
  "specparam_declaration", "specparam_range",
  "list_of_specparam_assignments", "specparam_assignment",
  "ignspec_opt_cond", "path_declaration", "simple_path_declaration",
  "path_delay_value", "list_of_path_delay_extra_expressions",
  "specify_edge_identifier", "parallel_path_description",
  "full_path_description", "list_of_path_inputs", "more_path_inputs",
  "list_of_path_outputs", "opt_polarity_operator",
  "specify_input_terminal_descriptor",
  "specify_output_terminal_descriptor", "system_timing_declaration",
  "system_timing_arg", "system_timing_args", "path_delay_expression",
  "constant_mintypmax_expression", "ignspec_constant_expression",
  "ignspec_expr", "ignspec_id", "param_signed", "param_integer",
  "param_real", "param_range", "param_decl", "$@26", "localparam_decl",
  "$@27", "param_decl_list", "single_param_decl", "defparam_decl",
  "defparam_decl_list", "single_defparam_decl", "wire_decl", "$@28",
  "$@29", "$@30", "$@31", "opt_supply_wires", "wire_name_list",
  "wire_name_and_opt_assign", "wire_name", "assign_stmt",
  "assign_expr_list", "assign_expr", "cell_stmt", "$@32", "$@33",
  "tok_prim_wrapper", "cell_list", "single_cell", "$@34", "$@35",
  "prim_list", "single_prim", "$@36", "cell_parameter_list_opt",
  "cell_parameter_list", "cell_parameter", "cell_port_list",
  "cell_port_list_rules", "cell_port", "always_stmt", "$@37", "$@38",
  "$@39", "always_cond", "always_events", "always_event", "opt_label",
  "opt_sva_label", "opt_property", "modport_stmt", "$@40", "$@41",
  "modport_args_opt", "modport_args", "modport_arg", "modport_member",
  "modport_type_token", "assert", "assert_property",
  "simple_behavioral_stmt", "behavioral_stmt", "$@42", "$@43", "$@44",
  "$@45", "$@46", "$@47", "$@48", "$@49", "$@50", "$@51",
  "unique_case_attr", "case_attr", "case_type", "opt_synopsys_attr",
  "behavioral_stmt_list", "optional_else", "$@52", "case_body",
  "case_item", "$@53", "$@54", "gen_case_body", "gen_case_item", "$@55",
  "$@56", "case_select", "case_expr_list", "rvalue", "lvalue",
  "lvalue_concat_list", "opt_arg_list", "arg_list", "arg_list2",
  "single_arg", "module_gen_body", "gen_stmt_or_module_body_stmt",
  "gen_stmt", "$@57", "$@58", "$@59", "$@60", "$@61", "$@62",
  "gen_stmt_block", "$@63", "gen_stmt_or_null", "opt_gen_else", "expr",
  "basic_expr", "$@64", "concat_list", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   124,   352,    94,
     353,    38,   354,   355,   356,   357,   358,    60,   359,   360,
      62,   361,   362,   363,   364,    43,    45,    42,    47,    37,
     365,   366,   367,    44,    61,    46,    59,    35,    40,    41,
      58,    91,    93,    64,   123,   125,    63,   126,    33
};
# endif

#define YYPACT_NINF -907

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-907)))

#define YYTABLE_NINF -421

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    -907,    93,   249,  -907,  -907,    96,  -907,   439,  -907,   249,
     249,   249,   249,   249,   249,   249,   101,  -907,   116,  -907,
    -907,   118,   151,    91,    91,   141,  -907,  -907,  -907,  -907,
    -907,  -907,  -907,  -907,  -907,    59,  -907,    97,    57,  -907,
     156,   156,  -907,    62,  -907,   161,   210,   101,   207,   101,
     247,  1472,   272,   125,   201,    57,  -907,   206,   206,   221,
    -907,   347,   356,  -907,    48,  -907,   319,  -907,  -907,  -907,
    -907,   357,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,
    -907,  -907,  -907,  1472,  1472,  -907,  -907,   196,  -907,  -907,
    1624,  -907,  -907,    66,   241,   201,  -907,   295,   295,  -907,
     253,   384,   279,  -907,  1472,  -907,  -907,   403,   281,  -907,
    -907,   296,   303,  1472,  1472,  1472,  1472,  1472,  1472,  1472,
    1472,     6,   -25,   305,  1472,  1472,  -907,  1472,  -907,   311,
     311,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,
    -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,
    -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,   121,
     440,   326,  -907,  -907,   334,  -907,  -907,   337,  -907,   311,
     311,   441,   461,   345,  -907,   469,    30,  -907,   352,   359,
    1472,  1472,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,
     478,  1472,  1472,  1472,  -907,  -907,  -907,    45,   417,  -907,
    -907,  1472,  1472,  1472,  1472,  1472,  1472,  1472,  1472,  1472,
    1472,  1472,  1472,  1472,  1472,  1472,  1472,  1472,  1472,  1472,
    1472,  1472,  1472,  1472,  1472,  1472,  1472,  1472,   378,   242,
     429,  -907,  -907,   442,   556,   445,   311,  1376,    88,   438,
     335,  -907,  -907,   560,   560,  -907,   542,  -907,  -907,   568,
    -907,   131,  -907,   253,   571,  1472,  1472,  1472,  -907,   281,
    -907,   572,  -907,   448,   451,  -907,   452,   458,  -907,   449,
     460,  1472,  2036,  2060,  2082,  2082,  2102,  2102,  2120,  2120,
    1638,  1638,  1638,  1638,   541,   541,   541,   541,   389,   389,
     389,   389,   318,   318,   463,   463,   463,  -907,   464,  1472,
    -907,  -907,   121,   462,  1472,  -907,  -907,  -907,   586,  -907,
    -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,
    -907,  -907,  -907,   750,  -907,  -907,  -907,  -907,   311,  -907,
     592,   471,   309,  -907,  -907,  -907,  -907,  -907,  -907,  -907,
    -907,  1854,   252,  -907,   257,  -907,   461,  -907,   473,  -907,
     465,   468,   472,   479,   311,  -907,   483,  -907,  -907,    73,
    -907,  -907,  1472,   474,   101,   485,  -907,  -907,  -907,  1472,
    -907,   156,   156,  -907,  -907,  -907,   442,  -907,    68,  -907,
    -907,  -907,   101,   285,  -907,  -907,    51,  -907,  -907,   607,
     609,   311,   486,  -907,  -907,   487,   490,   491,  -907,  -907,
    -907,   114,   214,    52,  -907,   618,  1040,  -907,  -907,  -907,
    -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,
    -907,   435,  -907,   496,  -907,   560,  -907,  -907,  -907,  -907,
     253,  -907,  -907,  -907,  -907,   311,  -907,  -907,   311,    65,
    -907,  -907,  -907,  -907,  1472,   659,  -907,   143,   817,  -907,
    -907,  -907,   503,  -907,   499,  -907,   470,  -907,   310,   497,
    -907,    27,  -907,  1472,   498,  -907,   206,   206,  -907,   442,
    -907,  -907,  -907,  1472,   504,   311,  -907,   501,   332,  -907,
     514,   507,   817,  -907,  -907,  -907,  -907,   515,   638,  -907,
    1472,  -907,   516,   517,   578,   114,   519,  -907,   538,  -907,
     316,  -907,  -907,   544,  -907,   545,  -907,   546,  1472,   669,
     349,  -907,   551,  1916,   550,  -907,  -907,  -907,   471,   597,
     600,   601,   603,  1472,  -907,   561,   476,  -907,  -907,   562,
    -907,   563,   574,   487,   567,   573,   575,   577,  -907,  -907,
    -907,  -907,  -907,    67,    67,    67,    89,  -907,   583,  -907,
    -907,   471,   471,  -907,  -907,  -907,   311,   311,  -907,   155,
    1472,  -907,    64,  -907,    51,  -907,  1472,    23,  -907,  -907,
    -907,  -907,   572,  1472,   576,  -907,  -907,   570,    51,   342,
    1472,  -907,  -907,   342,  1472,  -907,  -907,   202,   588,   591,
    -907,   801,   590,  -907,   370,   669,  -907,  1472,  -907,  -907,
    -907,  -907,  -907,   594,  -907,   595,   596,   598,   602,   593,
    -907,  -907,   572,  -907,   515,  -907,  1472,  -907,  1472,  -907,
    1472,  1472,   320,  -907,  -907,   515,  -907,  -907,   604,   605,
     606,  -907,   610,  1472,  1472,  1472,   560,   560,  -907,  1472,
    -907,  -907,  -907,  -907,  -907,   612,  -907,  -907,   696,   599,
    -907,  -907,   614,  -907,   759,   817,   374,   397,   616,  -907,
     621,   485,  -907,  1981,  -907,   623,  -907,  -907,  1472,   619,
    1472,   625,  -907,  -907,  -907,   669,   611,    -8,  -907,  1514,
    1514,   669,   669,  -907,   211,  -907,  1472,  -907,  -907,  -907,
     617,  -907,   627,   746,   746,  1033,  1075,  1135,  1472,  -907,
    -907,   630,  -907,  -907,   631,    51,   632,   637,   633,  1177,
    1201,  1243,  1303,   639,  -907,  -907,  -907,  -907,   642,    98,
     644,  -907,  -907,  -907,  -907,  1472,  1472,   645,    58,  -907,
    -907,  -907,   771,  -907,  -907,   572,   651,  1472,   649,   487,
    -907,  1472,   709,  -907,   774,  -907,   663,   354,   674,  -907,
    -907,   669,   147,   670,  1472,  -907,   672,  -907,  -907,  -907,
    -907,   801,   667,   664,  1472,  1792,  1345,   311,   398,  -907,
    -907,   399,  -907,   671,  1472,   668,  1472,   673,  1472,   679,
     680,  -907,  -907,   543,  -907,   675,  -907,  -907,  -907,  1472,
     681,  1472,   685,  1472,   687,   677,   689,  -907,  1472,  -907,
    -907,  -907,  -907,  -907,   927,   927,  -907,  -907,  -907,  -907,
    -907,  -907,  -907,   752,  2043,  -907,  1472,   697,  1538,   712,
     714,  -907,   669,  -907,   669,  -907,   716,   672,     6,  1472,
    -907,  -907,  -907,  -907,   703,  -907,   830,   215,  -907,  -907,
    -907,   717,   746,  -907,   746,  -907,  -907,   711,   722,   713,
     723,   721,   725,   727,   802,   487,  -907,   817,  1472,   817,
     817,   734,   740,   738,   742,   741,   743,  -907,   745,  -907,
     744,  -907,  -907,   753,  -907,  -907,   756,  -907,   342,  1472,
     749,  -907,   755,   757,   216,  -907,  -907,  -907,   669,   760,
     672,  1472,   758,  1345,  -907,   762,  -907,  -907,  -907,  1387,
     763,   765,  -907,   768,  -907,   778,  -907,   779,  -907,  -907,
    -907,  -907,  1009,  -907,   824,  -907,  -907,  -907,   780,  -907,
     781,  -907,   782,  -907,  -907,   436,  -907,  -907,  -907,  -907,
      51,  1472,   276,   767,   669,   669,   669,  -907,   783,  -907,
    -907,  -907,  1472,  -907,  -907,   784,   905,  -907,  -907,  -907,
    -907,  -907,  -907,  -907,   -20,  -907,     9,  -907,  -907,  -907,
     785,  -907,  -907,  -907,  -907,  -907,   850,   786,   709,  1472,
    1472,  1472,  1580,   256,   274,  -907,  -907,   789,   791,  -907,
     793,  -907,   753,  1472,  -907,   817,    51,  -907,  -907,  1009,
    -907,   803,   798,   799,   402,  1472,   808,  -907,   807,  1472,
     810,  1472,   811,  -907,  -907,  1430,  -907,  -907,  -907,   816,
    -907,  -907,  1472,  -907,  -907,  -907,   823,   411,  -907,  1472,
     818,  1472,   820,  1472,  -907,   821,  -907,   817,   832,  1472,
    1472,   826,   828,   831,   833,   834,  -907,   817,  -907,  1472,
     835,   837,   829,  1472,  -907,   838,  -907,   842,  -907,  -907,
     827,  -907,  1472,  -907,  -907,  -907,  -907,   497
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       2,     0,    12,     1,    16,     0,     3,     0,    15,    12,
      12,    12,    12,    12,    12,    12,    20,    64,     0,   250,
     252,     0,     0,   152,   152,    13,     5,     4,     9,    10,
       6,     7,     8,    25,    17,    19,    21,    23,    33,    28,
     244,   244,    59,     0,   151,   154,     0,    20,     0,     0,
       0,     0,     0,     0,    43,    33,   243,   246,   246,     0,
     133,     0,     0,   153,   108,   139,     0,    18,    22,    26,
     467,   465,   466,    12,    12,    12,    12,    12,    12,    12,
      12,    12,    12,     0,     0,    12,    12,   108,   461,    24,
     459,    27,    30,    12,     0,    43,   245,   248,   248,    62,
     146,     0,     0,   112,     0,   107,   111,     0,   156,    14,
     464,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   512,     0,     0,     0,   463,     0,   468,   107,
     426,   425,    12,    12,    12,    12,    12,    12,    12,    12,
      12,    12,    12,    12,    12,    12,    12,    12,    12,    12,
      12,    12,    12,    12,    12,    12,    12,    12,    12,    12,
      51,     0,    42,    82,    48,    45,    67,     0,   247,   108,
     108,    12,   150,     0,   135,     0,     0,   141,   157,     0,
       0,     0,   485,   486,   487,   488,   483,   484,   507,   508,
     472,     0,     0,     0,   474,   476,   511,     0,     0,   105,
     106,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      31,    34,    41,    50,     0,     0,   108,     0,    12,     0,
      12,   115,   249,     0,     0,    60,     0,    61,    63,   144,
     149,     0,   134,   146,     0,     0,     0,     0,   104,   156,
     155,    12,   166,     0,     0,   462,     0,   512,   513,     0,
     104,   434,   510,   509,   479,   480,   481,   482,   477,   478,
     495,   496,   497,   498,   493,   494,   499,   500,   489,   490,
     491,   492,   501,   502,   503,   504,   505,   506,     0,     0,
      37,    39,    12,     0,     0,    52,    54,    58,     0,    95,
      87,    88,    89,    90,    92,    91,    93,    94,    96,    98,
      97,    99,   100,    81,    86,    84,    46,    44,   108,    65,
       0,    81,    82,    66,    68,    69,    70,    71,    73,    72,
      74,    12,     0,   254,     0,   143,   148,   145,     0,   137,
       0,     0,     0,     0,   108,    82,    48,   160,   164,    12,
     470,   471,     0,     0,     0,    48,   433,   435,   437,     0,
     256,   244,   244,    35,    32,    49,    50,    56,     0,    80,
      83,    85,     0,     0,   258,   335,     0,   311,   314,     0,
       0,   108,     0,   451,    29,   329,     0,     0,   397,   398,
     399,   169,   203,     0,   439,     0,    82,   127,   113,   129,
     116,   117,   130,   121,   118,   119,   120,   122,   123,   124,
     125,     0,   128,     0,   114,     0,   251,   253,   147,   136,
     146,   102,   103,   101,   166,   110,   109,   274,   108,    12,
     158,    12,   140,   374,     0,    82,   367,   108,    12,   370,
     371,   369,     0,   368,     0,   165,     0,   427,     0,     0,
     475,   108,   424,    47,     0,   460,   246,   246,    55,    50,
      75,    76,    77,     0,     0,   108,   257,     0,     0,   276,
       0,   321,    12,   264,   266,   261,   330,   432,     0,   449,
       0,   442,     0,     0,     0,   169,     0,   242,     0,   190,
     203,   192,   193,     0,   194,     0,   195,     0,     0,     0,
       0,   199,     0,    12,     0,   279,   283,   284,    81,     0,
       0,     0,     0,     0,   255,     0,    12,   162,   161,     0,
     377,     0,   429,   329,     0,     0,     0,     0,    12,    12,
     396,   375,   372,   334,   334,   334,   334,   373,     0,   364,
     365,    81,    81,   473,   436,   469,   108,   108,    57,     0,
       0,   259,     0,   336,     0,   275,     0,     0,   312,   315,
     268,   268,     0,   434,     0,   328,   439,     0,     0,   184,
       0,   167,   168,   184,     0,   189,   191,     0,     0,     0,
     204,     0,     0,   240,     0,     0,   196,     0,   126,   441,
     438,   440,   131,   297,   281,     0,     0,     0,     0,     0,
     138,   142,     0,   159,   432,   428,     0,   379,     0,   381,
       0,     0,   393,   395,   394,   432,   333,   332,     0,     0,
       0,   353,     0,     0,     0,     0,     0,     0,    78,     0,
     260,   344,   345,   346,   338,    48,   340,   343,     0,     0,
     277,   278,     0,   320,     0,    12,     0,     0,   262,   270,
     272,    48,   452,    12,   445,     0,   182,   183,     0,     0,
       0,     0,   241,   212,   213,     0,     0,   228,   229,     0,
       0,     0,     0,   235,     0,   234,     0,   197,   200,   201,
     238,   115,     0,     0,   294,     0,     0,     0,     0,   447,
     163,     0,   430,   404,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   366,   363,    38,    40,     0,    47,
       0,   342,   337,   318,   319,     0,     0,     0,     0,   322,
     327,   313,     0,   265,   267,     0,     0,     0,     0,   329,
     453,     0,   177,   174,     0,   202,     0,   228,     0,   226,
     227,     0,   228,   220,     0,   205,   208,   237,   206,   232,
     233,     0,     0,     0,     0,    12,   300,   287,     0,   285,
     293,     0,   291,     0,     0,     0,     0,     0,     0,     0,
       0,   414,   378,    12,   389,     0,   385,   387,   376,     0,
       0,     0,     0,     0,     0,     0,     0,   391,     0,   341,
     339,   325,   326,   317,     0,     0,   316,   269,   271,   263,
     273,   431,   450,   458,    12,   443,     0,     0,     0,     0,
       0,   220,     0,   222,     0,   221,     0,     0,   240,     0,
     209,   236,   231,   198,     0,   132,     0,     0,   298,   301,
     289,     0,     0,   280,   294,   282,    12,     0,     0,     0,
       0,     0,     0,     0,   415,   329,   403,    12,     0,    12,
      12,     0,     0,     0,     0,     0,     0,   352,     0,   402,
       0,   323,   324,   453,   446,   454,     0,   176,   184,     0,
       0,   178,     0,     0,     0,   224,   230,   223,     0,     0,
     210,     0,     0,   300,   296,     0,    12,   286,   292,   306,
       0,   303,   304,     0,   356,     0,   357,     0,   361,   360,
     448,   413,     0,   380,   407,   382,   386,   388,     0,   347,
       0,   348,     0,   354,   351,   409,    79,   456,   455,   457,
       0,     0,     0,     0,     0,     0,     0,   217,     0,   207,
     211,   239,     0,   299,    12,     0,     0,   307,   295,    12,
     358,   359,   362,   421,   419,   416,     0,   422,   405,   390,
       0,   349,   350,   355,   400,   401,   410,     0,   177,     0,
       0,     0,     0,   228,   228,   225,   214,     0,     0,   288,
     310,   305,   453,     0,   418,    12,     0,   392,   408,     0,
     453,     0,     0,     0,     0,     0,     0,   185,   187,     0,
       0,     0,     0,   302,   290,     0,   417,   423,   406,     0,
     411,   444,     0,   181,   180,   179,     0,   187,   170,     0,
       0,     0,     0,     0,   309,     0,   383,    12,   173,     0,
       0,     0,     0,     0,     0,     0,   308,    12,   412,     0,
       0,     0,     0,     0,   219,     0,   216,     0,   384,   172,
       0,   186,     0,   188,   218,   215,   171,   188
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -907,  -907,  -907,   622,   154,  -907,  -907,    50,  -907,  -907,
     914,  -907,   924,   -16,  -907,  -907,   920,  -907,  -907,  -907,
     676,  -907,  -907,   882,  -907,  -331,  -298,   747,  -907,  -907,
    -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,
    -202,  -293,  -139,  -907,  -907,  -907,   656,   -79,   634,     7,
    -907,  -907,   293,  -338,  -907,  -907,  -340,  -907,  -907,  -907,
    -907,  -907,   640,  -225,  -907,   963,  -907,   730,  -907,  -907,
    -907,   552,  -907,   559,  -907,   495,  -907,  -907,  -907,    26,
    -907,  -560,  -907,  -906,  -907,  -907,   502,  -326,  -907,   488,
     400,  -907,  -907,  -907,   321,  -737,  -907,  -907,  -907,   323,
    -907,    69,  -694,  -635,  -793,  -907,   238,  -907,  -675,  -907,
    -498,  -582,  -183,   -30,   -46,   906,  -157,    33,  -907,     5,
    -907,   764,  -214,   769,  -907,   535,  -235,  -907,  -907,  -907,
    -907,   447,  -907,   284,  -545,   776,  -907,   456,  -907,  -907,
    -907,  -907,  -907,  -644,  -907,  -907,  -907,   178,  -907,  -907,
    -907,   130,  -795,  -907,    81,   792,  -907,  -907,  -907,  -907,
    -907,  -262,  -501,  -335,   -10,  -907,  -907,  -907,  -907,  -907,
     312,   385,  -907,  -907,  -907,  -557,  -407,  -907,  -907,  -907,
    -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,    11,   579,
    -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,  -907,
    -907,  -907,    56,  -907,  -245,  -360,   418,  -497,   467,  -907,
     585,   475,   227,  -332,  -907,  -907,  -907,  -907,  -907,  -907,
    -718,  -907,    70,  -907,   -47,  1573,  -907,   366
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,     2,     6,   445,     8,    25,   446,    16,    48,
      34,    35,    36,    87,    10,    55,    54,   159,   303,   230,
     231,   371,   372,    94,   164,   239,   305,   165,   233,   234,
     376,   469,    11,    59,   171,   247,    12,    38,   240,   333,
     448,   380,   391,   237,   323,   324,   325,   105,   130,   242,
     437,   107,   341,   599,   409,   691,    13,   100,   253,   430,
     108,   259,   250,   173,   251,    45,    64,   179,   261,   529,
     356,   357,   612,   359,   411,   494,   495,  1040,   496,   817,
     880,   668,   996,   997,   412,   500,   501,   413,   509,   510,
     511,   503,   504,   505,   755,   830,   675,   588,   589,   676,
     752,   884,   753,   677,   885,   506,   683,   684,   756,   689,
     757,   685,   886,    57,    97,   169,   243,   449,    40,   450,
      41,   342,   232,   416,   383,   384,   451,   572,   736,   570,
     571,   656,   658,   659,   358,   418,   478,   479,   419,   603,
     694,   518,   768,   770,   841,   895,   771,   772,   773,   693,
     837,   838,   900,   901,   902,   420,   481,   655,   482,   568,
     728,   729,   489,   452,   628,   340,   477,   649,   563,   645,
     646,   647,   648,   453,   422,   454,   455,   625,   614,   703,
     705,   960,  1037,   859,   860,   857,   869,   540,   456,   423,
     925,   783,   959,   985,   966,   988,   989,  1027,   854,   911,
     912,   982,   955,   956,    88,   458,   531,   574,   365,   366,
     367,   513,   600,   601,   578,   876,   740,   781,   576,   487,
     928,   814,   929,   874,   593,    90,   198,   123
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      37,   410,   671,   408,    89,   337,   421,    15,   129,   424,
     592,    58,    98,   244,    15,    15,    15,    15,    15,    15,
      15,   665,   813,   670,   236,   440,   480,   660,   348,   343,
     343,    37,   617,    37,   464,    14,   121,   122,   386,   652,
     747,   542,    14,    14,    14,    14,    14,    14,    14,   769,
     199,   200,     9,   821,    50,    33,   497,   176,   825,     9,
       9,     9,     9,     9,     9,     9,    60,   700,   641,   354,
     160,   106,   470,   471,   472,   569,   502,    33,   468,   827,
     197,   392,   626,   441,  -331,  -331,  -331,  -331,   103,  1016,
     889,     4,   160,     3,   131,   938,   642,   643,   192,   690,
      17,   945,   641,  -420,   626,    33,   417,   749,   750,   193,
    -420,   255,   256,   804,   457,   751,   823,   701,   492,   462,
      39,   379,    42,  1041,    50,   228,   255,   256,   708,   379,
     642,   643,   983,   263,   264,   190,   191,   474,   442,   984,
     653,   457,   974,   975,   266,   267,   267,    44,   785,   978,
     627,   654,    52,   940,   890,    43,     7,    47,   127,   -12,
     257,   493,   258,     7,     7,     7,     7,     7,     7,     7,
      50,   558,   627,   410,   502,   257,   248,   270,   421,   104,
     298,   805,    49,   508,    53,   444,    61,   806,   763,   887,
     660,   161,    62,   644,   -47,   162,   473,    56,   897,   443,
     378,   126,    63,   457,   480,   525,   497,   444,   350,   351,
     352,   524,   -12,   161,    65,   631,   438,   -47,   497,   507,
     512,    51,    52,    50,   368,   604,    67,   111,   112,   113,
     114,   115,   116,   117,   118,   119,   120,   457,   812,   124,
     125,   128,  -175,   308,   -36,   335,    96,   163,   731,   -11,
     -36,    69,   370,    92,   346,   673,   674,   375,   634,   635,
     347,   498,   749,   750,   300,   301,   834,     4,    52,   -12,
     824,   -12,  1011,   334,   127,   129,    91,     5,   417,  1000,
    1002,   457,   499,   403,   638,   639,   201,   202,   203,   204,
     205,   206,   207,   208,   209,   210,   211,   212,   213,   214,
     215,   216,   217,   218,   219,   220,   221,   222,   223,   224,
     225,   226,   227,   229,   720,   459,   379,   507,   931,   457,
     497,    52,   465,   410,   -12,   246,   512,   127,   421,    93,
     738,    19,    20,   457,   761,   382,   109,   999,   893,   936,
     762,   466,   467,   447,   894,   937,   415,    99,   461,   379,
     379,   101,   387,   388,   913,  1001,   200,   969,   970,   328,
     102,   436,   110,   498,   329,   330,   461,   166,   129,   168,
     461,   749,   750,   967,   414,   425,   856,   331,   426,   936,
     425,   172,   129,   427,   585,   403,   389,   390,   174,   749,
     750,   407,   163,   941,   332,   666,   667,   532,   485,   636,
     637,   549,   550,   175,   678,   190,   971,   177,   475,   178,
     457,   476,   512,   538,   539,   355,   368,  1020,   551,  1022,
     556,   557,   716,   717,   180,   410,   559,   408,   417,  1009,
     421,   181,   447,   424,   552,   154,   155,   156,   157,  1033,
     194,  1035,   104,   577,   -53,   527,   519,   520,   521,   522,
     914,   235,   916,   917,   131,   564,   229,   238,   565,    18,
     457,    19,    20,   241,    21,   249,   447,   245,   131,   749,
     750,   252,   595,   254,   410,   596,   609,   751,   820,   421,
      33,   260,   382,   265,   392,   262,   441,  -331,  -331,  -331,
    -331,    22,   678,   595,     4,   406,   687,   732,   759,   760,
     733,    23,   299,    24,   152,   153,   154,   155,   156,   157,
     447,   964,   965,   640,   543,   544,   545,   546,   415,   651,
     732,   842,   844,   734,   843,   845,   368,   398,   399,   400,
     417,  1015,   362,   669,   629,   630,   632,   672,   457,   611,
     190,  1030,   871,   872,   672,   271,   414,    33,   461,   623,
     624,   392,   302,   441,  -331,  -331,  -331,  -331,   268,   269,
     306,     4,   461,   407,   228,    20,   304,   327,   678,   532,
     307,   704,   345,   706,   707,   349,   354,   360,  1008,   417,
     361,   192,   362,   157,   363,   364,   713,   714,   715,   855,
     377,   374,   718,   355,   369,   530,   385,   431,   378,   429,
     432,   541,   443,   378,   433,   434,   439,   730,   463,   460,
     444,   483,   457,   484,   457,   457,   486,   488,   490,   491,
    1038,   742,   514,   744,   523,   547,   553,   555,   560,   562,
    1048,    26,    27,    28,    29,    30,    31,    32,   566,   447,
     567,   678,   575,   573,   579,   580,   581,   583,   775,   777,
     779,   780,   148,   149,   150,   151,   152,   153,   154,   155,
     156,   157,   790,   792,   794,   796,   584,   406,   415,   443,
     378,   590,   587,   497,   591,   597,   602,   444,   801,   802,
     605,    19,    20,   606,   607,   457,   608,   610,   840,   461,
     810,   613,   622,   622,   815,   618,   414,   616,   615,   664,
     641,   619,   662,   620,   533,   621,   534,   828,   535,   536,
     537,   633,   679,   407,   672,   680,  -393,  -393,  -393,   839,
     686,   692,   699,   695,   696,   722,   697,   847,   748,   849,
     698,   851,   709,   710,   711,   719,   389,   390,   712,   735,
     457,   457,   861,   723,   863,   737,   865,   764,   743,   741,
     767,   870,   538,   539,   745,   766,   782,   730,   730,   788,
     784,   786,    70,    33,    71,    72,   787,   447,   797,   877,
     415,   881,   798,   800,   803,   807,   724,   809,   811,   816,
     819,   309,   457,   818,   822,   313,   314,   315,   316,   317,
     318,   319,   457,   832,   826,   829,   833,   848,   414,   846,
     873,   858,   850,   867,    70,    33,    71,    72,   852,   853,
     862,   915,   725,   726,   864,   407,   866,   406,   868,   415,
     878,    33,   882,   320,   883,   392,   888,   441,  -331,  -331,
    -331,  -331,   932,   891,   892,     4,   321,   322,    73,    74,
     903,   447,   905,   447,   447,   896,   839,   414,   904,   906,
     907,   908,   947,   909,   681,   682,    75,    76,    77,    78,
      79,    80,   910,   918,   407,   957,   919,   920,   921,   923,
     922,   924,   958,   926,    81,    82,   727,   378,   933,   927,
      73,    74,   930,   934,   968,   935,   942,    83,   949,   939,
     944,   972,   948,    84,   950,   977,    85,    86,    75,    76,
      77,    78,    79,    80,   951,   952,   961,   962,   963,   980,
     987,   986,   976,   979,   461,   990,    81,    82,  1003,   406,
    1004,  1005,   992,   993,   994,   998,  1012,  1013,  1014,    83,
      70,    33,    71,    72,  1018,    84,  1007,  1019,    85,    86,
    1021,  1023,   957,   443,   378,  1026,  1029,  1032,  1017,  1034,
    1036,   444,   672,  1056,   672,  1039,  1043,  1044,  1025,  1052,
    1045,    66,  1046,  1047,  1050,  1028,  1051,  1054,   406,   447,
     461,  1055,  1031,    68,   672,    95,   672,   167,   373,   381,
     725,   726,   998,  1042,   765,   326,   428,    46,   435,   353,
     582,   528,  1049,   526,   991,   688,  1053,   594,   746,   831,
     899,   758,   586,   973,   170,  1057,    73,    74,   344,   336,
     561,   447,    70,    33,    71,    72,   338,   953,   657,   808,
     650,   447,   898,   943,    75,    76,    77,    78,    79,    80,
     981,   799,   339,   721,   702,   548,    70,    33,    71,    72,
     661,   875,    81,    82,   515,  1010,     0,   516,   554,     0,
     899,   663,  1006,     0,     0,    83,     0,     0,     0,     0,
       0,    84,    19,    20,    85,    86,     0,     0,     0,     0,
     954,     0,     0,     0,     0,     0,     0,     0,    70,    33,
      71,    72,     0,   387,   388,     0,     0,     0,    73,    74,
       0,     0,    22,     0,     0,   517,     0,     0,   899,     0,
       0,     0,    23,   899,    24,     0,    75,    76,    77,    78,
      79,    80,    73,    74,     0,     0,     0,   389,   390,     0,
       0,     0,     0,   774,    81,    82,     0,     0,     0,     0,
      75,    76,    77,    78,    79,    80,     0,    83,    70,    33,
      71,    72,     0,    84,     0,     0,    85,    86,    81,    82,
       0,     0,     0,     0,    73,    74,     0,     0,     0,     0,
       0,    83,     0,     0,     0,   776,     0,    84,     0,     0,
      85,    86,    75,    76,    77,    78,    79,    80,     0,     0,
      70,    33,    71,    72,     0,     0,     0,     0,     0,     0,
      81,    82,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    83,    70,    33,    71,    72,     0,    84,
       0,     0,    85,    86,    73,    74,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   778,     0,     0,     0,     0,
       0,     0,    75,    76,    77,    78,    79,    80,     0,     0,
       0,     0,     0,     0,     0,     0,    70,    33,    71,    72,
      81,    82,     0,     0,     0,     0,    73,    74,     0,     0,
       0,     0,     0,    83,     0,     0,     0,   789,     0,    84,
       0,     0,    85,    86,    75,    76,    77,    78,    79,    80,
      73,    74,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   791,    81,    82,     0,     0,     0,     0,    75,    76,
      77,    78,    79,    80,     0,    83,    70,    33,    71,    72,
       0,    84,     0,     0,    85,    86,    81,    82,     0,     0,
       0,     0,    73,    74,     0,     0,     0,     0,     0,    83,
       0,     0,     0,   793,     0,    84,     0,     0,    85,    86,
      75,    76,    77,    78,    79,    80,     0,     0,    70,    33,
      71,    72,     0,     0,     0,     0,     0,     0,    81,    82,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    83,     0,     0,     0,     0,     0,    84,     0,     0,
      85,    86,    73,    74,     0,     0,     0,     0,     0,     0,
      70,    33,    71,    72,     0,     0,     0,     0,     0,     0,
      75,    76,    77,    78,    79,    80,     0,   309,   310,   311,
     312,   313,   314,   315,   316,   317,   318,   319,    81,    82,
       0,     0,     0,     0,    73,    74,     0,     0,     0,     0,
       0,    83,   795,    70,    33,    71,    72,    84,     0,     0,
      85,    86,    75,    76,    77,    78,    79,    80,     0,   320,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      81,    82,   321,   322,     0,     0,    73,    74,     0,     0,
     836,     0,     0,    83,     0,    70,    33,    71,    72,    84,
       0,     0,    85,    86,    75,    76,    77,    78,    79,    80,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    81,    82,     0,     0,     0,     0,     0,    73,
      74,     0,   946,     0,     0,    83,     0,    70,    33,    71,
      72,    84,     0,     0,    85,    86,     0,    75,    76,    77,
      78,    79,    80,     0,     0,     0,     0,     0,     0,     0,
       0,    70,    33,    71,    72,    81,    82,     0,     0,     0,
       0,    73,    74,     0,     0,     0,     0,     0,    83,  1024,
       0,     0,     0,     0,    84,     0,     0,    85,    86,    75,
      76,    77,    78,    79,    80,     0,     0,     0,     0,     0,
       0,     0,     0,    70,    33,    71,    72,    81,    82,     0,
       0,     0,     0,    73,    74,     0,     0,     0,     0,     0,
      83,     0,     0,     0,     0,     0,    84,     0,     0,    85,
      86,    75,    76,    77,    78,    79,    80,    73,    74,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    81,
      82,     0,     0,     0,     0,    75,    76,    77,    78,    79,
      80,     0,   754,     0,     0,     0,     0,     0,    84,     0,
       0,    85,    86,    81,    82,     0,     0,     0,     0,    73,
      74,     0,     0,     0,     0,     0,   879,     0,     0,     0,
       0,     0,    84,     0,     0,    85,    86,    75,    76,    77,
      78,    79,    80,     0,     0,     0,   182,   183,   184,   185,
     186,   187,   188,   189,     0,    81,    82,   195,   196,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   995,     0,
       0,     0,     0,     0,    84,     0,     0,    85,    86,   132,
     133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
     143,   144,   145,   146,   147,   148,   149,   150,   151,   152,
     153,   154,   155,   156,   157,   144,   145,   146,   147,   148,
     149,   150,   151,   152,   153,   154,   155,   156,   157,     0,
     158,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   272,   273,   274,   275,   276,   277,
     278,   279,   280,   281,   282,   283,   284,   285,   286,   287,
     288,   289,   290,   291,   292,   293,   294,   295,   296,   297,
     392,     0,   393,  -331,  -331,  -331,  -331,     0,     0,     0,
       4,     0,     0,     0,     0,     0,   328,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   331,     0,     0,   395,     0,   396,
       0,   397,     0,     0,     0,     0,     0,     0,     0,   398,
     399,   400,     0,     0,     0,     0,     0,     0,   401,   402,
       0,   403,   392,   404,   393,  -331,  -331,  -331,  -331,     0,
       0,     0,     4,     0,     0,   394,     0,     0,   328,     0,
     405,   835,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   331,     0,     0,   395,
       0,   396,     0,   397,     0,     0,     0,     0,     0,     0,
       0,   398,   399,   400,     0,     0,     0,     0,     0,     0,
     401,   402,     0,   403,   392,   404,   393,  -331,  -331,  -331,
    -331,     0,     0,     0,     4,     0,     0,     0,     0,     0,
     328,     0,   405,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   331,     0,
       0,   395,     0,   396,     0,   397,     0,     0,     0,     0,
       0,     0,     0,   398,   399,   400,     0,     0,     0,     0,
       0,     0,   401,   402,     0,   403,     0,   404,   598,   392,
       0,   393,  -331,  -331,  -331,  -331,     0,     0,     0,     4,
       0,     0,     0,     0,   405,   328,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   331,     0,     0,   395,   739,   396,     0,
     397,     0,     0,     0,     0,     0,     0,     0,   398,   399,
     400,     0,     0,     0,     0,     0,     0,   401,   402,     0,
     403,   392,   404,   393,  -331,  -331,  -331,  -331,     0,     0,
       0,     4,     0,     0,     0,     0,     0,   328,     0,   405,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   331,     0,     0,   395,     0,
     396,     0,   397,     0,     0,     0,     0,     0,     0,     0,
     398,   399,   400,     0,     0,     0,     0,     0,     0,   401,
     402,     0,   403,     0,   404,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   405,   133,   134,   135,   136,   137,   138,   139,   140,
     141,   142,   143,   144,   145,   146,   147,   148,   149,   150,
     151,   152,   153,   154,   155,   156,   157,   134,   135,   136,
     137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
     147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
     157,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
     155,   156,   157,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
     155,   156,   157,   140,   141,   142,   143,   144,   145,   146,
     147,   148,   149,   150,   151,   152,   153,   154,   155,   156,
     157
};

static const yytype_int16 yycheck[] =
{
      16,   341,   584,   341,    51,   240,   341,     2,    87,   341,
     508,    41,    58,   170,     9,    10,    11,    12,    13,    14,
      15,   578,   740,   583,   163,   356,   386,   572,   253,   243,
     244,    47,   533,    49,   365,     2,    83,    84,   331,    16,
     675,   448,     9,    10,    11,    12,    13,    14,    15,   693,
     129,   130,     2,   747,    27,     4,     4,   104,   752,     9,
      10,    11,    12,    13,    14,    15,     4,   612,     4,     4,
       4,    64,     4,     5,     6,   482,   402,     4,   376,   754,
     127,     8,    15,    10,    11,    12,    13,    14,    40,   995,
     827,    18,     4,     0,    87,   888,    32,    33,   123,   597,
       4,   896,     4,   123,    15,     4,   341,   115,   116,   134,
     130,    81,    82,    55,   359,   123,   751,   614,     4,   364,
       4,   323,     4,  1029,    27,     4,    81,    82,   625,   331,
      32,    33,   123,   180,   181,   129,   130,   382,    65,   130,
     117,   386,   935,   936,   191,   192,   193,    56,   705,   944,
      83,   128,   125,   890,   829,     4,     2,    16,   131,    16,
     130,    47,   132,     9,    10,    11,    12,    13,    14,    15,
      27,   469,    83,   513,   500,   130,   171,   132,   513,   131,
     227,   123,   123,   131,   127,   134,   124,   129,   686,   824,
     735,   125,   130,   129,   129,   129,   128,    41,   842,   126,
     127,     5,    41,   448,   564,   430,     4,   134,   255,   256,
     257,   425,    16,   125,     4,   126,   355,   129,     4,   402,
     403,   124,   125,    27,   271,   518,    19,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,   482,   739,    85,
      86,    87,   128,   236,   123,   240,    40,    93,   655,     0,
     129,     4,   299,   128,   123,    53,    54,   304,   551,   552,
     129,    47,   115,   116,    22,    23,   764,    18,   125,   126,
     123,   128,   990,   240,   131,   354,     4,    28,   513,   973,
     974,   526,    68,    69,   129,   130,   132,   133,   134,   135,
     136,   137,   138,   139,   140,   141,   142,   143,   144,   145,
     146,   147,   148,   149,   150,   151,   152,   153,   154,   155,
     156,   157,   158,   159,   645,   362,   518,   500,   878,   564,
       4,   125,   369,   663,   128,   171,   509,   131,   663,   128,
     661,    22,    23,   578,   123,   328,    17,    81,   123,   123,
     129,   371,   372,   359,   129,   129,   341,   126,   364,   551,
     552,     4,    43,    44,   855,    81,   435,    81,    82,    24,
       4,   354,     5,    47,    29,    30,   382,   126,   447,    74,
     386,   115,   116,   930,   341,   123,   783,    42,   126,   123,
     123,   128,   461,   126,    68,    69,    77,    78,     4,   115,
     116,   341,   238,   891,   240,    53,    54,   444,   391,   556,
     557,    91,    92,   124,   587,   129,   130,     4,   123,   128,
     655,   126,   595,    93,    94,   261,   463,   999,   108,  1001,
     466,   467,   636,   637,   128,   765,   473,   765,   663,   986,
     765,   128,   448,   765,   124,   117,   118,   119,   120,  1021,
     135,  1023,   131,   490,     4,   438,    11,    12,    13,    14,
     857,   125,   859,   860,   447,   123,   302,   123,   126,    20,
     705,    22,    23,   126,    25,     4,   482,    26,   461,   115,
     116,   126,   123,     4,   814,   126,   523,   123,   124,   814,
       4,   129,   475,     5,     8,   126,    10,    11,    12,    13,
      14,    52,   675,   123,    18,   341,   126,   123,   681,   682,
     126,    62,   124,    64,   115,   116,   117,   118,   119,   120,
     526,    75,    76,   560,    11,    12,    13,    14,   513,   566,
     123,   123,   123,   126,   126,   126,   573,    57,    58,    59,
     765,   129,   130,   580,   544,   545,   546,   584,   783,    63,
     129,   130,   804,   805,   591,   128,   513,     4,   564,   538,
     539,     8,   123,    10,    11,    12,    13,    14,   192,   193,
       4,    18,   578,   513,     4,    23,   124,   129,   751,   616,
     125,   618,     4,   620,   621,     4,     4,   129,   985,   814,
     129,   123,   130,   120,   135,   125,   633,   634,   635,    46,
       4,   129,   639,   439,   130,   441,     4,   132,   127,   126,
     132,   447,   126,   127,   132,   126,   123,   654,   123,   135,
     134,     4,   857,     4,   859,   860,   130,   130,   128,   128,
    1027,   668,     4,   670,   128,   126,   129,   129,   124,   128,
    1037,     9,    10,    11,    12,    13,    14,    15,   124,   655,
     133,   824,     4,   128,   128,   128,    68,   128,   695,   696,
     697,   698,   111,   112,   113,   114,   115,   116,   117,   118,
     119,   120,   709,   710,   711,   712,   128,   513,   663,   126,
     127,   126,   128,     4,   128,   124,   126,   134,   725,   726,
      83,    22,    23,    83,    83,   930,    83,   126,   767,   705,
     737,   129,   538,   539,   741,   128,   663,   123,   135,   129,
       4,   128,   126,   128,    45,   128,    47,   754,    49,    50,
      51,   128,   124,   663,   761,   124,    57,    58,    59,   766,
     130,   127,   129,   128,   128,   126,   128,   774,   117,   776,
     128,   778,   128,   128,   128,   123,    77,    78,   128,   123,
     985,   986,   789,   129,   791,   124,   793,   130,   129,   126,
       4,   798,    93,    94,   129,   128,   126,   804,   805,   126,
     129,   129,     3,     4,     5,     6,   129,   783,   129,   816,
     765,   818,   130,   129,   129,     4,    17,   126,   129,    70,
     117,    31,  1027,     9,   110,    35,    36,    37,    38,    39,
      40,    41,  1037,   126,   124,   123,   132,   129,   765,   128,
      48,   126,   129,   126,     3,     4,     5,     6,   129,   129,
     129,   858,    53,    54,   129,   765,   129,   663,   129,   814,
     123,     4,   110,    73,   110,     8,   110,    10,    11,    12,
      13,    14,   879,   130,     4,    18,    86,    87,    79,    80,
     129,   857,   129,   859,   860,   128,   893,   814,   126,   126,
     129,   126,   899,   126,    53,    54,    97,    98,    99,   100,
     101,   102,    60,   129,   814,   912,   126,   129,   126,   126,
     129,   126,    48,   129,   115,   116,   117,   127,   129,   126,
      79,    80,   126,   128,   931,   128,   128,   128,   123,   129,
     128,   124,   129,   134,   126,   942,   137,   138,    97,    98,
      99,   100,   101,   102,   126,   126,   126,   126,   126,     4,
      60,   126,   129,   129,   930,   129,   115,   116,   129,   765,
     129,   128,   969,   970,   971,   972,   123,   129,   129,   128,
       3,     4,     5,     6,   126,   134,   983,   130,   137,   138,
     130,   130,   989,   126,   127,   129,   123,   129,   995,   129,
     129,   134,   999,   126,  1001,   123,   130,   129,  1005,   130,
     129,    47,   129,   129,   129,  1012,   129,   129,   814,   985,
     986,   129,  1019,    49,  1021,    55,  1023,    95,   302,   323,
      53,    54,  1029,  1030,   691,   238,   346,    24,   354,   259,
     495,   439,  1039,   434,   968,   595,  1043,   509,   675,   761,
     846,   680,   500,   934,    98,  1052,    79,    80,   244,   240,
     475,  1027,     3,     4,     5,     6,   240,     8,   571,   735,
     564,  1037,   844,   893,    97,    98,    99,   100,   101,   102,
     949,   719,   240,   648,   616,   456,     3,     4,     5,     6,
     573,   814,   115,   116,     4,   989,    -1,     7,   463,    -1,
     896,   576,   982,    -1,    -1,   128,    -1,    -1,    -1,    -1,
      -1,   134,    22,    23,   137,   138,    -1,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     3,     4,
       5,     6,    -1,    43,    44,    -1,    -1,    -1,    79,    80,
      -1,    -1,    52,    -1,    -1,    55,    -1,    -1,   944,    -1,
      -1,    -1,    62,   949,    64,    -1,    97,    98,    99,   100,
     101,   102,    79,    80,    -1,    -1,    -1,    77,    78,    -1,
      -1,    -1,    -1,    90,   115,   116,    -1,    -1,    -1,    -1,
      97,    98,    99,   100,   101,   102,    -1,   128,     3,     4,
       5,     6,    -1,   134,    -1,    -1,   137,   138,   115,   116,
      -1,    -1,    -1,    -1,    79,    80,    -1,    -1,    -1,    -1,
      -1,   128,    -1,    -1,    -1,    90,    -1,   134,    -1,    -1,
     137,   138,    97,    98,    99,   100,   101,   102,    -1,    -1,
       3,     4,     5,     6,    -1,    -1,    -1,    -1,    -1,    -1,
     115,   116,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   128,     3,     4,     5,     6,    -1,   134,
      -1,    -1,   137,   138,    79,    80,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,    -1,
      -1,    -1,    97,    98,    99,   100,   101,   102,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,     3,     4,     5,     6,
     115,   116,    -1,    -1,    -1,    -1,    79,    80,    -1,    -1,
      -1,    -1,    -1,   128,    -1,    -1,    -1,    90,    -1,   134,
      -1,    -1,   137,   138,    97,    98,    99,   100,   101,   102,
      79,    80,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    90,   115,   116,    -1,    -1,    -1,    -1,    97,    98,
      99,   100,   101,   102,    -1,   128,     3,     4,     5,     6,
      -1,   134,    -1,    -1,   137,   138,   115,   116,    -1,    -1,
      -1,    -1,    79,    80,    -1,    -1,    -1,    -1,    -1,   128,
      -1,    -1,    -1,    90,    -1,   134,    -1,    -1,   137,   138,
      97,    98,    99,   100,   101,   102,    -1,    -1,     3,     4,
       5,     6,    -1,    -1,    -1,    -1,    -1,    -1,   115,   116,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   128,    -1,    -1,    -1,    -1,    -1,   134,    -1,    -1,
     137,   138,    79,    80,    -1,    -1,    -1,    -1,    -1,    -1,
       3,     4,     5,     6,    -1,    -1,    -1,    -1,    -1,    -1,
      97,    98,    99,   100,   101,   102,    -1,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,   115,   116,
      -1,    -1,    -1,    -1,    79,    80,    -1,    -1,    -1,    -1,
      -1,   128,   129,     3,     4,     5,     6,   134,    -1,    -1,
     137,   138,    97,    98,    99,   100,   101,   102,    -1,    73,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     115,   116,    86,    87,    -1,    -1,    79,    80,    -1,    -1,
     125,    -1,    -1,   128,    -1,     3,     4,     5,     6,   134,
      -1,    -1,   137,   138,    97,    98,    99,   100,   101,   102,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   115,   116,    -1,    -1,    -1,    -1,    -1,    79,
      80,    -1,   125,    -1,    -1,   128,    -1,     3,     4,     5,
       6,   134,    -1,    -1,   137,   138,    -1,    97,    98,    99,
     100,   101,   102,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,     3,     4,     5,     6,   115,   116,    -1,    -1,    -1,
      -1,    79,    80,    -1,    -1,    -1,    -1,    -1,   128,   129,
      -1,    -1,    -1,    -1,   134,    -1,    -1,   137,   138,    97,
      98,    99,   100,   101,   102,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,     3,     4,     5,     6,   115,   116,    -1,
      -1,    -1,    -1,    79,    80,    -1,    -1,    -1,    -1,    -1,
     128,    -1,    -1,    -1,    -1,    -1,   134,    -1,    -1,   137,
     138,    97,    98,    99,   100,   101,   102,    79,    80,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   115,
     116,    -1,    -1,    -1,    -1,    97,    98,    99,   100,   101,
     102,    -1,   128,    -1,    -1,    -1,    -1,    -1,   134,    -1,
      -1,   137,   138,   115,   116,    -1,    -1,    -1,    -1,    79,
      80,    -1,    -1,    -1,    -1,    -1,   128,    -1,    -1,    -1,
      -1,    -1,   134,    -1,    -1,   137,   138,    97,    98,    99,
     100,   101,   102,    -1,    -1,    -1,   113,   114,   115,   116,
     117,   118,   119,   120,    -1,   115,   116,   124,   125,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   128,    -1,
      -1,    -1,    -1,    -1,   134,    -1,    -1,   137,   138,    95,
      96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,   110,   111,   112,   113,   114,   115,
     116,   117,   118,   119,   120,   107,   108,   109,   110,   111,
     112,   113,   114,   115,   116,   117,   118,   119,   120,    -1,
     136,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   201,   202,   203,   204,   205,   206,
     207,   208,   209,   210,   211,   212,   213,   214,   215,   216,
     217,   218,   219,   220,   221,   222,   223,   224,   225,   226,
       8,    -1,    10,    11,    12,    13,    14,    -1,    -1,    -1,
      18,    -1,    -1,    -1,    -1,    -1,    24,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    42,    -1,    -1,    45,    -1,    47,
      -1,    49,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    57,
      58,    59,    -1,    -1,    -1,    -1,    -1,    -1,    66,    67,
      -1,    69,     8,    71,    10,    11,    12,    13,    14,    -1,
      -1,    -1,    18,    -1,    -1,    21,    -1,    -1,    24,    -1,
      88,    89,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    42,    -1,    -1,    45,
      -1,    47,    -1,    49,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    57,    58,    59,    -1,    -1,    -1,    -1,    -1,    -1,
      66,    67,    -1,    69,     8,    71,    10,    11,    12,    13,
      14,    -1,    -1,    -1,    18,    -1,    -1,    -1,    -1,    -1,
      24,    -1,    88,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    42,    -1,
      -1,    45,    -1,    47,    -1,    49,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    57,    58,    59,    -1,    -1,    -1,    -1,
      -1,    -1,    66,    67,    -1,    69,    -1,    71,    72,     8,
      -1,    10,    11,    12,    13,    14,    -1,    -1,    -1,    18,
      -1,    -1,    -1,    -1,    88,    24,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    42,    -1,    -1,    45,    46,    47,    -1,
      49,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    57,    58,
      59,    -1,    -1,    -1,    -1,    -1,    -1,    66,    67,    -1,
      69,     8,    71,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    18,    -1,    -1,    -1,    -1,    -1,    24,    -1,    88,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    42,    -1,    -1,    45,    -1,
      47,    -1,    49,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      57,    58,    59,    -1,    -1,    -1,    -1,    -1,    -1,    66,
      67,    -1,    69,    -1,    71,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    88,    96,    97,    98,    99,   100,   101,   102,   103,
     104,   105,   106,   107,   108,   109,   110,   111,   112,   113,
     114,   115,   116,   117,   118,   119,   120,    97,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
     110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
     120,    99,   100,   101,   102,   103,   104,   105,   106,   107,
     108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
     118,   119,   120,   101,   102,   103,   104,   105,   106,   107,
     108,   109,   110,   111,   112,   113,   114,   115,   116,   117,
     118,   119,   120,   103,   104,   105,   106,   107,   108,   109,
     110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
     120
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,   140,   141,     0,    18,    28,   142,   143,   144,   146,
     153,   171,   175,   195,   256,   258,   147,     4,    20,    22,
      23,    25,    52,    62,    64,   145,   142,   142,   142,   142,
     142,   142,   142,     4,   149,   150,   151,   152,   176,     4,
     257,   259,     4,     4,    56,   204,   204,    16,   148,   123,
      27,   124,   125,   127,   155,   154,    41,   252,   252,   172,
       4,   124,   130,    41,   205,     4,   149,    19,   151,     4,
       3,     5,     6,    79,    80,    97,    98,    99,   100,   101,
     102,   115,   116,   128,   134,   137,   138,   152,   343,   363,
     364,     4,   128,   128,   162,   155,    40,   253,   253,   126,
     196,     4,     4,    40,   131,   186,   188,   190,   199,    17,
       5,   143,   143,   143,   143,   143,   143,   143,   143,   143,
     143,   363,   363,   366,   143,   143,     5,   131,   143,   186,
     187,   188,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   107,   108,   109,   110,   111,   112,
     113,   114,   115,   116,   117,   118,   119,   120,   136,   156,
       4,   125,   129,   143,   163,   166,   126,   162,    74,   254,
     254,   173,   128,   202,     4,   124,   363,     4,   128,   206,
     128,   128,   364,   364,   364,   364,   364,   364,   364,   364,
     129,   130,   123,   134,   135,   364,   364,   363,   365,   186,
     186,   143,   143,   143,   143,   143,   143,   143,   143,   143,
     143,   143,   143,   143,   143,   143,   143,   143,   143,   143,
     143,   143,   143,   143,   143,   143,   143,   143,     4,   143,
     158,   159,   261,   167,   168,   125,   181,   182,   123,   164,
     177,   126,   188,   255,   255,    26,   143,   174,   258,     4,
     201,   203,   126,   197,     4,    81,    82,   130,   132,   200,
     129,   207,   126,   363,   363,     5,   363,   363,   366,   366,
     132,   128,   364,   364,   364,   364,   364,   364,   364,   364,
     364,   364,   364,   364,   364,   364,   364,   364,   364,   364,
     364,   364,   364,   364,   364,   364,   364,   364,   363,   124,
      22,    23,   123,   157,   124,   165,     4,   125,   188,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      73,    86,    87,   183,   184,   185,   166,   129,    24,    29,
      30,    42,   143,   178,   256,   258,   262,   265,   274,   294,
     304,   191,   260,   261,   260,     4,   123,   129,   202,     4,
     363,   363,   363,   206,     4,   143,   209,   210,   273,   212,
     129,   129,   130,   135,   125,   347,   348,   349,   363,   130,
     363,   160,   161,   159,   129,   363,   169,     4,   127,   179,
     180,   185,   188,   263,   264,     4,   180,    43,    44,    77,
      78,   181,     8,    10,    21,    45,    47,    49,    57,    58,
      59,    66,    67,    69,    71,    88,   143,   146,   192,   193,
     195,   213,   223,   226,   256,   258,   262,   265,   274,   277,
     294,   302,   313,   328,   352,   123,   126,   126,   201,   126,
     198,   132,   132,   132,   126,   187,   188,   189,   181,   123,
     164,    10,    65,   126,   134,   143,   146,   152,   179,   256,
     258,   265,   302,   312,   314,   315,   327,   343,   344,   363,
     135,   152,   343,   123,   164,   363,   252,   252,   165,   170,
       4,     5,     6,   128,   343,   123,   126,   305,   275,   276,
     344,   295,   297,     4,     4,   188,   130,   358,   130,   301,
     128,   128,     4,    47,   214,   215,   217,     4,    47,    68,
     224,   225,   226,   230,   231,   232,   244,   251,   131,   227,
     228,   229,   251,   350,     4,     4,     7,    55,   280,    11,
      12,    13,    14,   128,   261,   202,   212,   188,   210,   208,
     143,   345,   363,    45,    47,    49,    50,    51,    93,    94,
     326,   143,   315,    11,    12,    13,    14,   126,   328,    91,
      92,   108,   124,   129,   349,   129,   253,   253,   165,   363,
     124,   264,   128,   307,   123,   126,   124,   133,   298,   315,
     268,   269,   266,   128,   346,     4,   357,   363,   353,   128,
     128,    68,   214,   128,   128,    68,   225,   128,   236,   237,
     126,   128,   249,   363,   228,   123,   126,   124,    72,   192,
     351,   352,   126,   278,   180,    83,    83,    83,    83,   363,
     126,    63,   211,   129,   317,   135,   123,   301,   128,   128,
     128,   128,   143,   327,   327,   316,    15,    83,   303,   303,
     303,   126,   303,   128,   180,   180,   255,   255,   129,   130,
     363,     4,    32,    33,   129,   308,   309,   310,   311,   306,
     276,   363,    16,   117,   128,   296,   270,   270,   271,   272,
     273,   347,   126,   350,   129,   314,    53,    54,   220,   363,
     220,   250,   363,    53,    54,   235,   238,   242,   251,   124,
     124,    53,    54,   245,   246,   250,   130,   126,   229,   248,
     249,   194,   127,   288,   279,   128,   128,   128,   128,   129,
     273,   346,   345,   318,   363,   319,   363,   363,   346,   128,
     128,   128,   128,   363,   363,   363,   261,   261,   363,   123,
     164,   310,   126,   129,    17,    53,    54,   117,   299,   300,
     363,   315,   123,   126,   126,   123,   267,   124,   164,    46,
     355,   126,   363,   129,   363,   129,   238,   242,   117,   115,
     116,   123,   239,   241,   128,   233,   247,   249,   233,   251,
     251,   123,   129,   249,   130,   191,   128,     4,   281,   282,
     282,   285,   286,   287,    90,   363,    90,   363,    90,   363,
     363,   356,   126,   330,   129,   314,   129,   129,   126,    90,
     363,    90,   363,    90,   363,   129,   363,   129,   130,   309,
     129,   363,   363,   129,    55,   123,   129,     4,   272,   126,
     363,   129,   301,   359,   360,   363,    70,   218,     9,   117,
     124,   241,   110,   242,   123,   241,   124,   247,   363,   123,
     234,   245,   126,   132,   249,    89,   125,   289,   290,   363,
     186,   283,   123,   126,   123,   126,   128,   363,   129,   363,
     129,   363,   129,   129,   337,    46,   315,   324,   126,   322,
     323,   363,   129,   363,   129,   363,   129,   126,   129,   325,
     363,   300,   300,    48,   362,   351,   354,   363,   123,   128,
     219,   363,   110,   110,   240,   243,   251,   242,   110,   234,
     247,   130,     4,   123,   129,   284,   128,   282,   286,   143,
     291,   292,   293,   129,   126,   129,   126,   129,   126,   126,
      60,   338,   339,   301,   315,   363,   315,   315,   129,   126,
     129,   126,   129,   126,   126,   329,   129,   126,   359,   361,
     126,   220,   363,   129,   128,   128,   123,   129,   243,   129,
     234,   249,   128,   290,   128,   291,   125,   363,   129,   123,
     126,   126,   126,     8,    61,   341,   342,   363,    48,   331,
     320,   126,   126,   126,    75,    76,   333,   314,   363,    81,
      82,   130,   124,   240,   243,   243,   129,   363,   291,   129,
       4,   293,   340,   123,   130,   332,   126,    60,   334,   335,
     129,   218,   363,   363,   363,   128,   221,   222,   363,    81,
     241,    81,   241,   129,   129,   128,   361,   363,   315,   314,
     341,   359,   123,   129,   129,   129,   222,   363,   126,   130,
     250,   130,   250,   130,   129,   363,   129,   336,   363,   123,
     130,   363,   129,   250,   129,   250,   129,   321,   315,   123,
     216,   222,   363,   130,   129,   129,   129,   129,   315,   363,
     129,   129,   130,   363,   129,   129,   126,   363
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   139,   141,   140,   142,   142,   142,   142,   142,   142,
     142,   142,   144,   143,   145,   145,   147,   148,   146,   149,
     149,   150,   150,   151,   151,   152,   152,   152,   154,   153,
     156,   157,   155,   155,   158,   158,   159,   160,   159,   161,
     159,   159,   162,   162,   162,   163,   163,   164,   164,   165,
     165,   167,   166,   168,   169,   166,   170,   166,   166,   172,
     171,   173,   173,   174,   176,   175,   177,   177,   178,   178,
     178,   178,   178,   178,   178,   179,   179,   179,   179,   179,
     180,   180,   182,   181,   183,   183,   183,   184,   184,   184,
     185,   185,   185,   185,   185,   185,   185,   185,   185,   185,
     185,   186,   186,   186,   186,   187,   187,   188,   188,   189,
     189,   190,   190,   191,   191,   191,   192,   192,   192,   192,
     192,   192,   192,   192,   192,   192,   192,   192,   192,   192,
     192,   194,   193,   196,   195,   197,   195,   198,   195,   199,
     195,   200,   195,   201,   201,   202,   202,   203,   203,   203,
     203,   204,   204,   205,   205,   206,   206,   207,   208,   206,
     209,   209,   211,   210,   210,   212,   212,   213,   214,   214,
     215,   215,   216,   216,   217,   217,   218,   218,   219,   219,
     219,   219,   220,   220,   220,   221,   221,   222,   222,   223,
     223,   224,   224,   225,   225,   225,   226,   226,   227,   228,
     228,   229,   230,   230,   231,   232,   232,   233,   233,   233,
     234,   234,   235,   235,   236,   236,   236,   237,   237,   237,
     238,   238,   239,   239,   240,   240,   241,   241,   241,   242,
     243,   244,   245,   245,   245,   246,   246,   247,   248,   248,
     249,   250,   251,   252,   252,   253,   253,   254,   254,   255,
     257,   256,   259,   258,   260,   260,   261,   262,   263,   263,
     264,   266,   267,   265,   268,   265,   269,   265,   270,   270,
     271,   271,   272,   272,   273,   274,   275,   275,   276,   278,
     277,   279,   277,   280,   280,   281,   281,   283,   282,   284,
     282,   285,   285,   286,   287,   286,   288,   288,   289,   289,
     290,   290,   290,   291,   292,   292,   293,   293,   293,   293,
     293,   295,   296,   294,   297,   294,   298,   298,   298,   298,
     298,   298,   299,   299,   299,   300,   300,   300,   301,   301,
     302,   302,   303,   303,   303,   305,   306,   304,   307,   307,
     308,   308,   309,   309,   310,   311,   311,   312,   312,   312,
     312,   312,   312,   312,   312,   312,   313,   313,   313,   313,
     313,   313,   313,   314,   314,   314,   314,   315,   315,   315,
     315,   315,   315,   315,   315,   316,   315,   317,   315,   318,
     315,   319,   320,   321,   315,   322,   315,   323,   315,   324,
     315,   325,   315,   326,   326,   326,   327,   328,   328,   328,
     329,   329,   329,   330,   330,   332,   331,   331,   333,   333,
     335,   336,   334,   337,   337,   339,   340,   338,   341,   341,
     342,   342,   342,   342,   343,   343,   343,   344,   344,   345,
     345,   346,   346,   347,   347,   348,   348,   349,   350,   350,
     351,   351,   353,   354,   352,   355,   352,   356,   352,   357,
     352,   358,   352,   360,   359,   361,   361,   362,   362,   363,
     363,   364,   364,   364,   364,   364,   364,   364,   365,   364,
     364,   364,   364,   364,   364,   364,   364,   364,   364,   364,
     364,   364,   364,   364,   364,   364,   364,   364,   364,   364,
     364,   364,   364,   364,   364,   364,   364,   364,   364,   364,
     364,   364,   364,   364,   364,   364,   364,   364,   364,   364,
     364,   364,   366,   366
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     0,     2,     2,     2,     2,     2,     2,     2,
       2,     0,     0,     2,     4,     0,     0,     0,     5,     1,
       0,     1,     3,     1,     3,     1,     3,     3,     0,     9,
       0,     0,     6,     0,     1,     3,     0,     0,     7,     0,
       7,     1,     2,     0,     4,     1,     3,     1,     0,     2,
       0,     0,     3,     0,     0,     5,     0,     6,     3,     0,
       7,     2,     0,     1,     0,     8,     2,     0,     1,     1,
       1,     1,     1,     1,     1,     2,     2,     2,     4,     8,
       1,     0,     0,     3,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     5,     5,     5,     3,     2,     2,     1,     0,     1,
       1,     1,     1,     2,     2,     0,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     1,     1,     1,
       1,     0,     6,     0,     7,     0,     9,     0,    11,     0,
       9,     0,    11,     2,     1,     3,     0,     3,     2,     1,
       0,     1,     0,     1,     0,     2,     0,     0,     0,     6,
       1,     3,     0,     5,     1,     2,     0,     3,     2,     0,
      10,    14,     2,     0,     4,     0,     2,     0,     1,     5,
       5,     5,     1,     1,     0,     1,     5,     1,     5,     3,
       2,     2,     1,     1,     1,     1,     3,     4,     5,     1,
       3,     3,     4,     0,     2,     4,     4,     4,     1,     2,
       2,     3,     1,     1,     7,    12,    11,     6,    12,    11,
       2,     3,     2,     3,     1,     3,     1,     1,     0,     1,
       1,     5,     2,     2,     1,     1,     3,     1,     1,     5,
       1,     1,     1,     1,     0,     1,     0,     1,     0,     1,
       0,     9,     0,     9,     1,     3,     3,     3,     1,     3,
       4,     0,     0,     7,     0,     6,     0,     6,     0,     3,
       1,     3,     1,     3,     2,     4,     1,     3,     3,     0,
       6,     0,     6,     1,     1,     1,     3,     0,     5,     0,
       6,     1,     3,     1,     0,     4,     4,     0,     1,     3,
       0,     1,     5,     1,     1,     3,     1,     2,     6,     5,
       3,     0,     0,     6,     0,     4,     4,     4,     3,     3,
       2,     0,     1,     3,     3,     2,     2,     1,     2,     0,
       2,     0,     1,     1,     0,     0,     0,     6,     2,     4,
       1,     3,     2,     1,     1,     1,     1,     7,     7,     8,
       8,     7,     6,     3,     7,     8,     7,     7,     8,     8,
       7,     7,     8,     4,     2,     2,     4,     1,     1,     1,
       1,     1,     2,     2,     1,     0,     5,     0,     5,     0,
       7,     0,     0,     0,    13,     0,     7,     0,     7,     0,
       8,     0,     9,     0,     2,     2,     2,     1,     1,     1,
       2,     2,     0,     2,     0,     0,     3,     0,     2,     0,
       0,     0,     4,     2,     0,     0,     0,     4,     2,     1,
       1,     1,     1,     3,     6,     2,     2,     1,     3,     1,
       3,     4,     0,     1,     0,     1,     3,     1,     2,     0,
       1,     1,     0,     0,    11,     0,     7,     0,     7,     0,
       6,     0,     4,     0,     2,     1,     1,     2,     0,     1,
       6,     1,     4,     2,     2,     1,     1,     1,     0,     7,
       5,     5,     3,     7,     3,     6,     3,     4,     4,     4,
       4,     4,     4,     3,     3,     3,     3,     3,     3,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     3,     3,     4,
       4,     3,     1,     3
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      YY_LAC_DISCARD ("YYBACKUP");                              \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if FRONTEND_VERILOG_YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !FRONTEND_VERILOG_YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !FRONTEND_VERILOG_YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif

/* Given a state stack such that *YYBOTTOM is its bottom, such that
   *YYTOP is either its top or is YYTOP_EMPTY to indicate an empty
   stack, and such that *YYCAPACITY is the maximum number of elements it
   can hold without a reallocation, make sure there is enough room to
   store YYADD more elements.  If not, allocate a new stack using
   YYSTACK_ALLOC, copy the existing elements, and adjust *YYBOTTOM,
   *YYTOP, and *YYCAPACITY to reflect the new capacity and memory
   location.  If *YYBOTTOM != YYBOTTOM_NO_FREE, then free the old stack
   using YYSTACK_FREE.  Return 0 if successful or if no reallocation is
   required.  Return 1 if memory is exhausted.  */
static int
yy_lac_stack_realloc (YYSIZE_T *yycapacity, YYSIZE_T yyadd,
#if FRONTEND_VERILOG_YYDEBUG
                      char const *yydebug_prefix,
                      char const *yydebug_suffix,
#endif
                      yytype_int16 **yybottom,
                      yytype_int16 *yybottom_no_free,
                      yytype_int16 **yytop, yytype_int16 *yytop_empty)
{
  YYSIZE_T yysize_old =
    *yytop == yytop_empty ? 0 : *yytop - *yybottom + 1;
  YYSIZE_T yysize_new = yysize_old + yyadd;
  if (*yycapacity < yysize_new)
    {
      YYSIZE_T yyalloc = 2 * yysize_new;
      yytype_int16 *yybottom_new;
      /* Use YYMAXDEPTH for maximum stack size given that the stack
         should never need to grow larger than the main state stack
         needs to grow without LAC.  */
      if (YYMAXDEPTH < yysize_new)
        {
          YYDPRINTF ((stderr, "%smax size exceeded%s", yydebug_prefix,
                      yydebug_suffix));
          return 1;
        }
      if (YYMAXDEPTH < yyalloc)
        yyalloc = YYMAXDEPTH;
      yybottom_new =
        (yytype_int16*) YYSTACK_ALLOC (yyalloc * sizeof *yybottom_new);
      if (!yybottom_new)
        {
          YYDPRINTF ((stderr, "%srealloc failed%s", yydebug_prefix,
                      yydebug_suffix));
          return 1;
        }
      if (*yytop != yytop_empty)
        {
          YYCOPY (yybottom_new, *yybottom, yysize_old);
          *yytop = yybottom_new + (yysize_old - 1);
        }
      if (*yybottom != yybottom_no_free)
        YYSTACK_FREE (*yybottom);
      *yybottom = yybottom_new;
      *yycapacity = yyalloc;
    }
  return 0;
}

/* Establish the initial context for the current lookahead if no initial
   context is currently established.

   We define a context as a snapshot of the parser stacks.  We define
   the initial context for a lookahead as the context in which the
   parser initially examines that lookahead in order to select a
   syntactic action.  Thus, if the lookahead eventually proves
   syntactically unacceptable (possibly in a later context reached via a
   series of reductions), the initial context can be used to determine
   the exact set of tokens that would be syntactically acceptable in the
   lookahead's place.  Moreover, it is the context after which any
   further semantic actions would be erroneous because they would be
   determined by a syntactically unacceptable token.

   YY_LAC_ESTABLISH should be invoked when a reduction is about to be
   performed in an inconsistent state (which, for the purposes of LAC,
   includes consistent states that don't know they're consistent because
   their default reductions have been disabled).  Iff there is a
   lookahead token, it should also be invoked before reporting a syntax
   error.  This latter case is for the sake of the debugging output.

   For parse.lac=full, the implementation of YY_LAC_ESTABLISH is as
   follows.  If no initial context is currently established for the
   current lookahead, then check if that lookahead can eventually be
   shifted if syntactic actions continue from the current context.
   Report a syntax error if it cannot.  */
#define YY_LAC_ESTABLISH                                         \
do {                                                             \
  if (!yy_lac_established)                                       \
    {                                                            \
      YYDPRINTF ((stderr,                                        \
                  "LAC: initial context established for %s\n",   \
                  yytname[yytoken]));                            \
      yy_lac_established = 1;                                    \
      {                                                          \
        int yy_lac_status =                                      \
          yy_lac (yyesa, &yyes, &yyes_capacity, yyssp, yytoken); \
        if (yy_lac_status == 2)                                  \
          goto yyexhaustedlab;                                   \
        if (yy_lac_status == 1)                                  \
          goto yyerrlab;                                         \
      }                                                          \
    }                                                            \
} while (0)

/* Discard any previous initial lookahead context because of Event,
   which may be a lookahead change or an invalidation of the currently
   established initial context for the current lookahead.

   The most common example of a lookahead change is a shift.  An example
   of both cases is syntax error recovery.  That is, a syntax error
   occurs when the lookahead is syntactically erroneous for the
   currently established initial context, so error recovery manipulates
   the parser stacks to try to find a new initial context in which the
   current lookahead is syntactically acceptable.  If it fails to find
   such a context, it discards the lookahead.  */
#if FRONTEND_VERILOG_YYDEBUG
# define YY_LAC_DISCARD(Event)                                           \
do {                                                                     \
  if (yy_lac_established)                                                \
    {                                                                    \
      if (yydebug)                                                       \
        YYFPRINTF (stderr, "LAC: initial context discarded due to "      \
                   Event "\n");                                          \
      yy_lac_established = 0;                                            \
    }                                                                    \
} while (0)
#else
# define YY_LAC_DISCARD(Event) yy_lac_established = 0
#endif

/* Given the stack whose top is *YYSSP, return 0 iff YYTOKEN can
   eventually (after perhaps some reductions) be shifted, return 1 if
   not, or return 2 if memory is exhausted.  As preconditions and
   postconditions: *YYES_CAPACITY is the allocated size of the array to
   which *YYES points, and either *YYES = YYESA or *YYES points to an
   array allocated with YYSTACK_ALLOC.  yy_lac may overwrite the
   contents of either array, alter *YYES and *YYES_CAPACITY, and free
   any old *YYES other than YYESA.  */
static int
yy_lac (yytype_int16 *yyesa, yytype_int16 **yyes,
        YYSIZE_T *yyes_capacity, yytype_int16 *yyssp, int yytoken)
{
  yytype_int16 *yyes_prev = yyssp;
  yytype_int16 *yyesp = yyes_prev;
  YYDPRINTF ((stderr, "LAC: checking lookahead %s:", yytname[yytoken]));
  if (yytoken == YYUNDEFTOK)
    {
      YYDPRINTF ((stderr, " Always Err\n"));
      return 1;
    }
  while (1)
    {
      int yyrule = yypact[*yyesp];
      if (yypact_value_is_default (yyrule)
          || (yyrule += yytoken) < 0 || YYLAST < yyrule
          || yycheck[yyrule] != yytoken)
        {
          yyrule = yydefact[*yyesp];
          if (yyrule == 0)
            {
              YYDPRINTF ((stderr, " Err\n"));
              return 1;
            }
        }
      else
        {
          yyrule = yytable[yyrule];
          if (yytable_value_is_error (yyrule))
            {
              YYDPRINTF ((stderr, " Err\n"));
              return 1;
            }
          if (0 < yyrule)
            {
              YYDPRINTF ((stderr, " S%d\n", yyrule));
              return 0;
            }
          yyrule = -yyrule;
        }
      {
        YYSIZE_T yylen = yyr2[yyrule];
        YYDPRINTF ((stderr, " R%d", yyrule - 1));
        if (yyesp != yyes_prev)
          {
            YYSIZE_T yysize = yyesp - *yyes + 1;
            if (yylen < yysize)
              {
                yyesp -= yylen;
                yylen = 0;
              }
            else
              {
                yylen -= yysize;
                yyesp = yyes_prev;
              }
          }
        if (yylen)
          yyesp = yyes_prev -= yylen;
      }
      {
        int yystate;
        {
          int yylhs = yyr1[yyrule] - YYNTOKENS;
          yystate = yypgoto[yylhs] + *yyesp;
          if (yystate < 0 || YYLAST < yystate
              || yycheck[yystate] != *yyesp)
            yystate = yydefgoto[yylhs];
          else
            yystate = yytable[yystate];
        }
        if (yyesp == yyes_prev)
          {
            yyesp = *yyes;
            *yyesp = yystate;
          }
        else
          {
            if (yy_lac_stack_realloc (yyes_capacity, 1,
#if FRONTEND_VERILOG_YYDEBUG
                                      " (", ")",
#endif
                                      yyes, yyesa, &yyesp, yyes_prev))
              {
                YYDPRINTF ((stderr, "\n"));
                return 2;
              }
            *++yyesp = yystate;
          }
        YYDPRINTF ((stderr, " G%d", yystate));
      }
    }
}


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.  In order to see if a particular token T is a
   valid looakhead, invoke yy_lac (YYESA, YYES, YYES_CAPACITY, YYSSP, T).

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store or if
   yy_lac returned 2.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyesa, yytype_int16 **yyes,
                YYSIZE_T *yyes_capacity, yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
       In the first two cases, it might appear that the current syntax
       error should have been detected in the previous state when yy_lac
       was invoked.  However, at that time, there might have been a
       different syntax error that discarded a different initial context
       during error recovery, leaving behind the current lookahead.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      YYDPRINTF ((stderr, "Constructing syntax error message\n"));
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          int yyx;

          for (yyx = 0; yyx < YYNTOKENS; ++yyx)
            if (yyx != YYTERROR && yyx != YYUNDEFTOK)
              {
                {
                  int yy_lac_status = yy_lac (yyesa, yyes, yyes_capacity,
                                              yyssp, yyx);
                  if (yy_lac_status == 2)
                    return 2;
                  if (yy_lac_status == 1)
                    continue;
                }
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
# if FRONTEND_VERILOG_YYDEBUG
      else if (yydebug)
        YYFPRINTF (stderr, "No expected tokens.\n");
# endif
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

    yytype_int16 yyesa[20];
    yytype_int16 *yyes;
    YYSIZE_T yyes_capacity;

  int yy_lac_established = 0;
  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  yyes = yyesa;
  yyes_capacity = sizeof yyesa / sizeof *yyes;
  if (YYMAXDEPTH < yyes_capacity)
    yyes_capacity = YYMAXDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    {
      YY_LAC_ESTABLISH;
      goto yydefault;
    }
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      YY_LAC_ESTABLISH;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  YY_LAC_DISCARD ("shift");

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  {
    int yychar_backup = yychar;
    switch (yyn)
      {
          case 2:
#line 192 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
	ast_stack.clear();
	ast_stack.push_back(current_ast);
}
#line 2716 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 3:
#line 195 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
	ast_stack.pop_back();
	log_assert(GetSize(ast_stack) == 0);
	for (auto &it : default_attr_list)
		delete it.second;
	default_attr_list.clear();
}
#line 2728 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 12:
#line 214 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (attr_list != nullptr)
			attr_list_stack.push(attr_list);
		attr_list = new std::map<std::string, AstNode*>;
		for (auto &it : default_attr_list)
			(*attr_list)[it.first] = it.second->clone();
	}
#line 2740 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 13:
#line 220 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.al) = attr_list;
		if (!attr_list_stack.empty()) {
			attr_list = attr_list_stack.top();
			attr_list_stack.pop();
		} else
			attr_list = nullptr;
	}
#line 2753 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 16:
#line 234 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (attr_list != nullptr)
			attr_list_stack.push(attr_list);
		attr_list = new std::map<std::string, AstNode*>;
		for (auto &it : default_attr_list)
			delete it.second;
		default_attr_list.clear();
	}
#line 2766 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 17:
#line 241 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		attr_list->swap(default_attr_list);
		delete attr_list;
		if (!attr_list_stack.empty()) {
			attr_list = attr_list_stack.top();
			attr_list_stack.pop();
		} else
			attr_list = nullptr;
	}
#line 2780 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 23:
#line 259 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (attr_list->count(*(yyvsp[0].string)) != 0)
			delete (*attr_list)[*(yyvsp[0].string)];
		(*attr_list)[*(yyvsp[0].string)] = AstNode::mkconst_int(1, false);
		delete (yyvsp[0].string);
	}
#line 2791 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 24:
#line 265 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (attr_list->count(*(yyvsp[-2].string)) != 0)
			delete (*attr_list)[*(yyvsp[-2].string)];
		(*attr_list)[*(yyvsp[-2].string)] = (yyvsp[0].ast);
		delete (yyvsp[-2].string);
	}
#line 2802 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 25:
#line 273 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = (yyvsp[0].string);
	}
#line 2810 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 26:
#line 276 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[0].string)->substr(0, 1) == "\\")
			*(yyvsp[-2].string) += "::" + (yyvsp[0].string)->substr(1);
		else
			*(yyvsp[-2].string) += "::" + *(yyvsp[0].string);
		delete (yyvsp[0].string);
		(yyval.string) = (yyvsp[-2].string);
	}
#line 2823 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 27:
#line 284 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[0].string)->substr(0, 1) == "\\")
			*(yyvsp[-2].string) += "." + (yyvsp[0].string)->substr(1);
		else
			*(yyvsp[-2].string) += "." + *(yyvsp[0].string);
		delete (yyvsp[0].string);
		(yyval.string) = (yyvsp[-2].string);
	}
#line 2836 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 28:
#line 294 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		do_not_require_port_stubs = false;
		AstNode *mod = new AstNode(AST_MODULE);
		ast_stack.back()->children.push_back(mod);
		ast_stack.push_back(mod);
		current_ast_mod = mod;
		port_stubs.clear();
		port_counter = 0;
		mod->str = *(yyvsp[0].string);
		append_attr(mod, (yyvsp[-2].al));
		delete (yyvsp[0].string);
	}
#line 2853 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 29:
#line 305 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (port_stubs.size() != 0)
			frontend_verilog_yyerror("Missing details for module port `%s'.",
					port_stubs.begin()->first.c_str());
		ast_stack.pop_back();
		log_assert(ast_stack.size() == 1);
		current_ast_mod = NULL;
	}
#line 2866 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 30:
#line 315 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { astbuf1 = nullptr; }
#line 2872 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 31:
#line 315 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { if (astbuf1) delete astbuf1; }
#line 2878 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 37:
#line 322 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (astbuf1) delete astbuf1;
		astbuf1 = new AstNode(AST_PARAMETER);
		astbuf1->children.push_back(AstNode::mkconst_int(0, true));
		append_attr(astbuf1, (yyvsp[-1].al));
	}
#line 2889 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 39:
#line 328 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (astbuf1) delete astbuf1;
		astbuf1 = new AstNode(AST_LOCALPARAM);
		astbuf1->children.push_back(AstNode::mkconst_int(0, true));
		append_attr(astbuf1, (yyvsp[-1].al));
	}
#line 2900 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 49:
#line 346 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (ast_stack.back()->children.size() > 0 && ast_stack.back()->children.back()->type == AST_WIRE) {
			AstNode *wire = new AstNode(AST_IDENTIFIER);
			wire->str = ast_stack.back()->children.back()->str;
			if (ast_stack.back()->children.back()->is_input) {
				AstNode *n = ast_stack.back()->children.back();
				if (n->attributes.count("\\defaultvalue"))
					delete n->attributes.at("\\defaultvalue");
				n->attributes["\\defaultvalue"] = (yyvsp[0].ast);
			} else
			if (ast_stack.back()->children.back()->is_reg || ast_stack.back()->children.back()->is_logic)
				ast_stack.back()->children.push_back(new AstNode(AST_INITIAL, new AstNode(AST_BLOCK, new AstNode(AST_ASSIGN_LE, wire, (yyvsp[0].ast)))));
			else
				ast_stack.back()->children.push_back(new AstNode(AST_ASSIGN, wire, (yyvsp[0].ast)));
		} else
			frontend_verilog_yyerror("SystemVerilog interface in module port list cannot have a default value.");
	}
#line 2922 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 51:
#line 366 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (ast_stack.back()->children.size() > 0 && ast_stack.back()->children.back()->type == AST_WIRE) {
			AstNode *node = ast_stack.back()->children.back()->clone();
			node->str = *(yyvsp[0].string);
			node->port_id = ++port_counter;
			ast_stack.back()->children.push_back(node);
		} else {
			if (port_stubs.count(*(yyvsp[0].string)) != 0)
				frontend_verilog_yyerror("Duplicate module port `%s'.", (yyvsp[0].string)->c_str());
			port_stubs[*(yyvsp[0].string)] = ++port_counter;
		}
		delete (yyvsp[0].string);
	}
#line 2940 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 53:
#line 379 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf1 = new AstNode(AST_INTERFACEPORT);
		astbuf1->children.push_back(new AstNode(AST_INTERFACEPORTTYPE));
		astbuf1->children[0]->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
	}
#line 2951 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 54:
#line 384 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {  /* SV interfaces */
		if (!sv_mode)
			frontend_verilog_yyerror("Interface found in port list (%s). This is not supported unless read_verilog is called with -sv!", (yyvsp[0].string)->c_str());
		astbuf2 = astbuf1->clone(); // really only needed if multiple instances of same type.
		astbuf2->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
		astbuf2->port_id = ++port_counter;
		ast_stack.back()->children.push_back(astbuf2);
		delete astbuf1; // really only needed if multiple instances of same type.
	}
#line 2966 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 56:
#line 394 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = (yyvsp[-2].ast);
		node->str = *(yyvsp[0].string);
		node->port_id = ++port_counter;
		if ((yyvsp[-1].ast) != NULL)
			node->children.push_back((yyvsp[-1].ast));
		if (!node->is_input && !node->is_output)
			frontend_verilog_yyerror("Module port `%s' is neither input nor output.", (yyvsp[0].string)->c_str());
		if (node->is_reg && node->is_input && !node->is_output && !sv_mode)
			frontend_verilog_yyerror("Input port `%s' is declared as register.", (yyvsp[0].string)->c_str());
		ast_stack.back()->children.push_back(node);
		append_attr(node, (yyvsp[-3].al));
		delete (yyvsp[0].string);
	}
#line 2985 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 58:
#line 408 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		do_not_require_port_stubs = true;
	}
#line 2993 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 59:
#line 413 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *mod = new AstNode(AST_PACKAGE);
		ast_stack.back()->children.push_back(mod);
		ast_stack.push_back(mod);
		current_ast_mod = mod;
		mod->str = *(yyvsp[0].string);
		append_attr(mod, (yyvsp[-2].al));
	}
#line 3006 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 60:
#line 420 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		current_ast_mod = NULL;
	}
#line 3015 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 64:
#line 432 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		do_not_require_port_stubs = false;
		AstNode *intf = new AstNode(AST_INTERFACE);
		ast_stack.back()->children.push_back(intf);
		ast_stack.push_back(intf);
		current_ast_mod = intf;
		port_stubs.clear();
		port_counter = 0;
		intf->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
	}
#line 3031 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 65:
#line 442 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (port_stubs.size() != 0)
			frontend_verilog_yyerror("Missing details for module port `%s'.",
				port_stubs.begin()->first.c_str());
		ast_stack.pop_back();
		log_assert(ast_stack.size() == 1);
		current_ast_mod = NULL;
	}
#line 3044 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 75:
#line 459 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { delete (yyvsp[0].string); }
#line 3050 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 76:
#line 460 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { delete (yyvsp[0].string); }
#line 3056 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 77:
#line 461 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { delete (yyvsp[0].string); }
#line 3062 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 78:
#line 462 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { delete (yyvsp[-1].ast); }
#line 3068 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 79:
#line 463 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { delete (yyvsp[-5].ast); delete (yyvsp[-3].ast); delete (yyvsp[-1].ast); }
#line 3074 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 82:
#line 469 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3 = new AstNode(AST_WIRE);
		current_wire_rand = false;
		current_wire_const = false;
	}
#line 3084 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 83:
#line 473 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = astbuf3;
	}
#line 3092 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 87:
#line 482 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_input = true;
	}
#line 3100 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 88:
#line 485 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_output = true;
	}
#line 3108 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 89:
#line 488 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_input = true;
		astbuf3->is_output = true;
	}
#line 3117 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 90:
#line 494 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
	}
#line 3124 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 91:
#line 496 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_wor = true;
	}
#line 3132 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 92:
#line 499 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_wand = true;
	}
#line 3140 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 93:
#line 502 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_reg = true;
	}
#line 3148 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 94:
#line 505 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_logic = true;
	}
#line 3156 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 95:
#line 508 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_logic = true;
	}
#line 3164 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 96:
#line 511 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_reg = true;
		astbuf3->range_left = 31;
		astbuf3->range_right = 0;
		astbuf3->is_signed = true;
	}
#line 3175 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 97:
#line 517 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->type = AST_GENVAR;
		astbuf3->is_reg = true;
		astbuf3->is_signed = true;
		astbuf3->range_left = 31;
		astbuf3->range_right = 0;
	}
#line 3187 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 98:
#line 524 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf3->is_signed = true;
	}
#line 3195 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 99:
#line 527 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_wire_rand = true;
	}
#line 3203 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 100:
#line 530 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_wire_const = true;
	}
#line 3211 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 101:
#line 535 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_RANGE);
		(yyval.ast)->children.push_back((yyvsp[-3].ast));
		(yyval.ast)->children.push_back((yyvsp[-1].ast));
	}
#line 3221 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 102:
#line 540 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_RANGE);
		(yyval.ast)->children.push_back(new AstNode(AST_SUB, new AstNode(AST_ADD, (yyvsp[-3].ast)->clone(), (yyvsp[-1].ast)), AstNode::mkconst_int(1, true)));
		(yyval.ast)->children.push_back(new AstNode(AST_ADD, (yyvsp[-3].ast), AstNode::mkconst_int(0, true)));
	}
#line 3231 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 103:
#line 545 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_RANGE);
		(yyval.ast)->children.push_back(new AstNode(AST_ADD, (yyvsp[-3].ast), AstNode::mkconst_int(0, true)));
		(yyval.ast)->children.push_back(new AstNode(AST_SUB, new AstNode(AST_ADD, (yyvsp[-3].ast)->clone(), AstNode::mkconst_int(1, true)), (yyvsp[-1].ast)));
	}
#line 3241 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 104:
#line 550 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_RANGE);
		(yyval.ast)->children.push_back((yyvsp[-1].ast));
	}
#line 3250 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 105:
#line 556 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_MULTIRANGE, (yyvsp[-1].ast), (yyvsp[0].ast));
	}
#line 3258 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 106:
#line 559 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[-1].ast);
		(yyval.ast)->children.push_back((yyvsp[0].ast));
	}
#line 3267 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 107:
#line 565 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 3275 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 108:
#line 568 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = NULL;
	}
#line 3283 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 109:
#line 573 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { (yyval.ast) = (yyvsp[0].ast); }
#line 3289 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 110:
#line 574 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { (yyval.ast) = (yyvsp[0].ast); }
#line 3295 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 111:
#line 577 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 3303 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 112:
#line 580 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_RANGE);
		(yyval.ast)->children.push_back(AstNode::mkconst_int(31, true));
		(yyval.ast)->children.push_back(AstNode::mkconst_int(0, true));
		(yyval.ast)->is_signed = true;
	}
#line 3314 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 131:
#line 598 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_GENBLOCK);
		node->str = *(yyvsp[-1].string);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 3325 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 132:
#line 603 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete (yyvsp[-4].string);
		ast_stack.pop_back();
	}
#line 3334 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 133:
#line 609 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = new AstNode(AST_DPI_FUNCTION, AstNode::mkconst_str(*(yyvsp[-1].string)), AstNode::mkconst_str(*(yyvsp[0].string)));
		current_function_or_task->str = *(yyvsp[0].string);
		append_attr(current_function_or_task, (yyvsp[-3].al));
		ast_stack.back()->children.push_back(current_function_or_task);
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 3347 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 134:
#line 616 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = NULL;
	}
#line 3355 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 135:
#line 619 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = new AstNode(AST_DPI_FUNCTION, AstNode::mkconst_str(*(yyvsp[-1].string)), AstNode::mkconst_str(*(yyvsp[-3].string)));
		current_function_or_task->str = *(yyvsp[0].string);
		append_attr(current_function_or_task, (yyvsp[-5].al));
		ast_stack.back()->children.push_back(current_function_or_task);
		delete (yyvsp[-3].string);
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 3369 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 136:
#line 627 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = NULL;
	}
#line 3377 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 137:
#line 630 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = new AstNode(AST_DPI_FUNCTION, AstNode::mkconst_str(*(yyvsp[-1].string)), AstNode::mkconst_str(*(yyvsp[-5].string) + ":" + RTLIL::unescape_id(*(yyvsp[-3].string))));
		current_function_or_task->str = *(yyvsp[0].string);
		append_attr(current_function_or_task, (yyvsp[-7].al));
		ast_stack.back()->children.push_back(current_function_or_task);
		delete (yyvsp[-5].string);
		delete (yyvsp[-3].string);
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 3392 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 138:
#line 639 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = NULL;
	}
#line 3400 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 139:
#line 642 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = new AstNode(AST_TASK);
		current_function_or_task->str = *(yyvsp[0].string);
		append_attr(current_function_or_task, (yyvsp[-3].al));
		ast_stack.back()->children.push_back(current_function_or_task);
		ast_stack.push_back(current_function_or_task);
		current_function_or_task_port_id = 1;
		delete (yyvsp[0].string);
	}
#line 3414 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 140:
#line 650 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = NULL;
		ast_stack.pop_back();
	}
#line 3423 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 141:
#line 654 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = new AstNode(AST_FUNCTION);
		current_function_or_task->str = *(yyvsp[0].string);
		append_attr(current_function_or_task, (yyvsp[-5].al));
		ast_stack.back()->children.push_back(current_function_or_task);
		ast_stack.push_back(current_function_or_task);
		AstNode *outreg = new AstNode(AST_WIRE);
		outreg->str = *(yyvsp[0].string);
		outreg->is_signed = (yyvsp[-2].boolean);
		outreg->is_reg = true;
		if ((yyvsp[-1].ast) != NULL) {
			outreg->children.push_back((yyvsp[-1].ast));
			outreg->is_signed = (yyvsp[-2].boolean) || (yyvsp[-1].ast)->is_signed;
			(yyvsp[-1].ast)->is_signed = false;
		}
		current_function_or_task->children.push_back(outreg);
		current_function_or_task_port_id = 1;
		delete (yyvsp[0].string);
	}
#line 3447 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 142:
#line 672 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task = NULL;
		ast_stack.pop_back();
	}
#line 3456 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 143:
#line 678 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task->children.push_back(AstNode::mkconst_str(*(yyvsp[-1].string)));
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 3466 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 144:
#line 683 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		current_function_or_task->children.push_back(AstNode::mkconst_str(*(yyvsp[0].string)));
		delete (yyvsp[0].string);
	}
#line 3475 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 153:
#line 703 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.boolean) = true;
	}
#line 3483 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 154:
#line 706 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.boolean) = false;
	}
#line 3491 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 157:
#line 711 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		albuf = nullptr;
		astbuf1 = nullptr;
		astbuf2 = nullptr;
	}
#line 3501 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 158:
#line 715 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
		if (astbuf2 != NULL)
			delete astbuf2;
		free_attr(albuf);
	}
#line 3512 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 162:
#line 726 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (albuf) {
			delete astbuf1;
			if (astbuf2 != NULL)
				delete astbuf2;
			free_attr(albuf);
		}
		albuf = (yyvsp[-2].al);
		astbuf1 = (yyvsp[-1].ast);
		astbuf2 = (yyvsp[0].ast);
		if (astbuf1->range_left >= 0 && astbuf1->range_right >= 0) {
			if (astbuf2) {
				frontend_verilog_yyerror("integer/genvar types cannot have packed dimensions (task/function arguments)");
			} else {
				astbuf2 = new AstNode(AST_RANGE);
				astbuf2->children.push_back(AstNode::mkconst_int(astbuf1->range_left, true));
				astbuf2->children.push_back(AstNode::mkconst_int(astbuf1->range_right, true));
			}
		}
		if (astbuf2 && astbuf2->children.size() != 2)
			frontend_verilog_yyerror("task/function argument range must be of the form: [<expr>:<expr>], [<expr>+:<expr>], or [<expr>-:<expr>]");
	}
#line 3539 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 170:
#line 763 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *en_expr = (yyvsp[-9].ast);
		char specify_edge = (yyvsp[-7].ch);
		AstNode *src_expr = (yyvsp[-6].ast);
		string *oper = (yyvsp[-5].string);
		specify_target *target = (yyvsp[-4].specify_target_ptr);
		specify_rise_fall *timing = (yyvsp[-1].specify_rise_fall_ptr);

		if (specify_edge != 0 && target->dat == nullptr)
			frontend_verilog_yyerror("Found specify edge but no data spec.\n");

		AstNode *cell = new AstNode(AST_CELL);
		ast_stack.back()->children.push_back(cell);
		cell->str = stringf("$specify$%d", autoidx++);
		cell->children.push_back(new AstNode(AST_CELLTYPE));
		cell->children.back()->str = target->dat ? "$specify3" : "$specify2";

		char oper_polarity = 0;
		char oper_type = oper->at(0);

		if (oper->size() == 3) {
			oper_polarity = oper->at(0);
			oper_type = oper->at(1);
		}

		cell->children.push_back(new AstNode(AST_PARASET, AstNode::mkconst_int(oper_type == '*', false, 1)));
		cell->children.back()->str = "\\FULL";

		cell->children.push_back(new AstNode(AST_PARASET, AstNode::mkconst_int(oper_polarity != 0, false, 1)));
		cell->children.back()->str = "\\SRC_DST_PEN";

		cell->children.push_back(new AstNode(AST_PARASET, AstNode::mkconst_int(oper_polarity == '+', false, 1)));
		cell->children.back()->str = "\\SRC_DST_POL";

		cell->children.push_back(new AstNode(AST_PARASET, timing->rise.t_min));
		cell->children.back()->str = "\\T_RISE_MIN";

		cell->children.push_back(new AstNode(AST_PARASET, timing->rise.t_avg));
		cell->children.back()->str = "\\T_RISE_TYP";

		cell->children.push_back(new AstNode(AST_PARASET, timing->rise.t_max));
		cell->children.back()->str = "\\T_RISE_MAX";

		cell->children.push_back(new AstNode(AST_PARASET, timing->fall.t_min));
		cell->children.back()->str = "\\T_FALL_MIN";

		cell->children.push_back(new AstNode(AST_PARASET, timing->fall.t_avg));
		cell->children.back()->str = "\\T_FALL_TYP";

		cell->children.push_back(new AstNode(AST_PARASET, timing->fall.t_max));
		cell->children.back()->str = "\\T_FALL_MAX";

		cell->children.push_back(new AstNode(AST_ARGUMENT, en_expr ? en_expr : AstNode::mkconst_int(1, false, 1)));
		cell->children.back()->str = "\\EN";

		cell->children.push_back(new AstNode(AST_ARGUMENT, src_expr));
		cell->children.back()->str = "\\SRC";

		cell->children.push_back(new AstNode(AST_ARGUMENT, target->dst));
		cell->children.back()->str = "\\DST";

		if (target->dat)
		{
			cell->children.push_back(new AstNode(AST_PARASET, AstNode::mkconst_int(specify_edge != 0, false, 1)));
			cell->children.back()->str = "\\EDGE_EN";

			cell->children.push_back(new AstNode(AST_PARASET, AstNode::mkconst_int(specify_edge == 'p', false, 1)));
			cell->children.back()->str = "\\EDGE_POL";

			cell->children.push_back(new AstNode(AST_PARASET, AstNode::mkconst_int(target->polarity_op != 0, false, 1)));
			cell->children.back()->str = "\\DAT_DST_PEN";

			cell->children.push_back(new AstNode(AST_PARASET, AstNode::mkconst_int(target->polarity_op == '+', false, 1)));
			cell->children.back()->str = "\\DAT_DST_POL";

			cell->children.push_back(new AstNode(AST_ARGUMENT, target->dat));
			cell->children.back()->str = "\\DAT";
		}

		delete oper;
		delete target;
		delete timing;
	}
#line 3627 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 171:
#line 846 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (*(yyvsp[-13].string) != "$setup" && *(yyvsp[-13].string) != "$hold" && *(yyvsp[-13].string) != "$setuphold" && *(yyvsp[-13].string) != "$removal" && *(yyvsp[-13].string) != "$recovery" &&
				*(yyvsp[-13].string) != "$recrem" && *(yyvsp[-13].string) != "$skew" && *(yyvsp[-13].string) != "$timeskew" && *(yyvsp[-13].string) != "$fullskew" && *(yyvsp[-13].string) != "$nochange")
			frontend_verilog_yyerror("Unsupported specify rule type: %s\n", (yyvsp[-13].string)->c_str());

		AstNode *src_pen = AstNode::mkconst_int((yyvsp[-11].ch) != 0, false, 1);
		AstNode *src_pol = AstNode::mkconst_int((yyvsp[-11].ch) == 'p', false, 1);
		AstNode *src_expr = (yyvsp[-10].ast), *src_en = (yyvsp[-9].ast) ? (yyvsp[-9].ast) : AstNode::mkconst_int(1, false, 1);

		AstNode *dst_pen = AstNode::mkconst_int((yyvsp[-7].ch) != 0, false, 1);
		AstNode *dst_pol = AstNode::mkconst_int((yyvsp[-7].ch) == 'p', false, 1);
		AstNode *dst_expr = (yyvsp[-6].ast), *dst_en = (yyvsp[-5].ast) ? (yyvsp[-5].ast) : AstNode::mkconst_int(1, false, 1);

		AstNode *limit = (yyvsp[-3].ast);
		AstNode *limit2 = (yyvsp[-2].ast);

		AstNode *cell = new AstNode(AST_CELL);
		ast_stack.back()->children.push_back(cell);
		cell->str = stringf("$specify$%d", autoidx++);
		cell->children.push_back(new AstNode(AST_CELLTYPE));
		cell->children.back()->str = "$specrule";

		cell->children.push_back(new AstNode(AST_PARASET, AstNode::mkconst_str(*(yyvsp[-13].string))));
		cell->children.back()->str = "\\TYPE";

		cell->children.push_back(new AstNode(AST_PARASET, limit));
		cell->children.back()->str = "\\T_LIMIT";

		cell->children.push_back(new AstNode(AST_PARASET, limit2 ? limit2 : AstNode::mkconst_int(0, true)));
		cell->children.back()->str = "\\T_LIMIT2";

		cell->children.push_back(new AstNode(AST_PARASET, src_pen));
		cell->children.back()->str = "\\SRC_PEN";

		cell->children.push_back(new AstNode(AST_PARASET, src_pol));
		cell->children.back()->str = "\\SRC_POL";

		cell->children.push_back(new AstNode(AST_PARASET, dst_pen));
		cell->children.back()->str = "\\DST_PEN";

		cell->children.push_back(new AstNode(AST_PARASET, dst_pol));
		cell->children.back()->str = "\\DST_POL";

		cell->children.push_back(new AstNode(AST_ARGUMENT, src_en));
		cell->children.back()->str = "\\SRC_EN";

		cell->children.push_back(new AstNode(AST_ARGUMENT, src_expr));
		cell->children.back()->str = "\\SRC";

		cell->children.push_back(new AstNode(AST_ARGUMENT, dst_en));
		cell->children.back()->str = "\\DST_EN";

		cell->children.push_back(new AstNode(AST_ARGUMENT, dst_expr));
		cell->children.back()->str = "\\DST";

		delete (yyvsp[-13].string);
	}
#line 3689 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 172:
#line 905 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 3697 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 173:
#line 908 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = nullptr;
	}
#line 3705 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 174:
#line 913 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[-1].ast);
	}
#line 3713 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 175:
#line 916 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = nullptr;
	}
#line 3721 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 176:
#line 921 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 3729 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 177:
#line 924 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = nullptr;
	}
#line 3737 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 178:
#line 929 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.specify_target_ptr) = new specify_target;
		(yyval.specify_target_ptr)->polarity_op = 0;
		(yyval.specify_target_ptr)->dst = (yyvsp[0].ast);
		(yyval.specify_target_ptr)->dat = nullptr;
	}
#line 3748 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 179:
#line 935 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.specify_target_ptr) = new specify_target;
		(yyval.specify_target_ptr)->polarity_op = 0;
		(yyval.specify_target_ptr)->dst = (yyvsp[-3].ast);
		(yyval.specify_target_ptr)->dat = (yyvsp[-1].ast);
	}
#line 3759 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 180:
#line 941 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.specify_target_ptr) = new specify_target;
		(yyval.specify_target_ptr)->polarity_op = '-';
		(yyval.specify_target_ptr)->dst = (yyvsp[-3].ast);
		(yyval.specify_target_ptr)->dat = (yyvsp[-1].ast);
	}
#line 3770 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 181:
#line 947 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.specify_target_ptr) = new specify_target;
		(yyval.specify_target_ptr)->polarity_op = '+';
		(yyval.specify_target_ptr)->dst = (yyvsp[-3].ast);
		(yyval.specify_target_ptr)->dat = (yyvsp[-1].ast);
	}
#line 3781 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 182:
#line 955 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { (yyval.ch) = 'p'; }
#line 3787 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 183:
#line 956 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { (yyval.ch) = 'n'; }
#line 3793 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 184:
#line 957 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { (yyval.ch) = 0; }
#line 3799 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 185:
#line 960 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.specify_rise_fall_ptr) = new specify_rise_fall;
		(yyval.specify_rise_fall_ptr)->rise = *(yyvsp[0].specify_triple_ptr);
		(yyval.specify_rise_fall_ptr)->fall.t_min = (yyvsp[0].specify_triple_ptr)->t_min->clone();
		(yyval.specify_rise_fall_ptr)->fall.t_avg = (yyvsp[0].specify_triple_ptr)->t_avg->clone();
		(yyval.specify_rise_fall_ptr)->fall.t_max = (yyvsp[0].specify_triple_ptr)->t_max->clone();
		delete (yyvsp[0].specify_triple_ptr);
	}
#line 3812 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 186:
#line 968 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.specify_rise_fall_ptr) = new specify_rise_fall;
		(yyval.specify_rise_fall_ptr)->rise = *(yyvsp[-3].specify_triple_ptr);
		(yyval.specify_rise_fall_ptr)->fall = *(yyvsp[-1].specify_triple_ptr);
		delete (yyvsp[-3].specify_triple_ptr);
		delete (yyvsp[-1].specify_triple_ptr);
	}
#line 3824 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 187:
#line 977 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.specify_triple_ptr) = new specify_triple;
		(yyval.specify_triple_ptr)->t_min = (yyvsp[0].ast);
		(yyval.specify_triple_ptr)->t_avg = (yyvsp[0].ast)->clone();
		(yyval.specify_triple_ptr)->t_max = (yyvsp[0].ast)->clone();
	}
#line 3835 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 188:
#line 983 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.specify_triple_ptr) = new specify_triple;
		(yyval.specify_triple_ptr)->t_min = (yyvsp[-4].ast);
		(yyval.specify_triple_ptr)->t_avg = (yyvsp[-2].ast);
		(yyval.specify_triple_ptr)->t_max = (yyvsp[0].ast);
	}
#line 3846 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 240:
#line 1111 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { delete (yyvsp[0].ast); }
#line 3852 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 241:
#line 1114 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { delete (yyvsp[0].ast); }
#line 3858 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 242:
#line 1117 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    { delete (yyvsp[0].string); }
#line 3864 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 243:
#line 1122 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf1->is_signed = true;
	}
#line 3872 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 245:
#line 1127 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (astbuf1->children.size() != 1)
			frontend_verilog_yyerror("Internal error in param_integer - should not happen?");
		astbuf1->children.push_back(new AstNode(AST_RANGE));
		astbuf1->children.back()->children.push_back(AstNode::mkconst_int(31, true));
		astbuf1->children.back()->children.push_back(AstNode::mkconst_int(0, true));
		astbuf1->is_signed = true;
	}
#line 3885 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 247:
#line 1137 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (astbuf1->children.size() != 1)
			frontend_verilog_yyerror("Parameter already declared as integer, cannot set to real.");
		astbuf1->children.push_back(new AstNode(AST_REALVALUE));
	}
#line 3895 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 249:
#line 1144 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[0].ast) != NULL) {
			if (astbuf1->children.size() != 1)
				frontend_verilog_yyerror("integer/real parameters should not have a range.");
			astbuf1->children.push_back((yyvsp[0].ast));
		}
	}
#line 3907 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 250:
#line 1153 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf1 = new AstNode(AST_PARAMETER);
		astbuf1->children.push_back(AstNode::mkconst_int(0, true));
		append_attr(astbuf1, (yyvsp[-1].al));
	}
#line 3917 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 251:
#line 1157 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
	}
#line 3925 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 252:
#line 1162 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf1 = new AstNode(AST_LOCALPARAM);
		astbuf1->children.push_back(AstNode::mkconst_int(0, true));
		append_attr(astbuf1, (yyvsp[-1].al));
	}
#line 3935 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 253:
#line 1166 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
	}
#line 3943 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 256:
#line 1174 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node;
		if (astbuf1 == nullptr) {
			if (!sv_mode)
				frontend_verilog_yyerror("In pure Verilog (not SystemVerilog), parameter/localparam with an initializer must use the parameter/localparam keyword");
			node = new AstNode(AST_PARAMETER);
			node->children.push_back(AstNode::mkconst_int(0, true));
		} else {
			node = astbuf1->clone();
		}
		node->str = *(yyvsp[-2].string);
		delete node->children[0];
		node->children[0] = (yyvsp[0].ast);
		ast_stack.back()->children.push_back(node);
		delete (yyvsp[-2].string);
	}
#line 3964 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 260:
#line 1198 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_DEFPARAM);
		node->children.push_back((yyvsp[-2].ast));
		node->children.push_back((yyvsp[0].ast));
		if ((yyvsp[-3].ast) != NULL)
			node->children.push_back((yyvsp[-3].ast));
		ast_stack.back()->children.push_back(node);
	}
#line 3977 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 261:
#line 1208 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		albuf = (yyvsp[-2].al);
		astbuf1 = (yyvsp[-1].ast);
		astbuf2 = (yyvsp[0].ast);
		if (astbuf1->range_left >= 0 && astbuf1->range_right >= 0) {
			if (astbuf2) {
				frontend_verilog_yyerror("integer/genvar types cannot have packed dimensions.");
			} else {
				astbuf2 = new AstNode(AST_RANGE);
				astbuf2->children.push_back(AstNode::mkconst_int(astbuf1->range_left, true));
				astbuf2->children.push_back(AstNode::mkconst_int(astbuf1->range_right, true));
			}
		}
		if (astbuf2 && astbuf2->children.size() != 2)
			frontend_verilog_yyerror("wire/reg/logic packed dimension must be of the form: [<expr>:<expr>], [<expr>+:<expr>], or [<expr>-:<expr>]");
	}
#line 3998 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 262:
#line 1223 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
		if (astbuf2 != NULL)
			delete astbuf2;
		free_attr(albuf);
	}
#line 4009 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 264:
#line 1229 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_WIRE));
		ast_stack.back()->children.back()->str = *(yyvsp[0].string);
		append_attr(ast_stack.back()->children.back(), (yyvsp[-2].al));
		ast_stack.back()->children.push_back(new AstNode(AST_ASSIGN, new AstNode(AST_IDENTIFIER), AstNode::mkconst_int(0, false, 1)));
		ast_stack.back()->children.back()->children[0]->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
	}
#line 4022 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 266:
#line 1237 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_WIRE));
		ast_stack.back()->children.back()->str = *(yyvsp[0].string);
		append_attr(ast_stack.back()->children.back(), (yyvsp[-2].al));
		ast_stack.back()->children.push_back(new AstNode(AST_ASSIGN, new AstNode(AST_IDENTIFIER), AstNode::mkconst_int(1, false, 1)));
		ast_stack.back()->children.back()->children[0]->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
	}
#line 4035 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 269:
#line 1248 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *wire_node = ast_stack.back()->children.at(GetSize(ast_stack.back()->children)-2)->clone();
		AstNode *assign_node = ast_stack.back()->children.at(GetSize(ast_stack.back()->children)-1)->clone();
		wire_node->str = *(yyvsp[0].string);
		assign_node->children[0]->str = *(yyvsp[0].string);
		ast_stack.back()->children.push_back(wire_node);
		ast_stack.back()->children.push_back(assign_node);
		delete (yyvsp[0].string);
	}
#line 4049 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 272:
#line 1262 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		bool attr_anyconst = false;
		bool attr_anyseq = false;
		bool attr_allconst = false;
		bool attr_allseq = false;
		if (ast_stack.back()->children.back()->get_bool_attribute("\\anyconst")) {
			delete ast_stack.back()->children.back()->attributes.at("\\anyconst");
			ast_stack.back()->children.back()->attributes.erase("\\anyconst");
			attr_anyconst = true;
		}
		if (ast_stack.back()->children.back()->get_bool_attribute("\\anyseq")) {
			delete ast_stack.back()->children.back()->attributes.at("\\anyseq");
			ast_stack.back()->children.back()->attributes.erase("\\anyseq");
			attr_anyseq = true;
		}
		if (ast_stack.back()->children.back()->get_bool_attribute("\\allconst")) {
			delete ast_stack.back()->children.back()->attributes.at("\\allconst");
			ast_stack.back()->children.back()->attributes.erase("\\allconst");
			attr_allconst = true;
		}
		if (ast_stack.back()->children.back()->get_bool_attribute("\\allseq")) {
			delete ast_stack.back()->children.back()->attributes.at("\\allseq");
			ast_stack.back()->children.back()->attributes.erase("\\allseq");
			attr_allseq = true;
		}
		if (current_wire_rand || attr_anyconst || attr_anyseq || attr_allconst || attr_allseq) {
			AstNode *wire = new AstNode(AST_IDENTIFIER);
			AstNode *fcall = new AstNode(AST_FCALL);
			wire->str = ast_stack.back()->children.back()->str;
			fcall->str = current_wire_const ? "\\$anyconst" : "\\$anyseq";
			if (attr_anyconst)
				fcall->str = "\\$anyconst";
			if (attr_anyseq)
				fcall->str = "\\$anyseq";
			if (attr_allconst)
				fcall->str = "\\$allconst";
			if (attr_allseq)
				fcall->str = "\\$allseq";
			fcall->attributes["\\reg"] = AstNode::mkconst_str(RTLIL::unescape_id(wire->str));
			ast_stack.back()->children.push_back(new AstNode(AST_ASSIGN, wire, fcall));
		}
	}
#line 4096 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 273:
#line 1304 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *wire = new AstNode(AST_IDENTIFIER);
		wire->str = ast_stack.back()->children.back()->str;
		if (astbuf1->is_input) {
			if (astbuf1->attributes.count("\\defaultvalue"))
				delete astbuf1->attributes.at("\\defaultvalue");
			astbuf1->attributes["\\defaultvalue"] = (yyvsp[0].ast);
		} else
		if (astbuf1->is_reg || astbuf1->is_logic)
			ast_stack.back()->children.push_back(new AstNode(AST_INITIAL, new AstNode(AST_BLOCK, new AstNode(AST_ASSIGN_LE, wire, (yyvsp[0].ast)))));
		else
			ast_stack.back()->children.push_back(new AstNode(AST_ASSIGN, wire, (yyvsp[0].ast)));
	}
#line 4114 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 274:
#line 1319 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (astbuf1 == nullptr)
			frontend_verilog_yyerror("Internal error - should not happen - no AST_WIRE node.");
		AstNode *node = astbuf1->clone();
		node->str = *(yyvsp[-1].string);
		append_attr_clone(node, albuf);
		if (astbuf2 != NULL)
			node->children.push_back(astbuf2->clone());
		if ((yyvsp[0].ast) != NULL) {
			if (node->is_input || node->is_output)
				frontend_verilog_yyerror("input/output/inout ports cannot have unpacked dimensions.");
			if (!astbuf2) {
				AstNode *rng = new AstNode(AST_RANGE);
				rng->children.push_back(AstNode::mkconst_int(0, true));
				rng->children.push_back(AstNode::mkconst_int(0, true));
				node->children.push_back(rng);
			}
			node->type = AST_MEMORY;
			auto *rangeNode = (yyvsp[0].ast);
			if (rangeNode->type == AST_RANGE && rangeNode->children.size() == 1) {
				// SV array size [n], rewrite as [n-1:0]
				rangeNode->children[0] = new AstNode(AST_SUB, rangeNode->children[0], AstNode::mkconst_int(1, true));
				rangeNode->children.push_back(AstNode::mkconst_int(0, false));
			}
			node->children.push_back(rangeNode);
		}
		if (current_function_or_task == NULL) {
			if (do_not_require_port_stubs && (node->is_input || node->is_output) && port_stubs.count(*(yyvsp[-1].string)) == 0) {
				port_stubs[*(yyvsp[-1].string)] = ++port_counter;
			}
			if (port_stubs.count(*(yyvsp[-1].string)) != 0) {
				if (!node->is_input && !node->is_output)
					frontend_verilog_yyerror("Module port `%s' is neither input nor output.", (yyvsp[-1].string)->c_str());
				if (node->is_reg && node->is_input && !node->is_output && !sv_mode)
					frontend_verilog_yyerror("Input port `%s' is declared as register.", (yyvsp[-1].string)->c_str());
				node->port_id = port_stubs[*(yyvsp[-1].string)];
				port_stubs.erase(*(yyvsp[-1].string));
			} else {
				if (node->is_input || node->is_output)
					frontend_verilog_yyerror("Module port `%s' is not declared in module header.", (yyvsp[-1].string)->c_str());
			}
		} else {
			if (node->is_input || node->is_output)
				node->port_id = current_function_or_task_port_id++;
		}
		ast_stack.back()->children.push_back(node);

		delete (yyvsp[-1].string);
	}
#line 4168 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 278:
#line 1376 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_ASSIGN, (yyvsp[-2].ast), (yyvsp[0].ast)));
	}
#line 4176 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 279:
#line 1381 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf1 = new AstNode(AST_CELL);
		append_attr(astbuf1, (yyvsp[-1].al));
		astbuf1->children.push_back(new AstNode(AST_CELLTYPE));
		astbuf1->children[0]->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
	}
#line 4188 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 280:
#line 1387 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
	}
#line 4196 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 281:
#line 1390 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf1 = new AstNode(AST_PRIMITIVE);
		astbuf1->str = *(yyvsp[-1].string);
		append_attr(astbuf1, (yyvsp[-2].al));
		delete (yyvsp[-1].string);
	}
#line 4207 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 282:
#line 1395 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete astbuf1;
	}
#line 4215 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 283:
#line 1400 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = (yyvsp[0].string);
	}
#line 4223 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 284:
#line 1403 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = new std::string("or");
	}
#line 4231 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 287:
#line 1412 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf2 = astbuf1->clone();
		if (astbuf2->type != AST_PRIMITIVE)
			astbuf2->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
		ast_stack.back()->children.push_back(astbuf2);
	}
#line 4243 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 289:
#line 1419 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf2 = astbuf1->clone();
		if (astbuf2->type != AST_PRIMITIVE)
			astbuf2->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
		ast_stack.back()->children.push_back(new AstNode(AST_CELLARRAY, (yyvsp[0].ast), astbuf2));
	}
#line 4255 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 294:
#line 1433 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		astbuf2 = astbuf1->clone();
		ast_stack.back()->children.push_back(astbuf2);
	}
#line 4264 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 301:
#line 1446 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_PARASET);
		astbuf1->children.push_back(node);
		node->children.push_back((yyvsp[0].ast));
	}
#line 4274 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 302:
#line 1451 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_PARASET);
		node->str = *(yyvsp[-3].string);
		astbuf1->children.push_back(node);
		node->children.push_back((yyvsp[-1].ast));
		delete (yyvsp[-3].string);
	}
#line 4286 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 303:
#line 1460 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		// remove empty args from end of list
		while (!astbuf2->children.empty()) {
			AstNode *node = astbuf2->children.back();
			if (node->type != AST_ARGUMENT) break;
			if (!node->children.empty()) break;
			if (!node->str.empty()) break;
			astbuf2->children.pop_back();
			delete node;
		}

		// check port types
		bool has_positional_args = false;
		bool has_named_args = false;
		for (auto node : astbuf2->children) {
			if (node->type != AST_ARGUMENT) continue;
			if (node->str.empty())
				has_positional_args = true;
			else
				has_named_args = true;
		}

		if (has_positional_args && has_named_args)
			frontend_verilog_yyerror("Mix of positional and named cell ports.");
	}
#line 4316 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 306:
#line 1490 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ARGUMENT);
		astbuf2->children.push_back(node);
		free_attr((yyvsp[0].al));
	}
#line 4326 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 307:
#line 1495 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ARGUMENT);
		astbuf2->children.push_back(node);
		node->children.push_back((yyvsp[0].ast));
		free_attr((yyvsp[-1].al));
	}
#line 4337 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 308:
#line 1501 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ARGUMENT);
		node->str = *(yyvsp[-3].string);
		astbuf2->children.push_back(node);
		node->children.push_back((yyvsp[-1].ast));
		delete (yyvsp[-3].string);
		free_attr((yyvsp[-5].al));
	}
#line 4350 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 309:
#line 1509 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ARGUMENT);
		node->str = *(yyvsp[-2].string);
		astbuf2->children.push_back(node);
		delete (yyvsp[-2].string);
		free_attr((yyvsp[-4].al));
	}
#line 4362 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 310:
#line 1516 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ARGUMENT);
		node->str = *(yyvsp[0].string);
		astbuf2->children.push_back(node);
		node->children.push_back(new AstNode(AST_IDENTIFIER));
		node->children.back()->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
		free_attr((yyvsp[-2].al));
	}
#line 4376 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 311:
#line 1527 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ALWAYS);
		append_attr(node, (yyvsp[-1].al));
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 4387 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 312:
#line 1532 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
	}
#line 4397 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 313:
#line 1536 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 4406 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 314:
#line 1540 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_INITIAL);
		append_attr(node, (yyvsp[-1].al));
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
	}
#line 4420 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 315:
#line 1548 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 4429 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 325:
#line 1567 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_POSEDGE);
		ast_stack.back()->children.push_back(node);
		node->children.push_back((yyvsp[0].ast));
	}
#line 4439 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 326:
#line 1572 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_NEGEDGE);
		ast_stack.back()->children.push_back(node);
		node->children.push_back((yyvsp[0].ast));
	}
#line 4449 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 327:
#line 1577 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_EDGE);
		ast_stack.back()->children.push_back(node);
		node->children.push_back((yyvsp[0].ast));
	}
#line 4459 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 328:
#line 1584 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = (yyvsp[0].string);
	}
#line 4467 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 329:
#line 1587 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = NULL;
	}
#line 4475 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 330:
#line 1592 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = (yyvsp[-1].string);
	}
#line 4483 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 331:
#line 1595 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.string) = NULL;
	}
#line 4491 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 332:
#line 1600 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.boolean) = true;
	}
#line 4499 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 333:
#line 1603 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.boolean) = false;
	}
#line 4507 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 334:
#line 1606 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.boolean) = false;
	}
#line 4515 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 335:
#line 1611 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
        AstNode *modport = new AstNode(AST_MODPORT);
        ast_stack.back()->children.push_back(modport);
        ast_stack.push_back(modport);
        modport->str = *(yyvsp[0].string);
        delete (yyvsp[0].string);
    }
#line 4527 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 336:
#line 1617 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
        ast_stack.pop_back();
        log_assert(ast_stack.size() == 2);
    }
#line 4536 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 344:
#line 1633 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
        AstNode *modport_member = new AstNode(AST_MODPORTMEMBER);
        ast_stack.back()->children.push_back(modport_member);
        modport_member->str = *(yyvsp[0].string);
        modport_member->is_input = current_modport_input;
        modport_member->is_output = current_modport_output;
        delete (yyvsp[0].string);
    }
#line 4549 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 345:
#line 1643 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {current_modport_input = 1; current_modport_output = 0;}
#line 4555 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 346:
#line 1643 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {current_modport_input = 0; current_modport_output = 1;}
#line 4561 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 347:
#line 1646 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (noassert_mode) {
			delete (yyvsp[-2].ast);
		} else {
			AstNode *node = new AstNode(assume_asserts_mode ? AST_ASSUME : AST_ASSERT, (yyvsp[-2].ast));
			if ((yyvsp[-6].string) != nullptr)
				node->str = *(yyvsp[-6].string);
			ast_stack.back()->children.push_back(node);
		}
		if ((yyvsp[-6].string) != nullptr)
			delete (yyvsp[-6].string);
	}
#line 4578 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 348:
#line 1658 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (noassume_mode) {
			delete (yyvsp[-2].ast);
		} else {
			AstNode *node = new AstNode(assert_assumes_mode ? AST_ASSERT : AST_ASSUME, (yyvsp[-2].ast));
			if ((yyvsp[-6].string) != nullptr)
				node->str = *(yyvsp[-6].string);
			ast_stack.back()->children.push_back(node);
		}
		if ((yyvsp[-6].string) != nullptr)
			delete (yyvsp[-6].string);
	}
#line 4595 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 349:
#line 1670 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (noassert_mode) {
			delete (yyvsp[-2].ast);
		} else {
			AstNode *node = new AstNode(assume_asserts_mode ? AST_FAIR : AST_LIVE, (yyvsp[-2].ast));
			if ((yyvsp[-7].string) != nullptr)
				node->str = *(yyvsp[-7].string);
			ast_stack.back()->children.push_back(node);
		}
		if ((yyvsp[-7].string) != nullptr)
			delete (yyvsp[-7].string);
	}
#line 4612 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 350:
#line 1682 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (noassume_mode) {
			delete (yyvsp[-2].ast);
		} else {
			AstNode *node = new AstNode(assert_assumes_mode ? AST_LIVE : AST_FAIR, (yyvsp[-2].ast));
			if ((yyvsp[-7].string) != nullptr)
				node->str = *(yyvsp[-7].string);
			ast_stack.back()->children.push_back(node);
		}
		if ((yyvsp[-7].string) != nullptr)
			delete (yyvsp[-7].string);
	}
#line 4629 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 351:
#line 1694 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_COVER, (yyvsp[-2].ast));
		if ((yyvsp[-6].string) != nullptr) {
			node->str = *(yyvsp[-6].string);
			delete (yyvsp[-6].string);
		}
		ast_stack.back()->children.push_back(node);
	}
#line 4642 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 352:
#line 1702 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_COVER, AstNode::mkconst_int(1, false));
		if ((yyvsp[-5].string) != nullptr) {
			node->str = *(yyvsp[-5].string);
			delete (yyvsp[-5].string);
		}
		ast_stack.back()->children.push_back(node);
	}
#line 4655 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 353:
#line 1710 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_COVER, AstNode::mkconst_int(1, false));
		if ((yyvsp[-2].string) != nullptr) {
			node->str = *(yyvsp[-2].string);
			delete (yyvsp[-2].string);
		}
		ast_stack.back()->children.push_back(node);
	}
#line 4668 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 354:
#line 1718 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (norestrict_mode) {
			delete (yyvsp[-2].ast);
		} else {
			AstNode *node = new AstNode(AST_ASSUME, (yyvsp[-2].ast));
			if ((yyvsp[-6].string) != nullptr)
				node->str = *(yyvsp[-6].string);
			ast_stack.back()->children.push_back(node);
		}
		if (!(yyvsp[-4].boolean))
			log_file_warning(current_filename, get_line_num(), "SystemVerilog does not allow \"restrict\" without \"property\".\n");
		if ((yyvsp[-6].string) != nullptr)
			delete (yyvsp[-6].string);
	}
#line 4687 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 355:
#line 1732 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (norestrict_mode) {
			delete (yyvsp[-2].ast);
		} else {
			AstNode *node = new AstNode(AST_FAIR, (yyvsp[-2].ast));
			if ((yyvsp[-7].string) != nullptr)
				node->str = *(yyvsp[-7].string);
			ast_stack.back()->children.push_back(node);
		}
		if (!(yyvsp[-5].boolean))
			log_file_warning(current_filename, get_line_num(), "SystemVerilog does not allow \"restrict\" without \"property\".\n");
		if ((yyvsp[-7].string) != nullptr)
			delete (yyvsp[-7].string);
	}
#line 4706 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 356:
#line 1748 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(assume_asserts_mode ? AST_ASSUME : AST_ASSERT, (yyvsp[-2].ast)));
		if ((yyvsp[-6].string) != nullptr) {
			ast_stack.back()->children.back()->str = *(yyvsp[-6].string);
			delete (yyvsp[-6].string);
		}
	}
#line 4718 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 357:
#line 1755 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_ASSUME, (yyvsp[-2].ast)));
		if ((yyvsp[-6].string) != nullptr) {
			ast_stack.back()->children.back()->str = *(yyvsp[-6].string);
			delete (yyvsp[-6].string);
		}
	}
#line 4730 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 358:
#line 1762 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(assume_asserts_mode ? AST_FAIR : AST_LIVE, (yyvsp[-2].ast)));
		if ((yyvsp[-7].string) != nullptr) {
			ast_stack.back()->children.back()->str = *(yyvsp[-7].string);
			delete (yyvsp[-7].string);
		}
	}
#line 4742 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 359:
#line 1769 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_FAIR, (yyvsp[-2].ast)));
		if ((yyvsp[-7].string) != nullptr) {
			ast_stack.back()->children.back()->str = *(yyvsp[-7].string);
			delete (yyvsp[-7].string);
		}
	}
#line 4754 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 360:
#line 1776 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_COVER, (yyvsp[-2].ast)));
		if ((yyvsp[-6].string) != nullptr) {
			ast_stack.back()->children.back()->str = *(yyvsp[-6].string);
			delete (yyvsp[-6].string);
		}
	}
#line 4766 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 361:
#line 1783 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (norestrict_mode) {
			delete (yyvsp[-2].ast);
		} else {
			ast_stack.back()->children.push_back(new AstNode(AST_ASSUME, (yyvsp[-2].ast)));
			if ((yyvsp[-6].string) != nullptr) {
				ast_stack.back()->children.back()->str = *(yyvsp[-6].string);
				delete (yyvsp[-6].string);
			}
		}
	}
#line 4782 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 362:
#line 1794 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (norestrict_mode) {
			delete (yyvsp[-2].ast);
		} else {
			ast_stack.back()->children.push_back(new AstNode(AST_FAIR, (yyvsp[-2].ast)));
			if ((yyvsp[-7].string) != nullptr) {
				ast_stack.back()->children.back()->str = *(yyvsp[-7].string);
				delete (yyvsp[-7].string);
			}
		}
	}
#line 4798 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 363:
#line 1807 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ASSIGN_EQ, (yyvsp[-3].ast), (yyvsp[0].ast));
		ast_stack.back()->children.push_back(node);
	}
#line 4807 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 364:
#line 1811 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ASSIGN_EQ, (yyvsp[-1].ast), new AstNode(AST_ADD, (yyvsp[-1].ast)->clone(), AstNode::mkconst_int(1, true)));
		ast_stack.back()->children.push_back(node);
	}
#line 4816 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 365:
#line 1815 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ASSIGN_EQ, (yyvsp[-1].ast), new AstNode(AST_SUB, (yyvsp[-1].ast)->clone(), AstNode::mkconst_int(1, true)));
		ast_stack.back()->children.push_back(node);
	}
#line 4825 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 366:
#line 1819 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_ASSIGN_LE, (yyvsp[-3].ast), (yyvsp[0].ast));
		ast_stack.back()->children.push_back(node);
	}
#line 4834 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 375:
#line 1829 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_TCALL);
		node->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[0].al));
	}
#line 4847 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 376:
#line 1836 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
	}
#line 4855 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 377:
#line 1839 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_TCALL);
		node->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[0].al));
	}
#line 4868 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 378:
#line 1846 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
	}
#line 4876 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 379:
#line 1849 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[-2].al));
		if ((yyvsp[0].string) != NULL)
			node->str = *(yyvsp[0].string);
	}
#line 4889 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 380:
#line 1856 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[-4].string) != NULL && (yyvsp[0].string) != NULL && *(yyvsp[-4].string) != *(yyvsp[0].string))
			frontend_verilog_yyerror("Begin label (%s) and end label (%s) don't match.", (yyvsp[-4].string)->c_str()+1, (yyvsp[0].string)->c_str()+1);
		if ((yyvsp[-4].string) != NULL)
			delete (yyvsp[-4].string);
		if ((yyvsp[0].string) != NULL)
			delete (yyvsp[0].string);
		ast_stack.pop_back();
	}
#line 4903 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 381:
#line 1865 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_FOR);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[-2].al));
	}
#line 4914 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 382:
#line 1870 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back((yyvsp[0].ast));
	}
#line 4922 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 383:
#line 1872 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
	}
#line 4932 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 384:
#line 1876 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 4941 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 385:
#line 1880 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_WHILE);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[-4].al));
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back((yyvsp[-1].ast));
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
	}
#line 4956 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 386:
#line 1889 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 4965 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 387:
#line 1893 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_REPEAT);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[-4].al));
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back((yyvsp[-1].ast));
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
	}
#line 4980 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 388:
#line 1902 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 4989 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 389:
#line 1906 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_CASE);
		AstNode *block = new AstNode(AST_BLOCK);
		AstNode *cond = new AstNode(AST_COND, AstNode::mkconst_int(1, false, 1), block);
		ast_stack.back()->children.push_back(node);
		node->children.push_back(new AstNode(AST_REDUCE_BOOL, (yyvsp[-1].ast)));
		node->children.push_back(cond);
		ast_stack.push_back(node);
		ast_stack.push_back(block);
		append_attr(node, (yyvsp[-4].al));
	}
#line 5005 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 390:
#line 1916 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 5014 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 391:
#line 1920 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_CASE, (yyvsp[-1].ast));
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[-4].al));
	}
#line 5025 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 392:
#line 1925 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.pop_back();
		ast_stack.pop_back();
	}
#line 5034 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 393:
#line 1931 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.boolean) = false;
	}
#line 5042 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 394:
#line 1934 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.boolean) = (yyvsp[0].al);
	}
#line 5050 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 395:
#line 1937 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.boolean) = true;
	}
#line 5058 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 396:
#line 1942 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[0].boolean)) (*(yyvsp[-1].al))["\\parallel_case"] = AstNode::mkconst_int(1, false);
		(yyval.al) = (yyvsp[-1].al);
	}
#line 5067 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 397:
#line 1948 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.push_back(0);
	}
#line 5075 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 398:
#line 1951 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.push_back('x');
	}
#line 5083 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 399:
#line 1954 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.push_back('z');
	}
#line 5091 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 400:
#line 1959 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (ast_stack.back()->attributes.count("\\full_case") == 0)
			ast_stack.back()->attributes["\\full_case"] = AstNode::mkconst_int(1, false);
	}
#line 5100 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 401:
#line 1963 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if (ast_stack.back()->attributes.count("\\parallel_case") == 0)
			ast_stack.back()->attributes["\\parallel_case"] = AstNode::mkconst_int(1, false);
	}
#line 5109 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 405:
#line 1974 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *block = new AstNode(AST_BLOCK);
		AstNode *cond = new AstNode(AST_COND, new AstNode(AST_DEFAULT), block);
		ast_stack.pop_back();
		ast_stack.back()->children.push_back(cond);
		ast_stack.push_back(block);
	}
#line 5121 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 410:
#line 1988 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(
				case_type_stack.size() && case_type_stack.back() == 'x' ? AST_CONDX :
				case_type_stack.size() && case_type_stack.back() == 'z' ? AST_CONDZ : AST_COND);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 5133 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 411:
#line 1994 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *block = new AstNode(AST_BLOCK);
		ast_stack.back()->children.push_back(block);
		ast_stack.push_back(block);
		case_type_stack.push_back(0);
	}
#line 5144 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 412:
#line 1999 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.pop_back();
		ast_stack.pop_back();
		ast_stack.pop_back();
	}
#line 5154 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 415:
#line 2010 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(
				case_type_stack.size() && case_type_stack.back() == 'x' ? AST_CONDX :
				case_type_stack.size() && case_type_stack.back() == 'z' ? AST_CONDZ : AST_COND);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 5166 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 416:
#line 2016 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.push_back(0);
	}
#line 5174 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 417:
#line 2018 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.pop_back();
		ast_stack.pop_back();
	}
#line 5183 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 420:
#line 2028 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_DEFAULT));
	}
#line 5191 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 421:
#line 2031 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back(new AstNode(AST_IDENTIFIER));
		ast_stack.back()->children.back()->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
	}
#line 5201 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 422:
#line 2036 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back((yyvsp[0].ast));
	}
#line 5209 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 423:
#line 2039 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back((yyvsp[0].ast));
	}
#line 5217 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 424:
#line 2044 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_PREFIX, (yyvsp[-3].ast), (yyvsp[0].ast));
		(yyval.ast)->str = *(yyvsp[-5].string);
		delete (yyvsp[-5].string);
	}
#line 5227 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 425:
#line 2049 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_IDENTIFIER, (yyvsp[0].ast));
		(yyval.ast)->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
		if ((yyvsp[0].ast) == nullptr && ((yyval.ast)->str == "\\$initstate" ||
				(yyval.ast)->str == "\\$anyconst" || (yyval.ast)->str == "\\$anyseq" ||
				(yyval.ast)->str == "\\$allconst" || (yyval.ast)->str == "\\$allseq"))
			(yyval.ast)->type = AST_FCALL;
	}
#line 5241 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 426:
#line 2058 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_IDENTIFIER, (yyvsp[0].ast));
		(yyval.ast)->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
	}
#line 5251 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 427:
#line 2065 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 5259 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 428:
#line 2068 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[-1].ast);
	}
#line 5267 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 429:
#line 2073 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_CONCAT);
		(yyval.ast)->children.push_back((yyvsp[0].ast));
	}
#line 5276 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 430:
#line 2077 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
		(yyval.ast)->children.push_back((yyvsp[-2].ast));
	}
#line 5285 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 437:
#line 2095 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back((yyvsp[0].ast));
	}
#line 5293 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 442:
#line 2108 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_GENFOR);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 5303 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 443:
#line 2112 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.back()->children.push_back((yyvsp[0].ast));
	}
#line 5311 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 444:
#line 2114 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
	}
#line 5319 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 445:
#line 2117 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_GENIF);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
		ast_stack.back()->children.push_back((yyvsp[-1].ast));
	}
#line 5330 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 446:
#line 2122 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
	}
#line 5338 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 447:
#line 2125 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_GENCASE, (yyvsp[-1].ast));
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 5348 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 448:
#line 2129 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		case_type_stack.pop_back();
		ast_stack.pop_back();
	}
#line 5357 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 449:
#line 2133 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_GENBLOCK);
		node->str = (yyvsp[0].string) ? *(yyvsp[0].string) : std::string();
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 5368 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 450:
#line 2138 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[-4].string) != NULL)
			delete (yyvsp[-4].string);
		if ((yyvsp[0].string) != NULL)
			delete (yyvsp[0].string);
		ast_stack.pop_back();
	}
#line 5380 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 451:
#line 2145 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_TECALL);
		node->str = *(yyvsp[0].string);
		delete (yyvsp[0].string);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 5392 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 452:
#line 2151 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();		
	}
#line 5400 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 453:
#line 2156 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_GENBLOCK);
		ast_stack.back()->children.push_back(node);
		ast_stack.push_back(node);
	}
#line 5410 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 454:
#line 2160 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		ast_stack.pop_back();
	}
#line 5418 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 459:
#line 2171 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 5426 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 460:
#line 2174 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_TERNARY);
		(yyval.ast)->children.push_back((yyvsp[-5].ast));
		(yyval.ast)->children.push_back((yyvsp[-2].ast));
		(yyval.ast)->children.push_back((yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-3].al));
	}
#line 5438 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 461:
#line 2183 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
	}
#line 5446 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 462:
#line 2186 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[0].string)->substr(0, 1) != "'")
			frontend_verilog_yyerror("Cast operation must be applied on sized constants e.g. (<expr>)<constval> , while %s is not a sized constant.", (yyvsp[0].string)->c_str());
		AstNode *bits = (yyvsp[-2].ast);
		AstNode *val = const2ast(*(yyvsp[0].string), case_type_stack.size() == 0 ? 0 : case_type_stack.back(), !lib_mode);
		if (val == NULL)
			log_error("Value conversion failed: `%s'\n", (yyvsp[0].string)->c_str());
		(yyval.ast) = new AstNode(AST_TO_BITS, bits, val);
		delete (yyvsp[0].string);
	}
#line 5461 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 463:
#line 2196 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		if ((yyvsp[0].string)->substr(0, 1) != "'")
			frontend_verilog_yyerror("Cast operation must be applied on sized constants, e.g. <ID>\'d0, while %s is not a sized constant.", (yyvsp[0].string)->c_str());
		AstNode *bits = new AstNode(AST_IDENTIFIER);
		bits->str = *(yyvsp[-1].string);
		AstNode *val = const2ast(*(yyvsp[0].string), case_type_stack.size() == 0 ? 0 : case_type_stack.back(), !lib_mode);
		if (val == NULL)
			log_error("Value conversion failed: `%s'\n", (yyvsp[0].string)->c_str());
		(yyval.ast) = new AstNode(AST_TO_BITS, bits, val);
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 5478 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 464:
#line 2208 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = const2ast(*(yyvsp[-1].string) + *(yyvsp[0].string), case_type_stack.size() == 0 ? 0 : case_type_stack.back(), !lib_mode);
		if ((yyval.ast) == NULL || (*(yyvsp[0].string))[0] != '\'')
			log_error("Value conversion failed: `%s%s'\n", (yyvsp[-1].string)->c_str(), (yyvsp[0].string)->c_str());
		delete (yyvsp[-1].string);
		delete (yyvsp[0].string);
	}
#line 5490 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 465:
#line 2215 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = const2ast(*(yyvsp[0].string), case_type_stack.size() == 0 ? 0 : case_type_stack.back(), !lib_mode);
		if ((yyval.ast) == NULL)
			log_error("Value conversion failed: `%s'\n", (yyvsp[0].string)->c_str());
		delete (yyvsp[0].string);
	}
#line 5501 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 466:
#line 2221 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REALVALUE);
		char *p = (char*)malloc(GetSize(*(yyvsp[0].string)) + 1), *q;
		for (int i = 0, j = 0; j < GetSize(*(yyvsp[0].string)); j++)
			if ((*(yyvsp[0].string))[j] != '_')
				p[i++] = (*(yyvsp[0].string))[j], p[i] = 0;
		(yyval.ast)->realvalue = strtod(p, &q);
		log_assert(*q == 0);
		delete (yyvsp[0].string);
		free(p);
	}
#line 5517 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 467:
#line 2232 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = AstNode::mkconst_str(*(yyvsp[0].string));
		delete (yyvsp[0].string);
	}
#line 5526 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 468:
#line 2236 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		AstNode *node = new AstNode(AST_FCALL);
		node->str = *(yyvsp[-1].string);
		delete (yyvsp[-1].string);
		ast_stack.push_back(node);
		append_attr(node, (yyvsp[0].al));
	}
#line 5538 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 469:
#line 2242 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = ast_stack.back();
		ast_stack.pop_back();
	}
#line 5547 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 470:
#line 2246 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_TO_SIGNED, (yyvsp[-1].ast));
		append_attr((yyval.ast), (yyvsp[-3].al));
	}
#line 5556 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 471:
#line 2250 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_TO_UNSIGNED, (yyvsp[-1].ast));
		append_attr((yyval.ast), (yyvsp[-3].al));
	}
#line 5565 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 472:
#line 2254 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[-1].ast);
	}
#line 5573 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 473:
#line 2257 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		delete (yyvsp[-5].ast);
		(yyval.ast) = (yyvsp[-3].ast);
		delete (yyvsp[-1].ast);
	}
#line 5583 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 474:
#line 2262 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[-1].ast);
	}
#line 5591 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 475:
#line 2265 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REPLICATE, (yyvsp[-4].ast), (yyvsp[-2].ast));
	}
#line 5599 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 476:
#line 2268 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_NOT, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5608 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 477:
#line 2272 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_AND, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5617 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 478:
#line 2276 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_NOT, new AstNode(AST_BIT_AND, (yyvsp[-3].ast), (yyvsp[0].ast)));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5626 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 479:
#line 2280 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_OR, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5635 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 480:
#line 2284 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_NOT, new AstNode(AST_BIT_OR, (yyvsp[-3].ast), (yyvsp[0].ast)));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5644 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 481:
#line 2288 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_XOR, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5653 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 482:
#line 2292 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_BIT_XNOR, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5662 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 483:
#line 2296 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_AND, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5671 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 484:
#line 2300 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_AND, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
		(yyval.ast) = new AstNode(AST_LOGIC_NOT, (yyval.ast));
	}
#line 5681 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 485:
#line 2305 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_OR, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5690 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 486:
#line 2309 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_OR, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
		(yyval.ast) = new AstNode(AST_LOGIC_NOT, (yyval.ast));
	}
#line 5700 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 487:
#line 2314 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_XOR, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5709 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 488:
#line 2318 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_REDUCE_XNOR, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5718 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 489:
#line 2322 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_SHIFT_LEFT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5727 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 490:
#line 2326 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_SHIFT_RIGHT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5736 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 491:
#line 2330 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_SHIFT_SLEFT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5745 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 492:
#line 2334 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_SHIFT_SRIGHT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5754 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 493:
#line 2338 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_LT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5763 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 494:
#line 2342 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_LE, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5772 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 495:
#line 2346 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_EQ, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5781 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 496:
#line 2350 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_NE, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5790 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 497:
#line 2354 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_EQX, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5799 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 498:
#line 2358 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_NEX, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5808 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 499:
#line 2362 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_GE, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5817 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 500:
#line 2366 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_GT, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5826 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 501:
#line 2370 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_ADD, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5835 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 502:
#line 2374 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_SUB, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5844 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 503:
#line 2378 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_MUL, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5853 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 504:
#line 2382 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_DIV, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5862 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 505:
#line 2386 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_MOD, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5871 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 506:
#line 2390 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_POW, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5880 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 507:
#line 2394 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_POS, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5889 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 508:
#line 2398 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_NEG, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5898 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 509:
#line 2402 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_LOGIC_AND, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5907 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 510:
#line 2406 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_LOGIC_OR, (yyvsp[-3].ast), (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5916 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 511:
#line 2410 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_LOGIC_NOT, (yyvsp[0].ast));
		append_attr((yyval.ast), (yyvsp[-1].al));
	}
#line 5925 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 512:
#line 2416 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = new AstNode(AST_CONCAT, (yyvsp[0].ast));
	}
#line 5933 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;

  case 513:
#line 2419 "frontends/verilog/verilog_parser.y" /* yacc.c:1646  */
    {
		(yyval.ast) = (yyvsp[0].ast);
		(yyval.ast)->children.push_back((yyvsp[-2].ast));
	}
#line 5942 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
    break;


#line 5946 "frontends/verilog/verilog_parser.tab.cc" /* yacc.c:1646  */
        default: break;
      }
    if (yychar_backup != yychar)
      YY_LAC_DISCARD ("yychar change");
  }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyesa, &yyes, &yyes_capacity, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        if (yychar != YYEMPTY)
          YY_LAC_ESTABLISH;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  /* If the stack popping above didn't lose the initial context for the
     current lookahead token, the shift below will for sure.  */
  YY_LAC_DISCARD ("error recovery");

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if 1
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  if (yyes != yyesa)
    YYSTACK_FREE (yyes);
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
