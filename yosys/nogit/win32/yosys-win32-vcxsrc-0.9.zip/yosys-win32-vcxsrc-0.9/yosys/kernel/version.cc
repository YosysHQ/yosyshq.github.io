namespace Yosys { extern const char *yosys_version_str; const char *yosys_version_str="Yosys 0.9 (git sha1 1979e0b1, Visual Studio)"; }
